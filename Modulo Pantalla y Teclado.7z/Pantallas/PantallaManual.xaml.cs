﻿using System;
using System.Windows;
using System.Windows.Media;
using System.Collections.Specialized;
using System.Windows.Input;
using System.Configuration;
using System.Timers;
using ModuloPantallaTeclado.Clases;
using ModuloPantallaTeclado.Interfaces;
using ModuloPantallaTeclado.Sub_Ventanas;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;
using Entidades.Comunicacion;
using Entidades.Logica;
using Entidades;
using System.Reflection;
using System.Diagnostics;
using Entidades.ComunicacionBaseDatos;

namespace ModuloPantallaTeclado.Pantallas
{
    /// <summary>
    /// Lógica de interacción para PantallaManual.xaml
    /// </summary>
    public partial class PantallaManual : Window, IPantalla
    {
        #region Variables y propiedades de la clase
        private ISubVentana _subVentana = null;
        private object oLock = new object();
        private System.Timers.Timer _timerActualizaReloj = new System.Timers.Timer();
        private VentanaPrincipal _principal;
        public Vehiculo VehiculoRecibido2 { set; get; }
        public Parte ParteRecibido { set; get; }
        public Turno TurnoRecibido { set; get; }
        public InformacionVia InformacionViaRecibida { set; get; }
        public Mimicos MimicosRecibidos { set; get; }
        public MensajesPantalla Mensajes = new MensajesPantalla();
        public ConfigVia ConfigViaRecibida { set; get; }
        private bool _bEstoyEsperandoRespuesta = false;
        public string ParametroAuxiliar { set; get; }
        private static System.Timers.Timer timeOutTimer;
        private const int comTimeOut = 1000;
        private IDictionary<enmTipoImagen, ImageBrush> _imagenesPantalla = new Dictionary<enmTipoImagen, ImageBrush>();
        private NLog.Logger _logger = NLog.LogManager.GetLogger("logfile");
        private JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings
        {
            NullValueHandling = NullValueHandling.Ignore,
            MissingMemberHandling = MissingMemberHandling.Ignore
        };
        #endregion

        #region Constructor de la clase y metodo de carga de colores
        public PantallaManual(VentanaPrincipal principal)
        {
            InitializeComponent();
            _principal = principal;
            //Inicializo timer de actualizacion de hora
            _timerActualizaReloj.Elapsed += OnTick;
            _timerActualizaReloj.Enabled = true;
            _timerActualizaReloj.AutoReset = true;

            //Cargo los eventos que llegan desde la pantalla principal
            _principal.KeyDown -= OnTecla;
            _principal.KeyDown += OnTecla;

            //Me suscribo al evento de recepcion de datos y al de cambio de estado de conexion
            AsynchronousSocketListener.ProcesarDatosRecibidos += RecibirDatosLogica;
            AsynchronousSocketListener.ProcesarCambioEstadoConexion += CambioEstadoConexion;

            CargarSubVentana(enmSubVentana.Principal);
            _subVentana = null;
            _bEstoyEsperandoRespuesta = false;
            ParametroAuxiliar = string.Empty;
            CargarColoresVentana();
        }

        private void CargarColoresVentana()
        {
            //Cargo todas las imagenes desde la carpeta de recursos
            var carpeta = Convert.ToString(ConfigurationManager.AppSettings["CarpetaImagenes"]);
            var path = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location) + carpeta;
            _imagenesPantalla = CargarImagenesRecursos(path);

            //Muestro los logos en los borders correspondientes
            //MAA Comento esto porque en gral va fijo
            //borderLogoCliente.Background = _imagenesPantalla[enmTipoImagen.LogoCliente];
            //borderLogoTelectro.Background = _imagenesPantalla[enmTipoImagen.LogoTelectronica];


            //MAA
            //Cargo los estilos
            //NameValueCollection color = (NameValueCollection)ConfigurationManager.GetSection("color");
            //string fondo = color["fondo"];
            //string borde = color["borde"];

            //Brush brushFondo = (Brush)new BrushConverter().ConvertFrom(fondo);
            //Brush brushBorder = (Brush)new BrushConverter().ConvertFrom(borde);

            //borderInformacionVia.Background = brushFondo;
            //borderInformacionVia.BorderBrush = brushBorder;

            //borderEstadoVia.Background = brushFondo;
            //borderEstadoVia.BorderBrush = brushBorder;

            //borderMensajesVia.Background = brushFondo;
            //borderMensajesVia.BorderBrush = brushBorder;

            //borderSectorVehiculo.Background = brushFondo;
            //borderSectorVehiculo.BorderBrush = brushBorder;

            //border.Background = brushFondo;
            //border.BorderBrush = brushBorder;

            //borderMensajesPrevios.Background = brushFondo;
            //borderMensajesPrevios.BorderBrush = brushBorder;

            //borderDescripcionVentanas.Background = brushFondo;
            //borderDescripcionVentanas.BorderBrush = brushBorder;

            //borderPerifericos.Background = brushFondo;
            //borderPerifericos.BorderBrush = brushBorder;


            //BitmapImage bi3 = new BitmapImage();
            //bi3.BeginInit();
            //bi3.UriSource = new Uri("pack://application:,,,/Recursos/impresora.png", UriKind.Absolute);
            //bi3.EndInit();

            //imgPrinter.Source = bi3;
        }
        #endregion

        #region Metodo para obtener el control (elemento del Framework)
        /// <summary>
        /// Obtiene el control que se quiere agregar a la ventana principal
        /// <returns>FrameworkElement</returns>
        /// </summary>
        public FrameworkElement ObtenerControlPrincipal()
        {
            FrameworkElement control = (FrameworkElement)borderManual.Child;
            borderManual.Child = null;
            Close();
            return control;
        }
        #endregion

        #region Metodo de analisis de comandos recibidos desde logica
        /// <summary>
        /// Analiza y procesa cada comando recibido
        /// </summary>
        /// <param name="com"></param>
        private void AnalizoDatosRecibidos( ComandoLogica com )
        {
            Debug.WriteLine( "AnalizoDatosRecibidos -> _bEstoyEsperandoRespuesta[{0}]", _bEstoyEsperandoRespuesta );

            if( com.CodigoStatus == enmStatus.Abortada )
            {
                _bEstoyEsperandoRespuesta = false;
                return;
            }

            // Si se pulso tecla, se utiliza este flag para timeout
            if( _bEstoyEsperandoRespuesta )
            {
                if( com.Accion == enmAccion.T_MENU && com.Operacion != string.Empty )
                {
                    Application.Current.Dispatcher.Invoke( (Action)( () =>
                      {
                          ParametroAuxiliar = com.Operacion;
                          CargarSubVentana( enmSubVentana.MenuPrincipal );
                          _bEstoyEsperandoRespuesta = false;
                      } ) );
                }
                //else if (com.Accion == enmAccion.FOTO && com.Operacion != string.Empty)
                //{
                //    Application.Current.Dispatcher.Invoke((Action)(() =>
                //    {
                //        ParametroAuxiliar = com.Operacion;
                //        CargarSubVentana(enmSubVentana.Foto);
                //        _bEstoyEsperandoRespuesta = false;
                //    }
                //    ));
                //}
                else if( com.Accion == enmAccion.T_PATENTE )
                {
                    Application.Current.Dispatcher.Invoke( (Action)( () =>
                      {
                          ParametroAuxiliar = com.Operacion;
                          CargarSubVentana( enmSubVentana.Patente );
                          _bEstoyEsperandoRespuesta = false;
                      }
                    ) );
                }
                else if( com.Accion == enmAccion.T_OBSERVACIONES && com.Operacion != string.Empty )
                {
                    Application.Current.Dispatcher.Invoke( (Action)( () =>
                      {
                          ParametroAuxiliar = com.Operacion;
                          CargarSubVentana( enmSubVentana.Observaciones );
                          _bEstoyEsperandoRespuesta = false;
                      } ) );
                }

                else if( com.Accion == enmAccion.T_MONEDAEXTRA && com.Operacion != string.Empty )
                {
                    Application.Current.Dispatcher.Invoke( (Action)( () =>
                      {
                          ParametroAuxiliar = com.Operacion;
                          CargarSubVentana( enmSubVentana.MonedaExtranjera );
                      } ) );
                    _bEstoyEsperandoRespuesta = false;
                }
                else if( com.Accion == enmAccion.T_RETIRO && com.Operacion != string.Empty )
                {
                    Application.Current.Dispatcher.Invoke( (Action)( () =>
                      {
                          ParametroAuxiliar = com.Operacion;
                          if( ParametroAuxiliar == enmAccion.LOGIN.ToString() )
                              CargarSubVentana( enmSubVentana.IngresoSistema );
                          else
                              CargarSubVentana( enmSubVentana.MenuPrincipal );
                          _bEstoyEsperandoRespuesta = false;
                      } ) );
                }
                else if( com.Accion == enmAccion.T_PAGODIFERIDO )
                {
                    Application.Current.Dispatcher.Invoke( (Action)( () =>
                      {
                          ParametroAuxiliar = com.Operacion;
                          CargarSubVentana( enmSubVentana.CrearPagoDiferido );
                      } ) );
                    _bEstoyEsperandoRespuesta = false;
                }
                else if( com.Accion == enmAccion.T_COBRODEUDAS )
                {
                    Application.Current.Dispatcher.Invoke( (Action)( () =>
                      {
                          ParametroAuxiliar = com.Operacion;
                          CargarSubVentana( enmSubVentana.CobroDeudas );
                      } ) );
                    _bEstoyEsperandoRespuesta = false;
                }
                else if( com.Accion == enmAccion.T_TICKETMANUAL && com.Operacion == string.Empty )
                {
                    Application.Current.Dispatcher.Invoke( (Action)( () =>
                      {
                          CargarSubVentana( enmSubVentana.TicketManual );
                      } ) );
                    _bEstoyEsperandoRespuesta = false;
                }
                else if( com.Accion == enmAccion.T_VALEPREPAGO && com.Operacion == string.Empty )
                {
                    Application.Current.Dispatcher.Invoke( (Action)( () =>
                      {
                          CargarSubVentana( enmSubVentana.ValePrepago );
                      } ) );
                    _bEstoyEsperandoRespuesta = false;
                }
                else if( com.Accion == enmAccion.FACTURA && com.CodigoStatus == enmStatus.Ok )
                {
                    Application.Current.Dispatcher.Invoke( (Action)( () =>
                      {
                          ParametroAuxiliar = com.Operacion;
                          CargarSubVentana( enmSubVentana.Factura );
                      } ) );
                    _bEstoyEsperandoRespuesta = false;
                }
            }
            else
            {
                if( com.Accion == enmAccion.FONDO_CAMBIO && com.Operacion != string.Empty )
                {
                    Application.Current.Dispatcher.Invoke( (Action)( () =>
                      {
                          ParametroAuxiliar = com.Operacion;
                          CargarSubVentana( enmSubVentana.FondoCambio );
                      } ) );
                }
                else if( com.Accion == enmAccion.RETIRO_ANT && com.Operacion != string.Empty )
                {
                    Application.Current.Dispatcher.Invoke( (Action)( () =>
                      {
                          ParametroAuxiliar = com.Operacion;
                          CargarSubVentana( enmSubVentana.RetiroAnticipado );
                      } ) );
                }
                else if( com.Accion == enmAccion.LIQUIDACION && com.Operacion != string.Empty )
                {
                    Application.Current.Dispatcher.Invoke( (Action)( () =>
                      {
                          ParametroAuxiliar = com.Operacion;
                          CargarSubVentana( enmSubVentana.Liquidacion );
                      } ) );
                }
                else if( com.Accion == enmAccion.RECORRIDO && com.Operacion != string.Empty )
                {
                    Application.Current.Dispatcher.Invoke( (Action)( () =>
                      {
                          ParametroAuxiliar = com.Operacion;
                          CargarSubVentana( enmSubVentana.Recorridos );
                      } ) );
                }
                else if( com.Accion == enmAccion.MSG_SUPER && com.Operacion != string.Empty )
                {
                    Application.Current.Dispatcher.Invoke( (Action)( () =>
                      {
                          ParametroAuxiliar = com.Operacion;
                          CargarSubVentana( enmSubVentana.MensajesSupervision );
                      } ) );
                }
                else if( com.Accion == enmAccion.MIMICOS && com.Operacion != string.Empty )
                {
                    Application.Current.Dispatcher.Invoke( (Action)( () => OnRecibeMimicosDispositivos( com.Operacion ) ) );
                }
                else if( com.Accion == enmAccion.LIST_EXENTO )
                {
                    Application.Current.Dispatcher.Invoke( (Action)( () =>
                      {
                          ParametroAuxiliar = com.Operacion;
                          CargarSubVentana( enmSubVentana.Exento );
                          _bEstoyEsperandoRespuesta = false;
                      }
                    ) );
                }
                else if( com.Accion == enmAccion.CORRER_PROCESO )
                {
                    Proceso proceso = JsonConvert.DeserializeObject<Proceso>( com.Operacion );

                    ProcessStartInfo info = new ProcessStartInfo( proceso.Path, proceso.Argumentos );
                    info.CreateNoWindow = true;
                    info.UseShellExecute = false;
                    Process exeProcess = Process.Start( info );
                }
            }

            if( com.Accion == enmAccion.LOGIN && com.Operacion != string.Empty )
            {
                ParametroAuxiliar = com.Operacion;
                Application.Current.Dispatcher.Invoke( (Action)( () =>
                      CargarSubVentana( enmSubVentana.IngresoSistema )
                ) );
            }
            else if( com.Accion == enmAccion.MUESTRA_MENU && com.Operacion != string.Empty )
            {
                _bEstoyEsperandoRespuesta = false;
                Application.Current.Dispatcher.Invoke( (Action)( () =>
                  {
                      ParametroAuxiliar = com.Operacion;
                      CargarSubVentana( enmSubVentana.MenuPrincipal );
                  } ) );
            }
            else if( com.Accion == enmAccion.MENSAJES && com.Operacion != string.Empty )
            {
                Application.Current.Dispatcher.Invoke( (Action)( () => OnMensaje( com.Operacion ) ) );
            }
            else if( com.Accion == enmAccion.DATOS_VIA ||
                    com.Accion == enmAccion.DATOS_TURNO ||
                    com.Accion == enmAccion.DATOS_PARTE ||
                    com.Accion == enmAccion.DATOS_VEHICULO
                    && com.Operacion != string.Empty )
            {
                Application.Current.Dispatcher.Invoke( (Action)( () => OnDatosVia( com.Accion, com.Operacion ) ) );
            }
            else if( com.Accion == enmAccion.CONFIRMAR && com.CodigoStatus == enmStatus.Ok )
            {
                Application.Current.Dispatcher.Invoke( (Action)( () =>
                  {
                      ParametroAuxiliar = com.Operacion;
                      CargarSubVentana( enmSubVentana.VentanaConfirmacion );
                  } ) );
            }
            else if( com.Accion == enmAccion.NUMERACION && com.CodigoStatus == enmStatus.Ok )
            {
                Application.Current.Dispatcher.Invoke( (Action)( () =>
                  {
                      ParametroAuxiliar = com.Operacion;
                      CargarSubVentana( enmSubVentana.AutorizacionNumeracion );
                  } ) );
            }
            else if( com.Accion == enmAccion.TAGMANUAL )
            {
                Application.Current.Dispatcher.Invoke( (Action)( () =>
                  {
                      ParametroAuxiliar = com.Operacion;
                      CargarSubVentana( enmSubVentana.TagOcrManual );
                      _bEstoyEsperandoRespuesta = false;
                  } ) );
            }
            else if( com.Accion == enmAccion.RECARGA && com.Operacion != string.Empty )
            {
                Application.Current.Dispatcher.Invoke( (Action)( () =>
                  {
                      ParametroAuxiliar = com.Operacion;
                      CargarSubVentana( enmSubVentana.Venta );
                  } ) );
                _bEstoyEsperandoRespuesta = false;
            }
            else if( com.Accion == enmAccion.CAMBIO_PASS && com.Operacion != string.Empty )
            {
                Application.Current.Dispatcher.Invoke( (Action)( () =>
                  {
                      ParametroAuxiliar = com.Operacion;
                      CargarSubVentana( enmSubVentana.CambioPassword );
                  } ) );
            }
            else if( com.Accion == enmAccion.FOTO && com.Operacion != string.Empty )
            {
                Application.Current.Dispatcher.Invoke( (Action)( () =>
                  {
                      ParametroAuxiliar = com.Operacion;
                      CargarSubVentana( enmSubVentana.Foto );
                      _bEstoyEsperandoRespuesta = false;
                  }
                ) );
            }
            else if (com.Accion == enmAccion.EXPRESIONES && com.Operacion != string.Empty)
            {
                Clases.Utiles.CargarFiltroPatentes(com.Operacion);
            }
            else if(com.Accion == enmAccion.CONFIGTECLAS && com.Operacion != string.Empty)
            {
                Dictionary<string, string> sectorTeclas = Utiles.ClassUtiles.ExtraerObjetoJson<Dictionary<string, string>>(com.Operacion);
                Teclado.CargarTeclasFuncion(ref sectorTeclas);
            }
        }

        private void OnDatosVia(enmAccion accion,string objDatos)
        {
            InformacionVia informacionViaRecibida = new InformacionVia();
            InformacionViaRecibida = informacionViaRecibida;
            //Extraigo los datos en sus respectivas propiedades
            switch (accion)
            {                
                case enmAccion.DATOS_VIA:
                    ConfigViaRecibida = Utiles.ClassUtiles.ExtraerObjetoJson<ConfigVia>(objDatos);

                    InformacionViaRecibida.ConfigVia = ConfigViaRecibida;

                    gridInformacionVia.DataContext = null;
                    gridInformacionVia.DataContext = InformacionViaRecibida;
                    break;
                case enmAccion.DATOS_VEHICULO:
                    VehiculoRecibido2 = Utiles.ClassUtiles.ExtraerObjetoJson<Vehiculo>(objDatos);
                    gridSectorVehiculo.DataContext = null;
                    gridSectorVehiculo.DataContext = VehiculoRecibido2;
                    gridPerifericos.DataContext = null;
                    gridPerifericos.DataContext = VehiculoRecibido2;
                    gridSectorVehiculo.DataContext = null;
                    gridSectorVehiculo.DataContext = VehiculoRecibido2;
                    break;
                case enmAccion.DATOS_PARTE:
                    ParteRecibido = Utiles.ClassUtiles.ExtraerObjetoJson<Parte>(objDatos);
                    break;
                case enmAccion.DATOS_TURNO:
                    TurnoRecibido = Utiles.ClassUtiles.ExtraerObjetoJson<Turno>(objDatos);
                    //gridEstadoVia.DataContext = null;
                    //gridEstadoVia.DataContext = TurnoRecibido;

                    PanelTipoCarga.DataContext = null;
                    PanelTipoCarga.DataContext = TurnoRecibido;

                    PanelEstadoVia.DataContext = null;
                    PanelEstadoVia.DataContext = TurnoRecibido;


                    InformacionViaRecibida.Turno = TurnoRecibido;

                    ConfigViaRecibida = Utiles.ClassUtiles.ExtraerObjetoJson<ConfigVia>(objDatos);
                    InformacionViaRecibida.ConfigVia = ConfigViaRecibida;

                    gridInformacionVia.DataContext = null;
                    gridInformacionVia.DataContext = InformacionViaRecibida;
                    break;
            }

            Application.Current.Dispatcher.Invoke((Action)(() =>
            {
                //Actualizo todos los data context de la pantalla para mostrar datos nuevos
                if (VehiculoRecibido2 != null)
                {
                    txtNumeroFactura.Text = VehiculoRecibido2.NumeroTicketF.ToString();
                    txtNumeroTransito.Text = VehiculoRecibido2.NumeroTransito.ToString();

                    //Actualizo la imagen de categoria
                    imgCategoria.Background = GetImagenCategoria(VehiculoRecibido2);
                    //Muestro la tarifa
                    txtTarifa.Text = Datos.FormatearMonedaAString(VehiculoRecibido2.Tarifa);
                }
            }));
        }
        #endregion

        #region Metodo de recepcion de mensajes
        /// <summary>
        /// Metodo que actualiza los mensajes en pantalla
        /// (Mensajes de lineas y desde supervision)
        /// </summary>
        /// <param name="objMensaje"></param>
        private void OnMensaje(string objMensaje)
        {
            try
            {
                var MensajeRecibido = JsonConvert.DeserializeObject<Mensajes>(objMensaje);

                Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                {
                    Mensajes.ActualizarMensaje(MensajeRecibido);
                    gridMensajesLineas.DataContext = null;
                    gridMensajesLineas.DataContext = Mensajes;
                    gridMensajesPrevios.DataContext = null;
                    gridMensajesPrevios.DataContext = Mensajes;
                }));
            }
            catch (JsonException jsonEx)
            {
                _logger.Debug("PantallaManual:OnMensaje() JsonException: {0}", jsonEx.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
            catch (Exception ex)
            {
                _logger.Debug("PantallaManual:OnMensaje() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
        }
        #endregion

        #region Metodo de actualizacion de mimicos de dispositivos
        /// <summary>
        /// Carga las imagenes correspondientes al estado de cada dispositivo
        /// </summary>
        /// <param name="objMimicosJson"></param>
        private void OnRecibeMimicosDispositivos(string objMimicosJson)
        {
            try
            {
                MimicosRecibidos = Utiles.ClassUtiles.ExtraerObjetoJson<Mimicos>(objMimicosJson);

                Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                {
                    if (MimicosRecibidos.EstadoRedLocal != enmEstadoDispositivo.Nada)
                    {
                        if (MimicosRecibidos.EstadoRedLocal == enmEstadoDispositivo.OK) imgEstadoRed.Background = _imagenesPantalla[enmTipoImagen.RedOk];
                        else if (MimicosRecibidos.EstadoRedLocal == enmEstadoDispositivo.Error) imgEstadoRed.Background = _imagenesPantalla[enmTipoImagen.RedError];
                    }

                    //TODO: falta agregar el icono de la conexion de red con el servidor
                    /*
                    if (MimicosRecibidos.EstadoRedServidor != enmEstadoDispositivo.Nada)
                    {
                        if (MimicosRecibidos.EstadoRedServidor == enmEstadoDispositivo.OK) imgEstadoRed.Background = _imagenesPantalla[enmTipoImagen.RedOk];
                        else if (MimicosRecibidos.EstadoRedServidor == enmEstadoDispositivo.Error) imgEstadoRed.Background = _imagenesPantalla[enmTipoImagen.RedError];
                    }
                    */

                    if (MimicosRecibidos.EstadoImpresora != enmEstadoDispositivo.Nada)
                    {
                        if (MimicosRecibidos.EstadoImpresora == enmEstadoDispositivo.OK)
                        {
                            imgPrinterBorder.Background = new SolidColorBrush(Color.FromRgb(0, 255, 0));
                            //imgPrinter.Background = _imagenesPantalla[enmTipoImagen.ImpresoraOk];
                            /*BitmapImage bi3 = new BitmapImage();
                            bi3.BeginInit();
                            bi3.UriSource = new Uri("pack://application:,,,/Recursos/impresoraOK.png", UriKind.Absolute);
                            bi3.EndInit();

                            imgPrinter.Source = bi3;*/
                        }
                        else if (MimicosRecibidos.EstadoImpresora == enmEstadoDispositivo.Error)
                        {
                            imgPrinterBorder.Background = new SolidColorBrush(Color.FromRgb(255, 0, 0));

                            //imgPrinter.Background = _imagenesPantalla[enmTipoImagen.ImpresoraError];
                            /*BitmapImage bi3 = new BitmapImage();
                            bi3.BeginInit();
                            bi3.UriSource = new Uri("\\Recursos\\impresoraError.png", UriKind.Relative);
                            bi3.EndInit();
                            */


                        }
                        //else if (MimicosRecibidos.EstadoImpresora == enmEstadoDispositivo.No) imgPrinter.Background = _imagenesPantalla[enmTipoImagen.ImpresoraNo];
                        //else if (MimicosRecibidos.EstadoImpresora == enmEstadoDispositivo.Warning) imgPrinter.Background = _imagenesPantalla[enmTipoImagen.ImpresoraWarning];
                    }

                    if (MimicosRecibidos.EstadoAntena != enmEstadoDispositivo.Nada)
                    {
                        if (MimicosRecibidos.EstadoAntena == enmEstadoDispositivo.OK) imgAntena.Background = _imagenesPantalla[enmTipoImagen.AntenaOk];
                        else if (MimicosRecibidos.EstadoAntena == enmEstadoDispositivo.Error) imgAntena.Background = _imagenesPantalla[enmTipoImagen.AntenaError];
                        else if (MimicosRecibidos.EstadoAntena == enmEstadoDispositivo.No) imgAntena.Background = _imagenesPantalla[enmTipoImagen.AntenaNo];
                        else if (MimicosRecibidos.EstadoAntena == enmEstadoDispositivo.Warning) imgAntena.Background = _imagenesPantalla[enmTipoImagen.AntenaWarning];
                    }

                    if (MimicosRecibidos.EstadoSeparador != enmEstadoDispositivo.Nada)
                    {
                        if (MimicosRecibidos.EstadoSeparador == enmEstadoDispositivo.OK) imgSeparador.Background = _imagenesPantalla[enmTipoImagen.SeparadorOk];
                        else if (MimicosRecibidos.EstadoSeparador == enmEstadoDispositivo.Error) imgSeparador.Background = _imagenesPantalla[enmTipoImagen.SeparadorError];
                    }

                    if (MimicosRecibidos.EstadoTarjetaChip != enmEstadoDispositivo.Nada)
                    {
                        if (MimicosRecibidos.EstadoTarjetaChip == enmEstadoDispositivo.OK) imgTarjChip.Background = _imagenesPantalla[enmTipoImagen.TChipOk];
                        else if (MimicosRecibidos.EstadoTarjetaChip == enmEstadoDispositivo.Error) imgTarjChip.Background = _imagenesPantalla[enmTipoImagen.TChipError];
                        else if (MimicosRecibidos.EstadoTarjetaChip == enmEstadoDispositivo.No) imgTarjChip.Background = _imagenesPantalla[enmTipoImagen.TChipNo];
                        else if (MimicosRecibidos.EstadoTarjetaChip == enmEstadoDispositivo.Warning) imgTarjChip.Background = _imagenesPantalla[enmTipoImagen.TChipWarning];
                    }

                    if (MimicosRecibidos.EstadoBarrera != enmEstadoBarrera.Nada)
                    {
                        if (MimicosRecibidos.EstadoBarrera == enmEstadoBarrera.Abajo) imgBarrera.Background = _imagenesPantalla[enmTipoImagen.BarreraAbajo];
                        else if (MimicosRecibidos.EstadoBarrera == enmEstadoBarrera.Arriba) imgBarrera.Background = _imagenesPantalla[enmTipoImagen.BarreraArriba];
                    }

                    if (MimicosRecibidos.SemaforoMarquesina != eEstadoSemaforo.Nada)
                    {
                        if (MimicosRecibidos.SemaforoMarquesina == eEstadoSemaforo.Rojo) imgSemMarquesina.Background = _imagenesPantalla[enmTipoImagen.SemMarquesinaRojo];
                        else if (MimicosRecibidos.SemaforoMarquesina == eEstadoSemaforo.Verde) imgSemMarquesina.Background = _imagenesPantalla[enmTipoImagen.SemMarquesinaVerde];
                    }

                    if (MimicosRecibidos.SemaforoPaso != eEstadoSemaforo.Nada)
                    {
                        if (MimicosRecibidos.SemaforoPaso == eEstadoSemaforo.Rojo) imgSemPaso.Background = _imagenesPantalla[enmTipoImagen.SemPasoRojo];
                        else if (MimicosRecibidos.SemaforoPaso == eEstadoSemaforo.Verde) imgSemPaso.Background = _imagenesPantalla[enmTipoImagen.SemPasoVerde];
                    }

                    if (MimicosRecibidos.CampanaViolacion != enmEstadoDispositivo.Nada)
                    {
                        if (MimicosRecibidos.CampanaViolacion == enmEstadoDispositivo.OK) imgCampana.Background = _imagenesPantalla[enmTipoImagen.Campana];
                        else imgCampana.Background = null;
                    }
                }));
            }
            catch (JsonException jsonEx)
            {
                _logger.Debug("PantallaManual:OnRecibeMimicosDispositivos() JsonException: {0}", jsonEx.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
            catch (Exception ex)
            {
                _logger.Debug("PantallaManual:OnRecibeMimicosDispositivos() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
        }
        #endregion

        #region Metodos de recepcion y envio de datos a modulo de logica
        /// <summary>
        /// Este metodo se llama cuando se desconecta un cliente.
        /// </summary>
        public void CambioEstadoConexion()
        {
            var mensajeDesconexion = new Mensajes();
            try
            {
                Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                {
                    Mensajes.LimpiarMensajesPantalla();
                }));
                //Se desconecto el cliente
                if (!AsynchronousSocketListener.PuertoAbierto())
                {
                    //Si habia alguna ventana abierta la cierro
                    if (_subVentana != null)
                        CargarSubVentana(enmSubVentana.Principal);
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        mensajeDesconexion.TipoMensaje = enmTipoMensaje.Linea1;
                        mensajeDesconexion.Mensaje = "No se puede conectar con servicio de lógica.";
                        Mensajes.ActualizarMensaje(mensajeDesconexion);
                    }));
                }

                if (_bEstoyEsperandoRespuesta)
                    _bEstoyEsperandoRespuesta = false;

                Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                {
                    gridMensajesLineas.DataContext = null;
                    gridMensajesLineas.DataContext = Mensajes;
                    gridMensajesPrevios.DataContext = null;
                    gridMensajesPrevios.DataContext = Mensajes;
                }));
            }
            catch
            {

            }
        }

        /// <summary>
        /// Este metodo recibe el string JSON que llega desde el socket
        /// </summary>
        /// <param name="JsonString"></param>
        public void RecibirDatosLogica(ComandoLogica comandoJson)
        {
            try
            {

                Debug.WriteLine("RecibirDatosLogica -> Accion[{0}] Status[{1}] SubVentana[{2}] Operacion[{3}]",
                    comandoJson.Accion, 
                    comandoJson.CodigoStatus.ToString(), 
                    _subVentana == null ? "NULL" : "NOT NULL",
                    comandoJson.Operacion);

                lock (oLock)
                {
                    if (_subVentana != null)
                        _subVentana.RecibirDatosLogica(comandoJson);
                    else
                        AnalizoDatosRecibidos(comandoJson);
                }
                
            }
            catch (JsonException jsonEx)
            {
                _logger.Debug("PantallaManual:RecibirDatosLogica() JsonException: {0}", jsonEx.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
            catch (Exception ex)
            {
                _logger.Debug("PantallaManual:RecibirDatosLogica() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
        }

        /// <summary>
        /// Este metodo envia un json formateado en string hacia el socket
        /// </summary>
        /// <param name="status"></param>
        /// <param name="Accion"></param>
        /// <param name="Operacion"></param>
        public void EnviarDatosALogica(enmStatus status, enmAccion Accion, string Operacion)
        {
            var comandoJson = new ComandoLogica(status, Accion, Operacion);

            try
            {
                AsynchronousSocketListener.SendDataToAll(comandoJson);
                SetTimeOutTimer();
            }
            catch (Exception ex)
            {
                _logger.Debug("PantallaManual:EnviarDatosALogica() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al intentar enviar datos a logica.");
            }
        }
        #endregion

        #region Metodos de recepcion y analisis de teclas presionadas
        /// <summary>
        /// Evento que recibe la tecla presionada
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void OnTecla(object sender, KeyEventArgs e)
        {
            _logger.Trace("PantallaManual:OnTecla() [{0}]", e.Key.ToString());

            TeclasMaximaPrioridad(e.Key);

            if (_subVentana != null)
                _subVentana.ProcesarTecla(e.Key);
            else
            {
                if (_bEstoyEsperandoRespuesta == false)
                {
                    AnalizaTecla(e.Key);
                }
            }

        }

        /// <summary>
        /// Este metodo contiene las teclas que se ejecutan siempre, independientemente
        /// de la ventana o subventana visible.
        /// </summary>
        /// <param name="tecla"></param>
        private void TeclasMaximaPrioridad(Key tecla)
        {
            if (Teclado.IsFunctionKey(tecla, "SubeBarrera"))
            {
                //Envio el comando de tecla subir barrera a logica
                _bEstoyEsperandoRespuesta = true;
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_SUBEBARRERA, string.Empty);
            }
            else if (Teclado.IsFunctionKey(tecla, "BajaBarrera"))
            {
                //Envio el comando de tecla bajar barrera a logica
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_BAJABARRERA, string.Empty);
            }
            else if (Teclado.IsFunctionKey(tecla, "Semaforo"))
            {
                //Envio el comando de tecla semaforo a logica
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_SEMAFORO, string.Empty);
            }
        }

        /// <summary>
        /// Recibe la tecla que fue presionada y llama a la función correspondiente a ser ejecutada.
        /// <param name="tecla"></param>
        /// </summary>
        public void AnalizaTecla(Key tecla)
        {
            if (Teclado.IsFunctionKey(tecla,"Turno"))
            {
                //Envio el comando de tecla turno a logica y espero la respuesta
                _bEstoyEsperandoRespuesta = true;
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_TURNO, string.Empty);
            }
            else if (Teclado.IsFunctionKey(tecla, "Menu"))
            {
                //Envio el comando de tecla menu a logica y espero la respuesta
                _bEstoyEsperandoRespuesta = true;
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_MENU, string.Empty);
            }
            else if (Teclado.IsFunctionKey(tecla, "Exento"))
            {
                //Envio el comando de tecla exento a logica y espero la respuesta
                _bEstoyEsperandoRespuesta = true;
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_EXENTO, string.Empty);
            }
            else if (Teclado.IsFunctionKey(tecla, "Foto"))
            {
                //Envio el comando de tecla foto a logica y espero la respuesta
                _bEstoyEsperandoRespuesta = true;
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_FOTO, string.Empty);
            }
            else if (Teclado.IsFunctionKey(tecla, "Patente"))
            {
                //Envio el comando de tecla foto a logica y espero la respuesta
                _bEstoyEsperandoRespuesta = true;
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_PATENTE, string.Empty);
            }
            else if (Teclado.IsFunctionKey(tecla, "TagManual"))
            {
                //Envio el comando de tecla foto a logica y espero la respuesta
                _bEstoyEsperandoRespuesta = true;
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_TAGMANUAL, string.Empty);
            }
            else if (Teclado.IsFunctionKey(tecla, "Retiro"))
            {
                //Envio el comando de tecla retiro a logica y espero la respuesta
                _bEstoyEsperandoRespuesta = true;
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_RETIRO, string.Empty);
            }
            else if (Teclado.IsFunctionKey(tecla, "Venta"))
            {
                //Envio el comando de tecla venta a logica y espero la respuesta
                _bEstoyEsperandoRespuesta = true;
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_VENTA, string.Empty);
            }
            else if (Teclado.IsFunctionKey(tecla, "Observaciones"))
            {
                //Envio el comando de tecla observaciones a logica y espero la respuesta
                _bEstoyEsperandoRespuesta = true;
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_OBSERVACIONES, string.Empty);
            }
            else if (Teclado.IsFunctionKey(tecla, "PagoDiferido"))
            {
                //Envio el comando de tecla pago diferido a logica y espero la respuesta
                _bEstoyEsperandoRespuesta = true;
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_PAGODIFERIDO, string.Empty);
            }
            else if (Teclado.IsFunctionKey(tecla, "CobroDeudas"))
            {
                //Envio el comando de tecla cobro deudas a logica y espero la respuesta
                _bEstoyEsperandoRespuesta = true;
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_COBRODEUDAS, string.Empty);
            }
            else if (Teclado.IsFunctionKey(tecla, "TicketManual"))
            {
                //Envio el comando de tecla ticket manual a logica y espero la respuesta
                _bEstoyEsperandoRespuesta = true;
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_TICKETMANUAL, string.Empty);
            }
            else if (Teclado.IsFunctionKey(tecla, "MonedaExtranjera"))
            {
                //Envio el comando de tecla moneda extranjera a logica y espero la respuesta
                _bEstoyEsperandoRespuesta = true;
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_MONEDAEXTRA, string.Empty);
            }
            else if (Teclado.IsFunctionKey(tecla, "SimulacionPaso"))
            {
                //Envio el comando de tecla simulacion paso a logica
                _bEstoyEsperandoRespuesta = true;
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_SIMULACPASO, string.Empty);
            }
            else if (Teclado.IsFunctionKey(tecla, "Quiebre"))
            {
                //Envio el comando de tecla quiebre a logica
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_QUIEBRE, string.Empty);
            }
            else if (Teclado.IsFunctionKey(tecla, "Cash"))
            {
                //Envio el comando de tecla cash a logica
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_CASH, string.Empty);
            }
            else if (Teclado.IsFunctionKey(tecla, "Factura"))
            {
                //Envio el comando de tecla factura a logica
                _bEstoyEsperandoRespuesta = true;
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_FACTURA, string.Empty);
            }
            else if (Teclado.IsFunctionKey(tecla, "ValePrepago"))
            {
                //Envio el comando de tecla observaciones a logica y espero la respuesta
                _bEstoyEsperandoRespuesta = true;
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_VALEPREPAGO, string.Empty);
            }
            else if (Teclado.IsFunctionKey(tecla, "Enter"))
            {
                //Envio el comando de tecla enter a logica
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_ENTER, string.Empty);
            }
            else if (Teclado.IsFunctionKey(tecla, "Escape"))
            {
                //Envio el comando de tecla enter a logica
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_ESCAPE, string.Empty);
            }
            else if (Teclado.IsFunctionKey(tecla, "Cancelar"))
            {
                //Envio el comando de tecla escape a logica
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_CANCELAR, string.Empty);
            }
            else if (Teclado.IsFunctionKey(tecla, "DetracManual"))
            {
                //Envio el comando de tecla detraccion manual a logica
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_DETRACMAN, string.Empty);
            }
            else if (Teclado.IsFunctionKey(tecla, "UnViaje"))
            {
                //Envio el comando de tecla un viaje a logica
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_UNVIAJE, string.Empty);
            }
            else if (Teclado.IsFunctionKey(tecla, "Tarjeta"))
            {
                //Envio el comando de tecla tarjeta a logica
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_TARJETA, string.Empty);
            }
            else if (Teclado.IsFunctionKey(tecla, "ExentoAmbulancia"))
            {
                //Envio el comando de tecla exento ambulancia a logica                
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_EXENTOAMBU, string.Empty);
            }
            else if (Teclado.IsFunctionKey(tecla, "ExentoBombero"))
            {
                //Envio el comando de tecla exento bombero a logica
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_EXENTOBOMB, string.Empty);
            }
            else if (Teclado.IsFunctionKey(tecla, "ExentoPolicia"))
            {
                //Envio el comando de tecla exento policia a logica
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_EXENTOPOLI, string.Empty);
            }
            //Analizo las teclas de categoria
            else if (Teclado.IsNumericKey(tecla))
            {
                Vehiculo vehiculo = new Vehiculo();
                List<DatoVia> listaDV = new List<DatoVia>();
                if (Teclado.IsFunctionKey(tecla, "Categoria1"))
                {
                    vehiculo.Categoria = 1;
                    Utiles.ClassUtiles.InsertarDatoVia(vehiculo, ref listaDV);
                    EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_CATEGORIA, JsonConvert.SerializeObject(listaDV, jsonSerializerSettings));
                }
                else if (Teclado.IsFunctionKey(tecla, "Categoria2"))
                {
                    vehiculo.Categoria = 2;
                    Utiles.ClassUtiles.InsertarDatoVia(vehiculo, ref listaDV);
                    EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_CATEGORIA, JsonConvert.SerializeObject(listaDV, jsonSerializerSettings));
                }
                else if (Teclado.IsFunctionKey(tecla, "Categoria3"))
                {
                    vehiculo.Categoria = 3;
                    Utiles.ClassUtiles.InsertarDatoVia(vehiculo, ref listaDV);
                    EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_CATEGORIA, JsonConvert.SerializeObject(listaDV, jsonSerializerSettings));
                }
                else if (Teclado.IsFunctionKey(tecla, "Categoria4"))
                {
                    vehiculo.Categoria = 4;
                    Utiles.ClassUtiles.InsertarDatoVia(vehiculo, ref listaDV);
                    EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_CATEGORIA, JsonConvert.SerializeObject(listaDV, jsonSerializerSettings));
                }
                else if (Teclado.IsFunctionKey(tecla, "Categoria5"))
                {
                    vehiculo.Categoria = 5;
                    Utiles.ClassUtiles.InsertarDatoVia(vehiculo, ref listaDV);
                    EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_CATEGORIA, JsonConvert.SerializeObject(listaDV, jsonSerializerSettings));
                }
                else if (Teclado.IsFunctionKey(tecla, "Categoria6"))
                {
                    vehiculo.Categoria = 6;
                    Utiles.ClassUtiles.InsertarDatoVia(vehiculo, ref listaDV);
                    EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_CATEGORIA, JsonConvert.SerializeObject(listaDV, jsonSerializerSettings));
                }
                else if (Teclado.IsFunctionKey(tecla, "Categoria7"))
                {
                    vehiculo.Categoria = 7;
                    Utiles.ClassUtiles.InsertarDatoVia(vehiculo, ref listaDV);
                    EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_CATEGORIA, JsonConvert.SerializeObject(listaDV, jsonSerializerSettings));
                }
                else if (Teclado.IsFunctionKey(tecla, "Categoria8"))
                {
                    vehiculo.Categoria = 8;
                    Utiles.ClassUtiles.InsertarDatoVia(vehiculo, ref listaDV);
                    EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_CATEGORIA, JsonConvert.SerializeObject(listaDV, jsonSerializerSettings));
                }
                else if (Teclado.IsFunctionKey(tecla, "Categoria9"))
                {
                    vehiculo.Categoria = 9;
                    Utiles.ClassUtiles.InsertarDatoVia(vehiculo, ref listaDV);
                    EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_CATEGORIA, JsonConvert.SerializeObject(listaDV, jsonSerializerSettings));
                }
            }
        }
        #endregion

        #region Metodo de muestra de mensaje en cuadro de descripcion
        public void MensajeDescripcion(string mensaje)
        {
            Application.Current.Dispatcher.BeginInvoke((Action)(() =>
            {
                txtDescripcion.Text = mensaje;
            }));
        }
        #endregion

        #region Metodo de carga de sub-ventana
        /// <summary>
        /// Metodo que carga una subventana en el border correspondiente
        /// </summary>
        /// <param name="subVentana"></param>
        public void CargarSubVentana(enmSubVentana subVentana)
        {
            switch (subVentana)
            {
                case enmSubVentana.IngresoSistema:
                    {
                        _subVentana = new IngresoSistema(this);
                        SubVentana.Child = _subVentana.ObtenerControlPrincipal();
                        break;
                    }
                case enmSubVentana.MenuPrincipal:
                    {
                        _subVentana = new MenuPrincipal(this);
                        SubVentana.Child = _subVentana.ObtenerControlPrincipal();
                        break;
                    }
                case enmSubVentana.Exento:
                    {
                        _subVentana = new VentanaExento(this);
                        SubVentana.Child = _subVentana.ObtenerControlPrincipal();
                        break;
                    }
                case enmSubVentana.Foto:
                    {
                        _subVentana = new VentanaFoto(this);
                        SubVentana.Child = _subVentana.ObtenerControlPrincipal();
                        break;
                    }
                case enmSubVentana.Patente:
                    {
                        _subVentana = new VentanaPatente(this);
                        SubVentana.Child = _subVentana.ObtenerControlPrincipal();
                        break;
                    }
                case enmSubVentana.TagOcrManual:
                    {
                        _subVentana = new VentanaTagManual(this);
                        SubVentana.Child = _subVentana.ObtenerControlPrincipal();
                        break;
                    }
                case enmSubVentana.FondoCambio:
                    {
                        _subVentana = new VentanaFondoCambio(this);
                        SubVentana.Child = _subVentana.ObtenerControlPrincipal();
                        break;
                    }
                case enmSubVentana.RetiroAnticipado:
                    {
                        if (Utiles.ClassUtiles.ExtraerObjetoJson<RetiroAnticipado>(ParametroAuxiliar).PorDenominacion)
                        {
                            _subVentana = new VentanaRetiroAnticipadoDenominaciones(this);
                        }
                        else
                        {
                            _subVentana = new VentanaRetiroAnticipado(this);
                        }
                        SubVentana.Child = _subVentana.ObtenerControlPrincipal();
                        break;
                    }
                case enmSubVentana.Liquidacion:
                    {
                        _subVentana = new VentanaLiquidacion(this);
                        SubVentana.Child = _subVentana.ObtenerControlPrincipal();
                        break;
                    }
                case enmSubVentana.CambioPassword:
                    {
                        _subVentana = new VentanaCambioPassword(this);
                        SubVentana.Child = _subVentana.ObtenerControlPrincipal();
                        break;
                    }
                case enmSubVentana.Venta:
                    {
                        _subVentana = new VentanaVenta(this);
                        SubVentana.Child = _subVentana.ObtenerControlPrincipal();
                        break;
                    }
                case enmSubVentana.MensajesSupervision:
                    {
                        _subVentana = new VentanaMsgSupervision(this);
                        SubVentana.Child = _subVentana.ObtenerControlPrincipal();
                        break;
                    }
                case enmSubVentana.Observaciones:
                    {
                        _subVentana = new VentanaObservaciones(this);
                        SubVentana.Child = _subVentana.ObtenerControlPrincipal();
                        break;
                    }
                case enmSubVentana.CrearPagoDiferido:
                    {
                        _subVentana = new VentanaPagoDiferido(this);
                        SubVentana.Child = _subVentana.ObtenerControlPrincipal();
                        break;
                    }
                case enmSubVentana.CobroDeudas:
                    {
                        _subVentana = new VentanaCobroDeudas(this);
                        SubVentana.Child = _subVentana.ObtenerControlPrincipal();
                        break;
                    }
                case enmSubVentana.TicketManual:
                    {
                        _subVentana = new VentanaTicketManual(this);
                        SubVentana.Child = _subVentana.ObtenerControlPrincipal();
                        break;
                    }
                case enmSubVentana.ValePrepago:
                    {
                        _subVentana = new VentanaValePrepago(this);
                        SubVentana.Child = _subVentana.ObtenerControlPrincipal();
                        break;
                    }
                case enmSubVentana.Recorridos:
                    {
                        _subVentana = new VentanaRecorridos(this);
                        SubVentana.Child = _subVentana.ObtenerControlPrincipal();
                        break;
                    }
                case enmSubVentana.MonedaExtranjera:
                    {
                        _subVentana = new VentanaMonedaExtranjera(this);
                        SubVentana.Child = _subVentana.ObtenerControlPrincipal();
                        break;
                    }
                case enmSubVentana.Factura:
                    {
                        _subVentana = new VentanaCobroFactura(this);
                        SubVentana.Child = _subVentana.ObtenerControlPrincipal();
                        break;
                    }
                case enmSubVentana.VentanaConfirmacion:
                    {
                        _subVentana = new VentanaConfirmacion(this);
                        SubVentana.Child = _subVentana.ObtenerControlPrincipal();
                        break;
                    }
                case enmSubVentana.AutorizacionNumeracion:
                    {
                        _subVentana = new VentanaAutNumeracion(this);
                        SubVentana.Child = _subVentana.ObtenerControlPrincipal();
                        break;
                    }
                default:
                    {
                        try
                        {
                            SubVentana.Child = null;
                            _subVentana = null;
                            txtDescripcion.Text = "";
                        }
                        catch
                        {

                        }
                        break;
                    }
            }
        }
        #endregion

        #region Timer de timeout de comunicaciones
        private void SetTimeOutTimer()
        {
            // Create a timer with a two second interval.
            timeOutTimer = new System.Timers.Timer(comTimeOut);
            // Hook up the Elapsed event for the timer. 
            timeOutTimer.Elapsed += OnTimedEvent;
            timeOutTimer.AutoReset = false;
            timeOutTimer.Enabled = true;
        }

        private void OnTimedEvent(object source, ElapsedEventArgs e)
        {
            if(_bEstoyEsperandoRespuesta)
            {
                _bEstoyEsperandoRespuesta = false;
                timeOutTimer.Enabled = false;
            }
        }
        #endregion

        #region Metodo de actualizacion de fecha/hora mediante timer
        private void OnTick(object sender, object e)
        {
            txtFecha.Dispatcher.BeginInvoke((Action)(() => txtFecha.Text = DateTime.Now.ToString("dd/MM/yyyy")));
            txtHora.Dispatcher.BeginInvoke((Action)(() => txtHora.Text = DateTime.Now.ToString("HH:mm:ss")));
        }
        #endregion

        #region Metodo que carga las imagenes que estan en la carpeta de recursos en RAM
        /// <summary>
        /// Carga las imagenes como brushes en un diccionario
        /// </summary>
        /// <param name="carpetaRecursos"></param>
        /// <returns></returns>
        public IDictionary<enmTipoImagen, ImageBrush> CargarImagenesRecursos(string carpetaRecursos)
        {
            IDictionary<enmTipoImagen, ImageBrush> dict = new Dictionary<enmTipoImagen, ImageBrush>();
            var imagenBrush = new ImageBrush();
            var filters = new string[] { "png", "gif", "jpg", "bmp" };

            try
            {
                foreach(enmTipoImagen key in Enum.GetValues(typeof(enmTipoImagen)))
                {
                    dict.Add(key, null);
                }

                var files = Utiles.ClassUtiles.GetFilesFrom(carpetaRecursos, filters, false);
                foreach (var imagen in files)
                {
                    //Compruebo que el recurso forme parte del enumerado para agregarlo al diccionario
                    if (Enum.IsDefined(typeof(enmTipoImagen), Path.GetFileNameWithoutExtension(imagen)))
                    {
                        imagenBrush = new ImageBrush();
                        imagenBrush.ImageSource = new BitmapImage(new Uri(BaseUriHelper.GetBaseUri(this), imagen));
                        imagenBrush.Freeze();
                        dict[(enmTipoImagen)Enum.Parse(typeof(enmTipoImagen), Path.GetFileNameWithoutExtension(imagen))] = imagenBrush;
                        imagenBrush = null;
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.Debug("PantallaManual:CargarImagenesRecursos() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al cargar las imagenes desde la carpeta.");
            }
            return dict;
        }
        #endregion

        #region Metodo que devuelve una imagen de categoria de acuerdo al Vehiculo
        /// <summary>
        /// Devuelve un ImageBrush con la imagen de la categoria del vehiculo
        /// </summary>
        /// <param name="veh"></param>
        /// <returns></returns>
        private ImageBrush GetImagenCategoria(Vehiculo veh)
        {
            ImageBrush imgBrush = null;

            try
            {
                switch (veh.Categoria)
                {
                    case 0:
                        {
                            imgBrush = _imagenesPantalla[enmTipoImagen.categoria0];
                            break;
                        }
                    case 1:
                        {
                            imgBrush = _imagenesPantalla[enmTipoImagen.categoria1];
                            break;
                        }
                    case 2:
                        {
                            imgBrush = _imagenesPantalla[enmTipoImagen.categoria2];
                            break;
                        }
                    case 3:
                        {
                            imgBrush = _imagenesPantalla[enmTipoImagen.categoria3];
                            break;
                        }
                    case 4:
                        {
                            imgBrush = _imagenesPantalla[enmTipoImagen.categoria4];
                            break;
                        }
                    case 5:
                        {
                            imgBrush = _imagenesPantalla[enmTipoImagen.categoria5];
                            break;
                        }
                    case 6:
                        {
                            imgBrush = _imagenesPantalla[enmTipoImagen.categoria6];
                            break;
                        }
                    case 7:
                        {
                            imgBrush = _imagenesPantalla[enmTipoImagen.categoria7];
                            break;
                        }
                    case 8:
                        {
                            imgBrush = _imagenesPantalla[enmTipoImagen.categoria8];
                            break;
                        }
                    case 9:
                        {
                            imgBrush = _imagenesPantalla[enmTipoImagen.categoria9];
                            break;
                        }
                }
            }
            catch (Exception ex)
            {
                _logger.Debug("PantallaManual:GetImagenCategoria() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al mostrar la imagen correspondiente.");
            }
            return imgBrush;
        }
        #endregion
    }
}
