﻿using System;
using System.Reflection;
using System.Windows;
using System.Windows.Input;
using ModuloPantallaTeclado.Clases;
using ModuloPantallaTeclado.Interfaces;
using ModuloPantallaTeclado.Pantallas;
using System.Threading;
using System.Configuration;

namespace ModuloPantallaTeclado
{
    /// <summary>
    /// Lógica de interacción para VentanaPrincipal.xaml
    /// </summary>
    public partial class VentanaPrincipal : Window
    {
        #region Variables de clase
        private Thread ThreadingServer = null;
        private IPantalla _pantallaVia = null;
        private NLog.Logger _logger = NLog.LogManager.GetLogger("logfile");
        #endregion

        #region Constructor de la clase
        public VentanaPrincipal()
        {
            InitializeComponent();
            string version = Assembly.GetExecutingAssembly().GetName().Version.ToString();
            ventanaPrincipal.Title = Assembly.GetExecutingAssembly().GetName().Name + " " + version;

            _logger.Info("************** Inicio Pantalla TCI {0} **************",version);

            if (ThreadingServer == null)
            {
                ThreadingServer = new Thread(StartServer);
            }

            //Clases.Utiles.CargarFiltroPatentes();
            Clases.Utiles.CargarConfigCortarPatente();
        }
        #endregion

        #region Hilo de servidor TCP asincronico
        private static void StartServer()
        {
            AsynchronousSocketListener.StartListening();
        }
        #endregion

        #region Eventos de la ventana
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //Inicio el hilo del servidor
            ThreadingServer.Start();

            //Dibujo la pantalla que corresponda segun el tipo de via
            try
            {
                string modeloVia = Convert.ToString(ConfigurationManager.AppSettings["ModeloVia"]);
                var tipoVia = (enmModeloVia)Enum.Parse(typeof(enmModeloVia), modeloVia.ToUpper());

                if (tipoVia == enmModeloVia.AVI)
                    _pantallaVia = new PantallaAVI(this);
                else if (tipoVia == enmModeloVia.DINAMICA)
                    _pantallaVia = new PantallaDinamica(this);
                else
                    _pantallaVia = new PantallaManual(this);

                borderPrincipal.Child = _pantallaVia.ObtenerControlPrincipal();
            }
            catch (Exception ex)
            {
                _logger.Fatal("VentanaPrincipal:Window_Loaded() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al instanciar la pantalla.");
            }
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            AsynchronousSocketListener.Cerrar();
            ThreadingServer = null;
            _logger.Info("****************** Cierre Pantalla TCI ******************");
        }

        private void gridPrincipal_KeyDown(object sender, KeyEventArgs e)
        {

        }
        #endregion
    }
}
