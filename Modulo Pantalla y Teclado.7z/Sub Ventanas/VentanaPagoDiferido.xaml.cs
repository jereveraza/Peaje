﻿using System;
using System.Windows;
using ModuloPantallaTeclado.Interfaces;
using ModuloPantallaTeclado.Entidades;
using ModuloPantallaTeclado.Clases;
using System.Collections.Generic;
using Newtonsoft.Json;
using Entidades.Comunicacion;
using Entidades;
using Entidades.Logica;
using System.Windows.Input;

namespace ModuloPantallaTeclado.Sub_Ventanas
{
    public enum enmMenuPagoDiferido { IngresoPatente, IngresoDocumento, ObtenerDatos, ConfirmoPago, ConfirmoImpresionTkt }

    /// <summary>
    /// Lógica de interacción para VentanaPagoDiferido.xaml
    /// </summary>
    public partial class VentanaPagoDiferido : Window, ISubVentana
    {
        #region Variables y propiedades de clase
        private IPantalla _pantalla = null;
        private enmMenuPagoDiferido _enmMenuPagoDiferido;
        private string _patenteIngresada;
        private NLog.Logger _logger = NLog.LogManager.GetLogger("logfile");
        JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings
        {
            NullValueHandling = NullValueHandling.Ignore,
            MissingMemberHandling = MissingMemberHandling.Ignore
        };
        #endregion

        #region Mensajes de descripcion
        const string msgIngresoPatente = "Ingrese la patente [ENTER] para confirmar, [ESC] para volver.";
        const string msgFormatoPatenteErr = "Formato de patente incorrecto";
        const string msgIngresoDocumento = "Ingrese el número de documento y presione [ENTER] para confirmar, [ESC] para volver.";
        const string msgFirmaTicket = "Confirme la firma del ticket con [ENTER], [ESC] para salir.";
        const string msgConfirmePagoDif = "Confirme el pago diferido con [ENTER], [ESC] para volver.";
        #endregion

        #region Constructor de la clase
        /// <summary>
        /// Constructor de la clase
        /// </summary>
        /// <param name="padre"></param>
        public VentanaPagoDiferido(IPantalla padre)
        {
            InitializeComponent();
            _pantalla = padre;
        }
        #endregion

        #region Evento de carga de la ventana
        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            _enmMenuPagoDiferido = enmMenuPagoDiferido.IngresoPatente;
            
            Application.Current.Dispatcher.BeginInvoke((Action)(() =>
            {
                _pantalla.MensajeDescripcion(msgIngresoPatente);
                txtBoxViolacionesMonto.Text = Datos.GetSimboloMonedaReferencia()+"0";
                txtBoxPagosDifMonto.Text = Datos.GetSimboloMonedaReferencia()+"0";
                txtBoxViolaciones.Text = "0";
                txtBoxPagosDif.Text = "0";
                if (_pantalla.ParametroAuxiliar != string.Empty)
                {
                    _patenteIngresada = _pantalla.ParametroAuxiliar;
                    txtBoxPatente.Text = _patenteIngresada;
                }
            }));
        }
        #endregion

        #region Metodo para obtener el control desde el padre
        /// <summary>
        /// Obtiene el control que se quiere agregar a la ventana principal
        /// <returns>FrameworkElement</returns>
        /// </summary>
        public FrameworkElement ObtenerControlPrincipal()
        {
            FrameworkElement control = (FrameworkElement)borderPagoDiferido.Child;
            borderPagoDiferido.Child = null;
            Close();
            return control;
        }
        #endregion

        #region Metodo que carga los datos en los controles
        /// <summary>
        /// Metodo que carga los datos enviados por logica en los controles
        /// </summary>
        /// <param name="datos"></param>
        private void CargarDatosEnControles(string datos)
        {
            if (datos == "CERRAR")
            {
                //No se puede hacer el pago diferido, cierro la ventana
                Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                {
                    _pantalla.CargarSubVentana(enmSubVentana.Principal);
                }));
            }
            else
            {
                int totalViolaciones = 0, totalPagosDif = 0;
                long  deudaTotalViolaciones = 0, deudaTotalPagosDif = 0;

                try
                {                    
                    ListaDeuda listaDeudas = Utiles.ClassUtiles.ExtraerObjetoJson<ListaDeuda>(datos);
                    List<Deuda> deudas = listaDeudas.ListaDeudas;

                    //Cuento la cantidad de deudas segun tipo y calculo el monto adeudado
                    foreach (var v in deudas)
                    {
                        if (v.Tipo == "VIOLACION")
                        {
                            totalViolaciones++;
                            deudaTotalViolaciones += v.Monto;
                        }
                        else
                        {
                            totalPagosDif++;
                            deudaTotalPagosDif += v.Monto;
                        }
                    }
                    //Cargo los valores en los textbox correspondientes
                    txtBoxViolaciones.Text = totalViolaciones.ToString();
                    txtBoxViolacionesMonto.Text = Datos.GetSimboloMonedaReferencia() + deudaTotalViolaciones.ToString();
                    txtBoxPagosDif.Text = totalPagosDif.ToString();
                    txtBoxPagosDifMonto.Text = Datos.GetSimboloMonedaReferencia() + deudaTotalPagosDif.ToString();
                    //Ordeno la lista por fecha descendente
                    deudas.Sort((x, y) => y.FechaHora.CompareTo(x.FechaHora));
                    //Si hay mas de 5 elementos, solo muestro los primeros 5
                    dataGridDeudas.Items.Clear();
                    if (deudas.Count > 5)
                        dataGridDeudas.ItemsSource = deudas.GetRange(0, 5);
                    else
                        dataGridDeudas.ItemsSource = deudas;
                    dataGridDeudas.Items.Refresh();

                    _enmMenuPagoDiferido = enmMenuPagoDiferido.ConfirmoPago;
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        _pantalla.MensajeDescripcion(msgConfirmePagoDif);
                    }));
                }
                catch (JsonException jsonEx)
                {
                    _logger.Debug("VentanaPagoDiferido:CargarDatosEnControles() JsonException: {0}", jsonEx.Message.ToString());
                    _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
                }
                catch (Exception ex)
                {
                    _logger.Debug("VentanaPagoDiferido:CargarDatosEnControles() Exception: {0}", ex.Message.ToString());
                    _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
                }
            }

        }
        #endregion

        #region Metodos de comunicacion con el modulo de logica
        /// <summary>
        /// Este metodo recibe el string JSON que llega desde el socket
        /// </summary>
        /// <param name="comandoJson"></param>
        public void RecibirDatosLogica(ComandoLogica comandoJson)
        {
            try
            {
                if (_enmMenuPagoDiferido == enmMenuPagoDiferido.ObtenerDatos && comandoJson.Accion == enmAccion.PAGO_DIF)
                {
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        CargarDatosEnControles(comandoJson.Operacion);
                    }));
                }
            }
            catch (Exception ex)
            {
                _logger.Debug("VentanaPagoDiferido:RecibirDatosLogica() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al intentar enviar datos a logica.");
            }
        }

        /// <summary>
        /// Este metodo envia un json formateado en string hacia el socket
        /// </summary>
        /// <param name="status"></param>
        /// <param name="Accion"></param>
        /// <param name="Operacion"></param>
        public void EnviarDatosALogica(enmStatus status, enmAccion Accion, string Operacion)
        {
            try
            {
                _pantalla.EnviarDatosALogica(status, Accion, Operacion);
            }
            catch (Exception ex)
            {
                _logger.Debug("VentanaPagoDiferido:EnviarDatosALogica() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al intentar enviar datos a logica.");
            }
        }
        #endregion

        #region Metodo de procesamiento de tecla recibida
        /// <summary>
        /// A este metodo llegan las teclas recibidas desde la pantalla principal
        /// </summary>
        /// <param name="tecla"></param>
        public void ProcesarTecla(Key tecla)
        {
            List<DatoVia> listaDV = new List<DatoVia>();
            if (Teclado.IsEscapeKey(tecla))
            {
                Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                {
                    _pantalla.CargarSubVentana(enmSubVentana.Principal);
                    EnviarDatosALogica(enmStatus.Abortada, enmAccion.PAGO_DIF, string.Empty);
                }));
            }
            else if (Teclado.IsConfirmationKey(tecla))
            {
                if (_enmMenuPagoDiferido == enmMenuPagoDiferido.IngresoPatente)
                {
                    _patenteIngresada = txtBoxPatente.Text;
                    if (Clases.Utiles.EsPatenteValida(_patenteIngresada))
                    {
                        Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                        {
                            //Solicito a logica datos de la patente
                            Vehiculo vehiculo = new Vehiculo();
                            vehiculo.Patente = _patenteIngresada;
                            Utiles.ClassUtiles.InsertarDatoVia(vehiculo, ref listaDV);
                            EnviarDatosALogica(enmStatus.Ok, enmAccion.PAGO_DIF, Newtonsoft.Json.JsonConvert.SerializeObject(listaDV, jsonSerializerSettings) );
                        }));

                        //<----------   Aca va el ingreso opcional del documento
                        _enmMenuPagoDiferido = enmMenuPagoDiferido.ObtenerDatos;
                    }
                    else
                    {
                        //Si se ingreso la patente incorrecta, aviso al usuario y borro los datos
                        //ingresados
                        _pantalla.MensajeDescripcion(msgFormatoPatenteErr);
                        _patenteIngresada = string.Empty;
                        //No borro los datos ingresados para que el usuario pueda editar
                        //txtBoxPatente.Text = string.Empty;
                    }
                }
                else if(_enmMenuPagoDiferido == enmMenuPagoDiferido.ConfirmoPago)
                {
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        _pantalla.MensajeDescripcion(msgFirmaTicket);
                        _enmMenuPagoDiferido = enmMenuPagoDiferido.ConfirmoImpresionTkt;
                    }));
                }
                else if(_enmMenuPagoDiferido == enmMenuPagoDiferido.ConfirmoImpresionTkt)
                {
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        _pantalla.CargarSubVentana(enmSubVentana.Principal);
                        //Envio a logica la solicitud del pago diferido
                        Vehiculo vehiculo = new Vehiculo();
                        vehiculo.Patente = _patenteIngresada;
                        Utiles.ClassUtiles.InsertarDatoVia(vehiculo, ref listaDV);
                        EnviarDatosALogica(enmStatus.Ok, enmAccion.CREAR_PAGO_DIF, _patenteIngresada);
                    }));
                }
            }
            else if (Teclado.IsBackspaceKey(tecla))
            {
                if (_enmMenuPagoDiferido == enmMenuPagoDiferido.IngresoPatente)
                {
                    if (txtBoxPatente.Text.Length > 0)
                        txtBoxPatente.Text = txtBoxPatente.Text.Remove(txtBoxPatente.Text.Length - 1);
                }
            }
            else
            {
                if (_enmMenuPagoDiferido == enmMenuPagoDiferido.IngresoPatente)
                {
                    if (Teclado.IsLowerCaseOrNumberKey(tecla))
                        txtBoxPatente.Text += Teclado.GetKeyAlphaNumericValue(tecla);
                }
            }
        }
        #endregion
    }
}
