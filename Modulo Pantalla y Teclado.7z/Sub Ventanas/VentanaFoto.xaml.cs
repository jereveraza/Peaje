﻿using System;
using System.Windows;
using ModuloPantallaTeclado.Interfaces;
using ModuloPantallaTeclado.Clases;
using Entidades.Comunicacion;
using Entidades;
using System.Collections.Generic;
using Entidades.ComunicacionFoto;
using Newtonsoft.Json;
using System.IO;
using System.Timers;
using System.Windows.Input;

namespace ModuloPantallaTeclado.Sub_Ventanas
{
    /// <summary>
    /// Lógica de interacción para VentanaFoto.xaml
    /// </summary>
    public partial class VentanaFoto : Window, ISubVentana
    {
        #region Variables y propiedades de clase
        private IPantalla _pantalla = null;
        private bool _bSolicitudNuevaFoto = false;
        private bool _bZoomFoto = false;
        private string _strPathFoto;
        private Timer _timerFoto = new Timer();
        private NLog.Logger _logger = NLog.LogManager.GetLogger("logfile");
        JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings
        {
            NullValueHandling = NullValueHandling.Ignore,
            MissingMemberHandling = MissingMemberHandling.Ignore
        };
        #endregion

        #region Mensajes de descripcion
        const string msgSeleccionOpciones = "Presione [ENTER] para confirmar, [ESC] para cancelar.";
        #endregion

        #region Constructor de la clase
        public VentanaFoto(IPantalla padre)
        {
            InitializeComponent();
            _pantalla = padre;
        }
        #endregion

        #region Evento de carga de la ventana
        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            _bSolicitudNuevaFoto = false;
            Foto foto = Utiles.ClassUtiles.ExtraerObjetoJson<Foto>( _pantalla.ParametroAuxiliar );
            _strPathFoto = Path.Combine( foto.PathFoto, foto.Nombre );

            _timerFoto.Elapsed += new ElapsedEventHandler( ChequeaExisteFoto );
            _timerFoto.Interval = 50;
            _timerFoto.AutoReset = true;
            _timerFoto.Start();
        }
        #endregion

        #region Timer de comprobacion de existencia de foto
        /// <summary>
        /// Timer que chequea si existe el archivo flg de la foto correspondiente y la actualiza en pantalla
        /// </summary>
        /// <param name="source"></param>
        /// <param name="e"></param>
        private void ChequeaExisteFoto( object source, ElapsedEventArgs e )
        {
            if( File.Exists( _strPathFoto + ".flg" ) )
            {
                Application.Current.Dispatcher.BeginInvoke( (Action)( () =>
                {
                    panelFoto.Children.Clear();
                    panelFoto.Children.Add( Clases.Utiles.CargarFotoRectangulo( _strPathFoto, Datos.AnchoFoto, Datos.AltoFoto, false ) );
                    _pantalla.MensajeDescripcion( msgSeleccionOpciones );    
                } ) );
                _timerFoto.Stop();
            }
        }
        #endregion

        #region Metodo para obtener el control desde el padre
        /// <summary>
        /// Obtiene el control que se quiere agregar a la ventana principal
        /// <returns>FrameworkElement</returns>
        /// </summary>
        public FrameworkElement ObtenerControlPrincipal()
        {
            FrameworkElement control = (FrameworkElement)borderVentanaFoto.Child;
            borderVentanaFoto.Child = null;
            Close();
            return control;
        }
        #endregion

        #region Metodos de comunicacion con el modulo de logica
        /// <summary>
        /// Este metodo recibe el string JSON que llega desde el socket
        /// </summary>
        /// <param name="comandoJson"></param>
        public void RecibirDatosLogica(ComandoLogica comandoJson)
        {
            try
            {
                if (comandoJson.Accion == enmAccion.FOTO && comandoJson.Operacion != string.Empty && _bSolicitudNuevaFoto)
                {
                    Foto foto = Utiles.ClassUtiles.ExtraerObjetoJson<Foto>( comandoJson.Operacion );
                    _strPathFoto = Path.Combine( foto.PathFoto, foto.Nombre );
                    
                    _timerFoto.Start();
                }
            }
            catch (Exception ex)
            {
                _logger.Debug("VentanaFoto:RecibirDatosLogica() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al recibir el path de la foto de logica.");
            }
        }

        /// <summary>
        /// Este metodo envia un json formateado en string hacia el socket
        /// </summary>
        /// <param name="status"></param>
        /// <param name="Accion"></param>
        /// <param name="Operacion"></param>
        public void EnviarDatosALogica(enmStatus status, enmAccion Accion, string Operacion)
        {
            try
            {
                _pantalla.EnviarDatosALogica(status, Accion, Operacion);
            }
            catch (Exception ex)
            {
                _logger.Debug("VentanaFoto:EnviarDatosALogica() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al intentar enviar datos a logica.");
            }
        }
        #endregion

        #region Metodo de procesamiento de tecla recibida
        /// <summary>
        /// A este metodo llegan las teclas recibidas desde la pantalla principal
        /// </summary>
        /// <param name="tecla"></param>
        public void ProcesarTecla(Key tecla)
        {
            List<DatoVia> listaDV = new List<DatoVia>();
            if (Teclado.IsConfirmationKey(tecla))
            {
                //Envio a logica el path de la foto a enviar con el transito
                Foto foto = new Foto();
                foto.PathFoto = _strPathFoto;
                if (_timerFoto.Enabled)
                    _timerFoto.Stop();
                Utiles.ClassUtiles.InsertarDatoVia(foto, ref listaDV);
                EnviarDatosALogica(enmStatus.Ok, enmAccion.FOTO_TRAN, JsonConvert.SerializeObject(listaDV, jsonSerializerSettings));
                _pantalla.CargarSubVentana(enmSubVentana.Principal);
            }
            else if (Teclado.IsFunctionKey(tecla, "Foto"))
            {
                //Solicito una nueva foto a logica
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_FOTO, string.Empty);
                _bSolicitudNuevaFoto = true;
            }
            else if (Teclado.IsFunctionKey(tecla, "ZoomFoto"))
            {
                //Inserto la foto con zoom en lugar de la anterior
                Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                {
                    if (_bZoomFoto) _bZoomFoto = false;
                    else _bZoomFoto = true;
                    panelFoto.Children.Clear();
                    panelFoto.Children.Add( Clases.Utiles.CargarFotoRectangulo(_strPathFoto, Datos.AnchoFoto, Datos.AltoFoto, _bZoomFoto));
                }));
            }
            else if (Teclado.IsEscapeKey(tecla))
            {
                _pantalla.CargarSubVentana(enmSubVentana.Principal);
                if (_timerFoto.Enabled)
                    _timerFoto.Stop();
                EnviarDatosALogica(enmStatus.Abortada, enmAccion.FOTO_TRAN, string.Empty);
            }

        }
        #endregion
    }
}
