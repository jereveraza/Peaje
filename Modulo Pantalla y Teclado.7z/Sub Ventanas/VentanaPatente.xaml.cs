﻿using System;
using System.Windows;
using ModuloPantallaTeclado.Interfaces;
using ModuloPantallaTeclado.Clases;
using Entidades.Comunicacion;
using Entidades;
using Entidades.Logica;
using System.Collections.Generic;
using Entidades.ComunicacionFoto;
using Newtonsoft.Json;
using System.IO;
using System.Timers;
using System.Windows.Input;

namespace ModuloPantallaTeclado.Sub_Ventanas
{
    /// <summary>
    /// Lógica de interacción para VentanaPatente.xaml
    /// </summary>
    public partial class VentanaPatente : Window, ISubVentana
    {
        #region Variables y propiedades de clase
        private IPantalla _pantalla = null;
        private string _patenteIngresada;
        private bool _bSolicitudNuevaFoto = true;
        private bool _bZoomFoto = false;
        private string _strPathFoto = null;
        private Timer _timerFoto = new Timer();
        private Causa _causa = null;
        private NLog.Logger _logger = NLog.LogManager.GetLogger("logfile");
        JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings
        {
            NullValueHandling = NullValueHandling.Ignore,
            MissingMemberHandling = MissingMemberHandling.Ignore
        };
        #endregion

        #region Mensajes de descripcion
        const string msgSeleccionOpciones = "Ingrese la patente [ENTER] para confirmar, [ESC] para volver.";
        const string msgFormatoPatenteErr = "Formato de patente incorrecto";
        #endregion

        #region Constructor de la clase
        public VentanaPatente(IPantalla padre)
        {
            InitializeComponent();
            _pantalla = padre;
        }
        #endregion

        #region Evento de carga de la ventana
        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            if (_pantalla.ParametroAuxiliar != string.Empty)
            {
                _causa = Utiles.ClassUtiles.ExtraerObjetoJson<Causa>(_pantalla.ParametroAuxiliar);
                Vehiculo vehiculo = Utiles.ClassUtiles.ExtraerObjetoJson<Vehiculo>(_pantalla.ParametroAuxiliar);
                if (vehiculo != null)
                {
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        txtPatente.Text = vehiculo.Patente;
                    }));
                }
            }
            panelFoto.Children.Add(Clases.Utiles.CargarFotoRectangulo("", Datos.AnchoFoto, Datos.AltoFoto, false));
            _pantalla.MensajeDescripcion(msgSeleccionOpciones);

            _timerFoto.Elapsed += new ElapsedEventHandler( ChequeaExisteFoto );
            _timerFoto.Interval = 50;
            _timerFoto.AutoReset = true;
        }
        #endregion

        #region Metodo para obtener el control desde el padre
        /// <summary>
        /// Obtiene el control que se quiere agregar a la ventana principal
        /// <returns>FrameworkElement</returns>
        /// </summary>
        public FrameworkElement ObtenerControlPrincipal()
        {
            FrameworkElement control = (FrameworkElement)borderVentanaPatente.Child;
            borderVentanaPatente.Child = null;
            Close();
            return control;
        }
        #endregion

        #region Timer de comprobacion de foto
        /// <summary>
        /// Timer que chequea si existe el archivo flg de la foto correspondiente y la actualiza en pantalla
        /// </summary>
        /// <param name="source"></param>
        /// <param name="e"></param>
        private void ChequeaExisteFoto( object source, ElapsedEventArgs e )
        {
            if( File.Exists( _strPathFoto + ".flg" ) )
            {
                Application.Current.Dispatcher.BeginInvoke( (Action)( () =>
                {
                    panelFoto.Children.Clear();
                    panelFoto.Children.Add( Clases.Utiles.CargarFotoRectangulo( _strPathFoto, Datos.AnchoFoto, Datos.AltoFoto, false ) );
                    _pantalla.MensajeDescripcion( msgSeleccionOpciones );
                } ) );
                _timerFoto.Stop();
            }
        }
        #endregion

        #region Metodos de comunicacion con el modulo de logica
        /// <summary>
        /// Este metodo recibe el string JSON que llega desde el socket
        /// </summary>
        /// <param name="comandoJson"></param>
        public void RecibirDatosLogica(ComandoLogica comandoJson)
        {
            try
            {
                if (comandoJson.Accion == enmAccion.FOTO && comandoJson.Operacion != string.Empty && _bSolicitudNuevaFoto)
                {
                    //Inserto la nueva foto en lugar de la anterior
                    panelFoto.Dispatcher.Invoke((Action)(() =>
                    {
                        //if( panelFoto.Children.Count > 1 )
                        //    panelFoto.Children.RemoveAt(0);
                        Foto foto = Utiles.ClassUtiles.ExtraerObjetoJson<Foto>(comandoJson.Operacion);

                        _strPathFoto = Path.Combine(foto?.PathFoto, foto?.Nombre);

                        _timerFoto.Start();

                        //panelFoto.Children.Insert(0, Clases.Utiles.CargarFotoRectangulo( _strPathFoto, Datos.AnchoFoto, Datos.AltoFoto, false));
                        _bSolicitudNuevaFoto = false;
                        _pantalla.ParametroAuxiliar = comandoJson.Operacion;
                    }));
                }
                else if (comandoJson.CodigoStatus == enmStatus.Ok
                        && comandoJson.Accion == enmAccion.ESTADO)
                {
                    Causa causa = Utiles.ClassUtiles.ExtraerObjetoJson<Causa>(comandoJson.Operacion);

                    if (causa.Codigo == eCausas.AperturaTurno
                        || causa.Codigo == eCausas.CausaCierre
                        || causa.Codigo == eCausas.Salidavehiculo)
                    {
                        //Logica indica que se debe cerrar la ventana
                        Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                        {
                            _pantalla.CargarSubVentana(enmSubVentana.Principal);
                        }));
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.Debug("VentanaPatente:RecibirDatosLogica() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al recibir una Respuesta de logica.");
            }
        }

        /// <summary>
        /// Este metodo envia un json formateado en string hacia el socket
        /// </summary>
        /// <param name="status"></param>
        /// <param name="Accion"></param>
        /// <param name="Operacion"></param>
        public void EnviarDatosALogica(enmStatus status, enmAccion Accion, string Operacion)
        {
            try
            {
                _pantalla.EnviarDatosALogica(status, Accion, Operacion);
            }
            catch
            {

            }
        }
        #endregion

        #region Metodo de procesamiento de tecla recibida
        /// <summary>
        /// A este metodo llegan las teclas recibidas desde la pantalla principal
        /// </summary>
        /// <param name="tecla"></param>
        public void ProcesarTecla(Key tecla)
        {
            List<DatoVia> listaDV = new List<DatoVia>();
            if (Teclado.IsConfirmationKey(tecla))
            {
                //Compruebo si el formato de la patente es correcto
                _patenteIngresada = txtPatente.Text;
                if (Clases.Utiles.EsPatenteValida(_patenteIngresada))
                {
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        if (_timerFoto.Enabled)
                            _timerFoto.Stop();
                        //Envio solicitud de lista de exentos
                        Vehiculo vehiculo = new Vehiculo();
                        vehiculo.Patente = _patenteIngresada;
                        Utiles.ClassUtiles.InsertarDatoVia(vehiculo, ref listaDV);

                        Utiles.ClassUtiles.InsertarDatoVia(_causa, ref listaDV);

                        EnviarDatosALogica(enmStatus.Ok, enmAccion.TRA_PATENTE, JsonConvert.SerializeObject(listaDV, jsonSerializerSettings));
                        _pantalla.CargarSubVentana(enmSubVentana.Principal);
                    }));
                }
                else
                {
                    //Si se ingreso la patente incorrecta, aviso al usuario y borro los datos
                    //ingresados
                    _pantalla.MensajeDescripcion(msgFormatoPatenteErr);
                    _patenteIngresada = string.Empty;
                    //No se borra la patente para que la editen
                    //txtPatente.Text = string.Empty;
                }
            }
            else if (Teclado.IsFunctionKey(tecla, "Foto"))
            {
                //Solicito una nueva foto a logica
                EnviarDatosALogica(enmStatus.Tecla, enmAccion.T_FOTO, string.Empty);
                _bSolicitudNuevaFoto = true;
            }
            else if (Teclado.IsFunctionKey(tecla, "ZoomFoto"))
            {
                //Inserto la foto con zoom en lugar de la anterior
                Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                {
                    if (_bZoomFoto) _bZoomFoto = false;
                    else _bZoomFoto = true;
                    panelFoto.Children.RemoveAt(0);
                    panelFoto.Children.Insert(0, Clases.Utiles.CargarFotoRectangulo(_pantalla.ParametroAuxiliar, Datos.AnchoFoto, Datos.AltoFoto, _bZoomFoto));
                }));
            }
            else if (Teclado.IsEscapeKey(tecla))
            {
                if (_timerFoto.Enabled)
                    _timerFoto.Stop();
                txtPatente.Text = string.Empty;
                _pantalla.CargarSubVentana(enmSubVentana.Principal);
                EnviarDatosALogica(enmStatus.Abortada, enmAccion.TRA_PATENTE, string.Empty);
            }
            else if (Teclado.IsBackspaceKey(tecla))
            {
                if (txtPatente.Text.Length > 0)
                    txtPatente.Text = txtPatente.Text.Remove(txtPatente.Text.Length - 1);
            }
            else
            {
                if (Teclado.IsLowerCaseOrNumberKey(tecla))
                    txtPatente.Text += Teclado.GetKeyAlphaNumericValue(tecla);
            }
        }
        #endregion
    }
}
