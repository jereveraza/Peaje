﻿using System;
using System.Windows;
using ModuloPantallaTeclado.Interfaces;
using ModuloPantallaTeclado.Clases;
using System.Windows.Controls;
using System.Windows.Media;
using System.Collections.Specialized;
using System.Configuration;
using Newtonsoft.Json;
using Entidades.Comunicacion;
using Entidades;
using System.Collections.Generic;
using Entidades.Logica;
using Entidades.ComunicacionBaseDatos;
using System.Windows.Input;

namespace ModuloPantallaTeclado.Sub_Ventanas
{
    public enum enmMenuExento { IngresoPatente, ListaExentos }

    /// <summary>
    /// Lógica de interacción para VentanaExento.xaml
    /// </summary>
    public partial class VentanaExento : Window, ISubVentana
    {
        #region Variables y propiedades de clase
        private IPantalla _pantalla = null;
        private enmMenuExento _enmMenuExento = enmMenuExento.ListaExentos;
        private TextBox _txtPatente;
        private ListBox _listaOpciones;
        private string _patenteIngresada;
        private ListBoxItem _ItemSeleccionado;
        private int _cantidadOpcionesMenu;
        private bool _bPrimerDigito = false;
        private bool _bZoomFoto = false;
        private int _OpcionElegida;
        private string _colorItemSeleccionado;        
        private PatenteExenta _patenteExenta = null;
        private ListadoOpciones _listadoOpciones = null;
        private Label lblMenuOpcion;
        private NLog.Logger _logger = NLog.LogManager.GetLogger("logfile");
        JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings
        {
            NullValueHandling = NullValueHandling.Ignore,
            MissingMemberHandling = MissingMemberHandling.Ignore
        };
        #endregion

        #region Mensajes de descripcion
        const string msgSeleccionOpciones = "Ingrese la patente [ENTER] para confirmar, [ESC] para volver.";
        const string msgSeleccionTipoExento = "Seleccione una opcion [0-9] y presione [ENTER], [ESC] para volver.";
        const string msgTextoOpcionElegida = "Opción elegida:";
        const string msgFormatoPatenteErr = "Formato de patente incorrecto";
        #endregion

        #region Constructor de la clase
        /// <summary>
        /// Constructor de la clase
        /// </summary>
        /// <param name="padre"></param>
        public VentanaExento(IPantalla padre)
        {
            InitializeComponent();
            _pantalla = padre;
            NameValueCollection color = (NameValueCollection)ConfigurationManager.GetSection("color");
            _colorItemSeleccionado = color["itemSeleccionado"];
            _listaOpciones = null;
        }
        #endregion

        #region Evento de carga de la ventana
        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            _enmMenuExento = enmMenuExento.ListaExentos;
            _patenteExenta = Utiles.ClassUtiles.ExtraerObjetoJson<PatenteExenta>(_pantalla.ParametroAuxiliar);
            Application.Current.Dispatcher.BeginInvoke((Action)(() =>
            {
                DibujarPantalla();
                CargarDatosEnControles(_pantalla.ParametroAuxiliar);
            }));            
        }
        #endregion

        #region Metodo que dibuja los controles en pantalla
        /// <summary>
        /// Dibuja los controles en la pantalla
        /// </summary>
        private void DibujarPantalla()
        {
            if (_enmMenuExento == enmMenuExento.IngresoPatente)
            {
                _pantalla.MensajeDescripcion(msgSeleccionOpciones);
                panelExentos.Children.Clear();
                panelExentos.Children.Add(Clases.Utiles.CargarFotoRectangulo(_pantalla.ParametroAuxiliar, Datos.AnchoFoto, Datos.AltoFoto, false));
                _txtPatente = new TextBox();
                _txtPatente.Height = 32;
                _txtPatente.FontSize = 25;
                _txtPatente.Margin = new Thickness(0, 8, 0, 0);
                _txtPatente.VerticalContentAlignment = VerticalAlignment.Top;
                _txtPatente.HorizontalContentAlignment = HorizontalAlignment.Center;
                _txtPatente.FontWeight = FontWeights.Bold;
                _txtPatente.Width = 200;
                panelExentos.Children.Add(_txtPatente);
            }
            else if (_enmMenuExento == enmMenuExento.ListaExentos)
            {
                _pantalla.MensajeDescripcion(msgSeleccionTipoExento);
                //Borro los controles anteriores
                panelExentos.Children.Clear();

                //Dibujo la lista de opciones de exentos
                _listaOpciones = new ListBox();
                _listaOpciones.Height = 318;
                _listaOpciones.Width = 450;
                panelExentos.Children.Add(_listaOpciones);
                //Dibujo el label y textbox de la seleccion

                WrapPanel panelAuxiliar = new WrapPanel();
                panelAuxiliar.Orientation = Orientation.Horizontal;

                Label lblTextoOpcionElegida = new Label();
                lblTextoOpcionElegida.Content = msgTextoOpcionElegida;
                lblTextoOpcionElegida.VerticalAlignment = VerticalAlignment.Top;
                lblTextoOpcionElegida.FontSize = 20;
                lblTextoOpcionElegida.Height = 33;
                lblTextoOpcionElegida.Width = 165;
                lblTextoOpcionElegida.FontWeight = FontWeights.Bold;
                lblTextoOpcionElegida.FontFamily = new FontFamily("Arial");
                lblTextoOpcionElegida.Foreground = new SolidColorBrush(Colors.White);
                panelAuxiliar.Children.Add(lblTextoOpcionElegida);

                lblMenuOpcion = new Label();
                lblMenuOpcion.Content = " ";
                lblMenuOpcion.VerticalAlignment = VerticalAlignment.Top;
                lblMenuOpcion.VerticalContentAlignment = VerticalAlignment.Center;
                lblMenuOpcion.HorizontalContentAlignment = HorizontalAlignment.Center;
                lblMenuOpcion.FontSize = 20;
                lblMenuOpcion.Height = 33;
                lblMenuOpcion.Width = 35;
                lblMenuOpcion.FontWeight = FontWeights.Bold;
                lblMenuOpcion.FontFamily = new FontFamily("Arial");
                lblMenuOpcion.Background = new SolidColorBrush(Colors.LightGray);

                //panelExentos.Orientation = Orientation.Horizontal;
                panelAuxiliar.Children.Add(lblMenuOpcion);
                panelAuxiliar.Margin = new Thickness(120, 8, 0, 0);
                panelExentos.Children.Add(panelAuxiliar);
            }
        }
        #endregion

        #region Metodo para obtener el control desde el padre
        /// <summary>
        /// Obtiene el control que se quiere agregar a la ventana principal
        /// <returns>FrameworkElement</returns>
        /// </summary>
        public FrameworkElement ObtenerControlPrincipal()
        {
            FrameworkElement control = (FrameworkElement)borderVentanaExento.Child;
            borderVentanaExento.Child = null;
            Close();
            return control;
        }
        #endregion

        #region Metodos de comunicacion con el modulo de logica
        /// <summary>
        /// Este metodo recibe el string JSON que llega desde el socket
        /// </summary>
        /// <param name="comandoJson"></param>
        public void RecibirDatosLogica(ComandoLogica comandoJson)
        {
            if(comandoJson.Accion == enmAccion.FOTO && comandoJson.Operacion != string.Empty && 
                _enmMenuExento == enmMenuExento.IngresoPatente)
            {
                //Inserto la nueva foto en lugar de la anterior
                Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                {
                    panelExentos.Children.RemoveAt(0);
                    panelExentos.Children.Insert(0, Clases.Utiles.CargarFotoRectangulo(comandoJson.Operacion, Datos.AnchoFoto, Datos.AltoFoto, false));
                    _pantalla.ParametroAuxiliar = comandoJson.Operacion;
                }));
            }
            else if(comandoJson.CodigoStatus == enmStatus.Ok 
                && comandoJson.Accion == enmAccion.LIST_EXENTO 
                && comandoJson.Operacion != string.Empty)
            {
                try
                {
                    ListadoOpciones _listadoOpciones = Utiles.ClassUtiles.ExtraerObjetoJson<ListadoOpciones>(comandoJson.Operacion);
                    _patenteExenta = Utiles.ClassUtiles.ExtraerObjetoJson<PatenteExenta>(comandoJson.Operacion);

                    int nroOpcion = 1;

                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        foreach (Opcion opcion in _listadoOpciones.ListaOpciones)
                        {
                            _listaOpciones.Items.Add(nroOpcion.ToString() + " :\t" + opcion.Descripcion);
                            nroOpcion++;
                        }

                        _cantidadOpcionesMenu = _listadoOpciones.ListaOpciones.Count;
                        _OpcionElegida = 1;
                        lblMenuOpcion.Content = _OpcionElegida.ToString();
                        _listaOpciones.SelectedIndex = 0;
                        SeleccionarItem(_OpcionElegida - 1, _colorItemSeleccionado);
                    }));
                }
                catch (JsonException jsonEx)
                {
                    _logger.Debug("VentanaExento:RecibirDatosLogica() JsonException: {0}", jsonEx.Message.ToString());
                    _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
                }
                catch (Exception ex)
                {
                    _logger.Debug("VentanaExento:RecibirDatosLogica() Exception: {0}", ex.Message.ToString());
                    _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
                }
            }
            else if (comandoJson.CodigoStatus == enmStatus.Abortada && comandoJson.Accion == enmAccion.EXENTO)
            {
                //Logica indica que se debe cerrar la ventana
                Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                {
                    _pantalla.CargarSubVentana(enmSubVentana.Principal);
                }));
            }
        }

        #region Metodo de carga de textboxes de datos
        /// <summary>
        /// 
        /// </summary>
        /// <param name="datos"></param>
        private void CargarDatosEnControles(string datos)
        {
            try
            {
                _listadoOpciones = Utiles.ClassUtiles.ExtraerObjetoJson<ListadoOpciones>(datos);

                int nroOpcion = 1;

                Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                {
                    foreach (Opcion opcion in _listadoOpciones.ListaOpciones)
                    {
                        _listaOpciones?.Items.Add(nroOpcion.ToString() + " :\t" + opcion.Descripcion);
                        nroOpcion++;
                    }

                    _cantidadOpcionesMenu = _listadoOpciones.ListaOpciones.Count;
                    _OpcionElegida = 1;
                    lblMenuOpcion.Content = _OpcionElegida.ToString();
                    _listaOpciones.SelectedIndex = 0;
                    SeleccionarItem(_OpcionElegida - 1, _colorItemSeleccionado);
                }));
            }
            catch (JsonException jsonEx)
            {
                _logger.Debug("VentanaExento:CargarDatosEnControles() JsonException: {0}", jsonEx.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
            catch (Exception ex)
            {
                _logger.Debug("VentanaExento:CargarDatosEnControles() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
        }
        #endregion



        /// <summary>
        /// Este metodo envia un json formateado en string hacia el socket
        /// </summary>
        /// <param name="status"></param>
        /// <param name="Accion"></param>
        /// <param name="Operacion"></param>
        public void EnviarDatosALogica(enmStatus status, enmAccion Accion, string Operacion)
        {
            try
            {
                _pantalla.EnviarDatosALogica(status, Accion, Operacion);
            }
            catch (Exception ex)
            {
                _logger.Debug("VentanaExento:EnviarDatosALogica() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al intentar enviar datos a logica.");
            }
        }
        #endregion

        #region Metodo de procesamiento de tecla recibida
        /// <summary>
        /// A este metodo llegan las teclas recibidas desde la pantalla principal
        /// </summary>
        /// <param name="tecla"></param>
        public void ProcesarTecla(Key tecla)
        {
            List<DatoVia> listaDV = new List<DatoVia>();
            if (_enmMenuExento == enmMenuExento.IngresoPatente)
            {
                if (Teclado.IsConfirmationKey(tecla))
                {
                    //Compruebo si el formato de la patente es correcto
                    _patenteIngresada = _txtPatente.Text;
                    if (Clases.Utiles.EsPatenteValida(_patenteIngresada))
                    {
                        Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                        {
                            _enmMenuExento = enmMenuExento.ListaExentos;
                            DibujarPantalla();
                            //Envio solicitud de lista de exentos con la patente ingresada
                            Vehiculo vehiculo = new Vehiculo();
                            vehiculo.Patente = _patenteIngresada;
                            Utiles.ClassUtiles.InsertarDatoVia(vehiculo, ref listaDV);

                            Opcion opcion = _listadoOpciones.ListaOpciones[_OpcionElegida - 1];

                            Utiles.ClassUtiles.InsertarDatoVia(opcion, ref listaDV);

                            EnviarDatosALogica(enmStatus.Ok, enmAccion.LIST_EXENTO, Newtonsoft.Json.JsonConvert.SerializeObject(listaDV, jsonSerializerSettings));
                        }));
                    }
                    else
                    {
                        //Si se ingreso la patente incorrecta, aviso al usuario y borro los datos
                        //ingresados
                        _pantalla.MensajeDescripcion(msgFormatoPatenteErr);
                        _patenteIngresada = string.Empty;
                        //No borro los datos ingresados para que el usuario pueda editar
                        //_txtPatente.Text = string.Empty;
                    }
                }
                else if (Teclado.IsFunctionKey(tecla, "Foto"))
                {
                    //Solicito una nueva foto a logica
                    EnviarDatosALogica(enmStatus.Tecla, enmAccion.FOTO, string.Empty);
                }
                else if (Teclado.IsFunctionKey(tecla, "ZoomFoto"))
                {
                    //Inserto la foto con zoom en lugar de la anterior
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        if (_bZoomFoto) _bZoomFoto = false;
                        else _bZoomFoto = true;
                        panelExentos.Children.RemoveAt(0);
                        panelExentos.Children.Insert(0, Clases.Utiles.CargarFotoRectangulo(_pantalla.ParametroAuxiliar, Datos.AnchoFoto, Datos.AltoFoto, _bZoomFoto));
                    }));
                }
                else if (Teclado.IsEscapeKey(tecla))
                {
                    _txtPatente.Text = string.Empty;
                    Exento vehiculoExento = new Exento();

                    Utiles.ClassUtiles.InsertarDatoVia(vehiculoExento, ref listaDV);
                    EnviarDatosALogica(enmStatus.Abortada, enmAccion.EXENTO, JsonConvert.SerializeObject(listaDV, jsonSerializerSettings));
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        _pantalla.CargarSubVentana(enmSubVentana.Principal);
                    }));
                }
                else if (Teclado.IsBackspaceKey(tecla))
                {
                    if (_txtPatente.Text.Length > 0)
                        _txtPatente.Text = _txtPatente.Text.Remove(_txtPatente.Text.Length - 1);
                }
                else
                {
                    _txtPatente.Text += Teclado.GetKeyAlphaNumericValue(tecla);
                }
            }
            else if (_enmMenuExento == enmMenuExento.ListaExentos)
            {
                if (Teclado.IsEscapeKey(tecla))
                {
                    if (_pantalla.ParametroAuxiliar == string.Empty)
                    {
                        Exento vehiculoExento = new Exento();
                        Utiles.ClassUtiles.InsertarDatoVia(vehiculoExento, ref listaDV);
                        EnviarDatosALogica(enmStatus.Abortada, enmAccion.EXENTO, JsonConvert.SerializeObject(listaDV, jsonSerializerSettings));
                        Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                        {
                            _pantalla.CargarSubVentana(enmSubVentana.Principal);
                        }));
                    }
                    else
                    {
                        _enmMenuExento = enmMenuExento.IngresoPatente;
                        DibujarPantalla();
                        _txtPatente.Text = _patenteIngresada;
                    }
                }
                else if (Teclado.IsUpKey(tecla))
                {
                    if (_OpcionElegida > 1)
                    {
                        _listaOpciones.Dispatcher.BeginInvoke((Action)(() =>
                        {
                            _OpcionElegida--;
                            SeleccionarItem(_OpcionElegida - 1, _colorItemSeleccionado);
                        }));
                        lblMenuOpcion.Dispatcher.BeginInvoke((Action)(() => lblMenuOpcion.Content = _OpcionElegida.ToString()));
                    }
                }
                else if (Teclado.IsDownKey(tecla))
                {
                    if (_OpcionElegida < _cantidadOpcionesMenu)
                    {
                        _listaOpciones.Dispatcher.BeginInvoke((Action)(() =>
                        {
                            _OpcionElegida++;
                            SeleccionarItem(_OpcionElegida - 1, _colorItemSeleccionado);
                        }));
                        lblMenuOpcion.Dispatcher.BeginInvoke((Action)(() => lblMenuOpcion.Content = _OpcionElegida.ToString()));
                    }
                }
                else if (Teclado.IsNumericKey(tecla))
                {
                    int teclaNumerica = Teclado.GetKeyNumericValue(tecla);
                    //Si solamente tengo 9 opciones para mostrar en la lista
                    if (_cantidadOpcionesMenu < 10)
                    {
                        _OpcionElegida = teclaNumerica;
                        if (teclaNumerica >= 1 && teclaNumerica <= _cantidadOpcionesMenu)
                        {
                            lblMenuOpcion.Dispatcher.BeginInvoke((Action)(() => lblMenuOpcion.Content = _OpcionElegida.ToString()));
                            _listaOpciones.Dispatcher.BeginInvoke((Action)(() =>
                            {
                                SeleccionarItem(_OpcionElegida - 1, _colorItemSeleccionado);
                            }));
                        }
                    }
                    else
                    {
                        if (!_bPrimerDigito)
                        {
                            if (teclaNumerica >= 0 && teclaNumerica <= _cantidadOpcionesMenu / 10)
                            {
                                lblMenuOpcion.Dispatcher.BeginInvoke((Action)(() => lblMenuOpcion.Content = (_OpcionElegida / 10).ToString() + "_"));
                                _OpcionElegida = teclaNumerica * 10;
                                _bPrimerDigito = true;
                            }
                            else
                                lblMenuOpcion.Dispatcher.BeginInvoke((Action)(() => lblMenuOpcion.Content = string.Empty));
                        }
                        else
                        {
                            if (_OpcionElegida + teclaNumerica <= _cantidadOpcionesMenu)
                            {
                                _OpcionElegida += teclaNumerica;
                                lblMenuOpcion.Dispatcher.BeginInvoke((Action)(() => lblMenuOpcion.Content = _OpcionElegida.ToString()));
                                _listaOpciones.Dispatcher.BeginInvoke((Action)(() =>
                                {
                                    SeleccionarItem(_OpcionElegida - 1, _colorItemSeleccionado);
                                }));
                            }
                            else
                                lblMenuOpcion.Dispatcher.BeginInvoke((Action)(() => lblMenuOpcion.Content = string.Empty));
                            _bPrimerDigito = false;
                        }
                    }
                }
                else if (Teclado.IsConfirmationKey(tecla))
                {
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        Opcion opcion = _listadoOpciones.ListaOpciones[_OpcionElegida - 1];

                        Utiles.ClassUtiles.InsertarDatoVia(opcion, ref listaDV);
                        Utiles.ClassUtiles.InsertarDatoVia(_patenteExenta, ref listaDV);

                        EnviarDatosALogica(enmStatus.Ok, enmAccion.EXENTO, JsonConvert.SerializeObject(listaDV, jsonSerializerSettings));
                        _pantalla.CargarSubVentana(enmSubVentana.Principal);
                    }));
                }
            }
        }
        #endregion

        #region Metodo que selecciona un item del listbox
        /// <summary>
        /// Metodo que resalta la opcion seleccionada
        /// </summary>
        /// <param name="posicion"></param>
        /// <param name="background"></param>
        private void SeleccionarItem(int posicion, string background)
        {
            ListBoxItem item = new ListBoxItem();

            for (int i = 0; i < _listaOpciones.Items.Count; i++)
            {
                item = _listaOpciones.ItemContainerGenerator.ContainerFromIndex(i) as ListBoxItem;
                if (item != null)
                {
                    item.Background = null;
                    if (i == posicion)
                    {
                        item.Background = (Brush)new BrushConverter().ConvertFrom(background);
                        _ItemSeleccionado = item;
                        _listaOpciones.SelectedIndex = posicion;
                        _listaOpciones.SelectedItem = _ItemSeleccionado;
                        _listaOpciones.UpdateLayout();
                        _listaOpciones.ScrollIntoView(_listaOpciones.SelectedItem);
                        _listaOpciones.UpdateLayout();
                    }
                }
            }
        }
        #endregion
    }
}
