﻿using System;
using System.Windows;
using ModuloPantallaTeclado.Interfaces;
using ModuloPantallaTeclado.Clases;
using System.Collections.Specialized;
using System.Configuration;
using System.Windows.Controls;
using System.Windows.Media;
using System.Collections.Generic;
using Newtonsoft.Json;
using Entidades.Comunicacion;
using Entidades;
using Entidades.Logica;
using System.Windows.Input;

namespace ModuloPantallaTeclado.Sub_Ventanas
{
    public enum enmMenuVenta { SeleccionMonto, IngresoMonto, ConfirmaMonto }

    /// <summary>
    /// Lógica de interacción para VentanaVenta.xaml
    /// </summary>
    public partial class VentanaVenta : Window, ISubVentana
    {
        #region Variables y propiedades de clase
        private IPantalla _pantalla = null;
        private int _cantidadOpcionesMenu;
        private int _OpcionElegida;
        private enmMenuVenta _enmMenuVenta;
        private string _colorItemSeleccionado;
        private ListBoxItem _ItemSeleccionado;
        private bool _bPrimerDigito = false;
        private IList<string> _listaOpcionesMenu = new List<string>();
        private ListBox _listBoxMenu;
        private TextBox _txtBoxMontoIngresado;
        private Label _lblIngreseMonto;
        private int _caracteresSimboloMoneda;
        private string _nroTag;
        private bool _permiteIngresarOtroMonto = false;
        private NLog.Logger _logger = NLog.LogManager.GetLogger("logfile");
        JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings
        {
            NullValueHandling = NullValueHandling.Ignore,
            MissingMemberHandling = MissingMemberHandling.Ignore
        };
        #endregion

        #region Mensajes de descripcion
        const string msgSeleccionoMonto = "Seleccione el monto a recargar y presione [ENTER], [ESC] para volver.";
        const string msgIngreseMonto = "Ingrese el monto a recargar y confirme con [ENTER], [ESC] para volver.";
        const string msgConfirmeMonto = "Confirme el monto a recargar con [ENTER], [ESC] para volver.";
        #endregion

        #region Constructor de la clase
        public VentanaVenta(IPantalla padre)
        {
            InitializeComponent();
            _pantalla = padre;
            NameValueCollection color = (NameValueCollection)ConfigurationManager.GetSection("color");
            _colorItemSeleccionado = color["itemSeleccionado"];
            _listaOpcionesMenu.Clear();
        }
        #endregion

        #region Evento de carga de la ventana
        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            _bPrimerDigito = false;
            _enmMenuVenta = enmMenuVenta.SeleccionMonto;
            if (_pantalla.ParametroAuxiliar != string.Empty)
            {
                //_permiteIngresarOtroMonto = Utiles.ClassUtiles.ExtraerObjetoJson<MontoRetiro>(_pantalla.ParametroAuxiliar).AceptaMontoPersonalizado;
                //Cargo la lista al control
                DibujarMenuOpciones();
            }
        }
        #endregion

        #region Metodo para obtener el control desde el padre
        /// <summary>
        /// Obtiene el control que se quiere agregar a la ventana principal
        /// <returns>FrameworkElement</returns>
        /// </summary>
        public FrameworkElement ObtenerControlPrincipal()
        {
            FrameworkElement control = (FrameworkElement)borderVentanaVenta.Child;
            borderVentanaVenta.Child = null;
            Close();
            return control;
        }
        #endregion      

        #region Metodo que carga la lista de opciones al listbox
        private void DibujarMenuOpciones()
        {
            Vehiculo vehiculo = Utiles.ClassUtiles.ExtraerObjetoJson<Vehiculo>(_pantalla.ParametroAuxiliar);
            ListadoOpciones listadoOpciones = Utiles.ClassUtiles.ExtraerObjetoJson<ListadoOpciones>(_pantalla.ParametroAuxiliar);

            Application.Current.Dispatcher.BeginInvoke((Action)(() =>
            {
                txtBoxPatente.Text = vehiculo.Patente;
                txtBoxColor.Text = vehiculo.InfoTag.Color;
                txtBoxCategoria.Text = vehiculo.Categoria.ToString();
                txtBoxMarca.Text = vehiculo.InfoTag.Marca;
                txtBoxModelo.Text = vehiculo.InfoTag.Modelo;
                txtBoxNombre.Text = vehiculo.InfoTag.NombreCuenta;
                txtBoxNumeroTag.Text = vehiculo.InfoTag.NumeroTag;
                _nroTag = vehiculo.InfoTag.NumeroTag;

                int nroOpcion = 1;
                foreach (Opcion opcion in listadoOpciones.ListaOpciones)
                {
                    _listaOpcionesMenu.Add(nroOpcion.ToString("00") + " :\t" + opcion.Descripcion);
                    nroOpcion++;
                }

                //Agrego el item de ingreso de monto
                _listaOpcionesMenu.Add(nroOpcion.ToString("00") + " :\tIngresar Monto");
                _cantidadOpcionesMenu = _listaOpcionesMenu.Count;
            }));

            // Chequeo si permite ingrear otros valores de importe por fuera de lista
            foreach (Opcion opcion in listadoOpciones.ListaOpciones)
            {
                if(opcion.Objeto == "*")
                {
                    _permiteIngresarOtroMonto = true;
                    break;
                }
            }

            listBoxMenu.ItemsSource = _listaOpcionesMenu;
            _OpcionElegida = 1;
            listBoxMenu.SelectedIndex = 0;
            SeleccionarItem(_OpcionElegida - 1, _colorItemSeleccionado);
            _pantalla.MensajeDescripcion(msgSeleccionoMonto);
            _listBoxMenu = listBoxMenu;
            lblMenuOpcion.Content = _OpcionElegida.ToString();
        }
        #endregion

        #region Metodos de comunicacion con el modulo de logica
        /// <summary>
        /// Este metodo recibe el string JSON que llega desde el socket
        /// </summary>
        /// <param name="comandoJson"></param>
        public void RecibirDatosLogica(ComandoLogica comandoJson)
        {
            if (comandoJson.CodigoStatus == enmStatus.Ok
                && comandoJson.Accion == enmAccion.ESTADO)
            {
                Causa causa = Utiles.ClassUtiles.ExtraerObjetoJson<Causa>(comandoJson.Operacion);

                if (causa.Codigo == eCausas.AperturaTurno
                    || causa.Codigo == eCausas.CausaCierre
                    || causa.Codigo == eCausas.Salidavehiculo)
                {
                    //Logica indica que se debe cerrar la ventana
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        _pantalla.CargarSubVentana(enmSubVentana.Principal);
                    }));
                }
            }
        }

        /// <summary>
        /// Este metodo envia un json formateado en string hacia el socket
        /// </summary>
        /// <param name="status"></param>
        /// <param name="Accion"></param>
        /// <param name="Operacion"></param>
        public void EnviarDatosALogica(enmStatus status, enmAccion Accion, string Operacion)
        {
            try
            {
                _pantalla.EnviarDatosALogica(status, Accion, Operacion);
            }
            catch (Exception ex)
            {
                _logger.Debug("VentanaVenta:EnviarDatosALogica() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al intentar enviar datos a logica.");
            }
        }
        #endregion

        #region Metodo de procesamiento de tecla recibida
        /// <summary>
        /// A este metodo llegan las teclas recibidas desde la pantalla principal
        /// </summary>
        /// <param name="tecla"></param>
        public void ProcesarTecla(Key tecla)
        {
            List<DatoVia> listaDV = new List<DatoVia>();
            if (Teclado.IsEscapeKey(tecla))
            {
                if (_enmMenuVenta == enmMenuVenta.SeleccionMonto)
                {
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        EnviarDatosALogica(enmStatus.Abortada, enmAccion.RECARGA,String.Empty );
                        _pantalla.CargarSubVentana(enmSubVentana.Principal);
                    }));
                }
                else if (_enmMenuVenta == enmMenuVenta.IngresoMonto)
                {
                    _enmMenuVenta = enmMenuVenta.SeleccionMonto;
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        //Borro el listbox de menu
                        panelMenu.Children.Clear();
                        _pantalla.MensajeDescripcion(msgSeleccionoMonto);
                        DibujarMenuOpciones();
                        panelMenu.Children.Add(_listBoxMenu);
                        lblMenuOpcionShow.Visibility = Visibility.Visible;
                        lblMenuOpcion.Visibility = Visibility.Visible;
                    }));
                }
                else if (_enmMenuVenta == enmMenuVenta.ConfirmaMonto)
                {
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        _enmMenuVenta = enmMenuVenta.IngresoMonto;
                        _pantalla.MensajeDescripcion(msgIngreseMonto);
                    }));
                }
            }
            else if (Teclado.IsUpKey(tecla))
            {
                if (_enmMenuVenta == enmMenuVenta.SeleccionMonto)
                {
                    if (_OpcionElegida > 1)
                    {
                        listBoxMenu.Dispatcher.BeginInvoke((Action)(() =>
                        {
                            _OpcionElegida--;
                            SeleccionarItem(_OpcionElegida - 1, _colorItemSeleccionado);
                        }));
                        lblMenuOpcion.Dispatcher.BeginInvoke((Action)(() => lblMenuOpcion.Content = _OpcionElegida.ToString()));
                    }
                }
            }
            else if (Teclado.IsDownKey(tecla))
            {
                if (_enmMenuVenta == enmMenuVenta.SeleccionMonto)
                {
                    if (_OpcionElegida < _cantidadOpcionesMenu)
                    {
                        listBoxMenu.Dispatcher.BeginInvoke((Action)(() =>
                        {
                            _OpcionElegida++;
                            SeleccionarItem(_OpcionElegida - 1, _colorItemSeleccionado);
                        }));
                        lblMenuOpcion.Dispatcher.BeginInvoke((Action)(() => lblMenuOpcion.Content = _OpcionElegida.ToString()));
                    }
                }
            }
            else if (Teclado.IsNumericKey(tecla))
            {
                int teclaNumerica = (int)Teclado.GetKeyNumericValue(tecla);
                if (_enmMenuVenta == enmMenuVenta.SeleccionMonto)
                {
                    //Si solamente tengo 9 opciones para mostrar en la lista
                    if (_cantidadOpcionesMenu < 10)
                    {
                        _OpcionElegida = teclaNumerica;
                        if (teclaNumerica >= 1 && teclaNumerica <= _cantidadOpcionesMenu)
                        {
                            lblMenuOpcion.Dispatcher.BeginInvoke((Action)(() => lblMenuOpcion.Content = _OpcionElegida.ToString()));
                            listBoxMenu.Dispatcher.BeginInvoke((Action)(() =>
                            {
                                SeleccionarItem(_OpcionElegida - 1, _colorItemSeleccionado);
                            }));
                        }
                    }
                    else
                    {
                        if (!_bPrimerDigito)
                        {
                            if (teclaNumerica >= 0 && teclaNumerica <= _cantidadOpcionesMenu / 10)
                            {
                                lblMenuOpcion.Dispatcher.BeginInvoke((Action)(() => lblMenuOpcion.Content = (_OpcionElegida / 10).ToString() + "_"));
                                _OpcionElegida = teclaNumerica * 10;
                                _bPrimerDigito = true;
                            }
                            else
                                lblMenuOpcion.Dispatcher.BeginInvoke((Action)(() => lblMenuOpcion.Content = string.Empty));
                        }
                        else
                        {
                            if (_OpcionElegida + teclaNumerica <= _cantidadOpcionesMenu)
                            {
                                _OpcionElegida += teclaNumerica;
                                lblMenuOpcion.Dispatcher.BeginInvoke((Action)(() => lblMenuOpcion.Content = _OpcionElegida.ToString()));
                                listBoxMenu.Dispatcher.BeginInvoke((Action)(() =>
                                {
                                    SeleccionarItem(_OpcionElegida - 1, _colorItemSeleccionado);
                                }));
                            }
                            else
                                lblMenuOpcion.Dispatcher.BeginInvoke((Action)(() => lblMenuOpcion.Content = string.Empty));
                            _bPrimerDigito = false;
                        }
                    }
                }
                else if (_enmMenuVenta == enmMenuVenta.IngresoMonto)
                {
                    _txtBoxMontoIngresado.Text += Teclado.GetKeyNumericValue(tecla);
                }
            }
            else if (Teclado.IsBackspaceKey(tecla))
            {
                if (_enmMenuVenta == enmMenuVenta.IngresoMonto)
                {
                    if (_txtBoxMontoIngresado.Text.Length > _caracteresSimboloMoneda)
                        _txtBoxMontoIngresado.Text = _txtBoxMontoIngresado.Text.Remove(_txtBoxMontoIngresado.Text.Length - 1);
                }
            }
            else if (Teclado.IsConfirmationKey(tecla))
            {
                if (_enmMenuVenta == enmMenuVenta.SeleccionMonto)
                {
                    if (_permiteIngresarOtroMonto && _OpcionElegida == _cantidadOpcionesMenu-1 )
                    {
                        _enmMenuVenta = enmMenuVenta.IngresoMonto;
                        Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                        {
                            //Borro el listbox de menu
                            panelMenu.Children.Clear();
                            _pantalla.MensajeDescripcion(msgIngreseMonto);
                            //Oculto la etiqueta de Opcion y elegida y el textbox
                            lblMenuOpcionShow.Visibility = Visibility.Hidden;
                            lblMenuOpcion.Visibility = Visibility.Hidden;
                            //Dibujo el label de "Ingrese el monto:"
                            _lblIngreseMonto = new Label();
                            _lblIngreseMonto.Height = 32;
                            _lblIngreseMonto.FontSize = 20;
                            _lblIngreseMonto.VerticalContentAlignment = VerticalAlignment.Center;
                            _lblIngreseMonto.HorizontalContentAlignment = HorizontalAlignment.Center;
                            _lblIngreseMonto.Width = 250;
                            _lblIngreseMonto.Content = "Ingrese el monto:";
                            _lblIngreseMonto.FontWeight = FontWeights.Bold;
                            _lblIngreseMonto.FontFamily = new FontFamily("Arial");
                            _lblIngreseMonto.Foreground = new SolidColorBrush(Colors.White);
                            _lblIngreseMonto.Margin = new Thickness(0, 70, 0, 0);
                            //Lo agrego al panel
                            panelMenu.Children.Add(_lblIngreseMonto);

                            //Dibujo el textbox de ingreso de monto
                            _txtBoxMontoIngresado = new TextBox();
                            _txtBoxMontoIngresado.Height = 32;
                            _txtBoxMontoIngresado.FontSize = 27;
                            _txtBoxMontoIngresado.Margin = new Thickness(0, 70, 0, 0);
                            _txtBoxMontoIngresado.VerticalContentAlignment = VerticalAlignment.Center;
                            _txtBoxMontoIngresado.HorizontalContentAlignment = HorizontalAlignment.Center;
                            _txtBoxMontoIngresado.FontWeight = FontWeights.Bold;
                            _txtBoxMontoIngresado.Width = 200;
                            _txtBoxMontoIngresado.Text = Datos.GetSimboloMonedaReferencia();
                            _caracteresSimboloMoneda = _txtBoxMontoIngresado.Text.Length;
                            //Lo agrego al panel
                            panelMenu.Children.Add(_txtBoxMontoIngresado);
                        }));

                    }
                    else if (_OpcionElegida < _cantidadOpcionesMenu)
                    {
                        Venta recarga = new Venta(txtBoxPatente.Text, _nroTag, _OpcionElegida - 1);
                        Utiles.ClassUtiles.InsertarDatoVia(recarga, ref listaDV);
                        EnviarDatosALogica(enmStatus.Ok,enmAccion.RECARGA, JsonConvert.SerializeObject(Newtonsoft.Json.JsonConvert.SerializeObject(listaDV, jsonSerializerSettings)));
                        _pantalla.CargarSubVentana(enmSubVentana.Principal);
                    }
                }
                else if (_permiteIngresarOtroMonto && _enmMenuVenta == enmMenuVenta.IngresoMonto)
                {
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        if (_txtBoxMontoIngresado.Text.Length > _caracteresSimboloMoneda)
                        {
                            _enmMenuVenta = enmMenuVenta.ConfirmaMonto;
                            _pantalla.MensajeDescripcion(msgConfirmeMonto);
                        }
                    }));
                }
                else if (_enmMenuVenta == enmMenuVenta.ConfirmaMonto)
                {
                    Venta recarga = new Venta(txtBoxPatente.Text, _nroTag, long.Parse(_txtBoxMontoIngresado.Text.Remove(0, _caracteresSimboloMoneda)));
                    Utiles.ClassUtiles.InsertarDatoVia(recarga, ref listaDV);
                    EnviarDatosALogica(enmStatus.Ok, enmAccion.RECARGA, JsonConvert.SerializeObject(listaDV, jsonSerializerSettings));
                    _pantalla.CargarSubVentana(enmSubVentana.Principal);
                }
            }
        }
        #endregion

        #region Metodo que selecciona un item del listbox
        /// <summary>
        /// Metodo que resalta la opcion seleccionada
        /// </summary>
        /// <param name="posicion"></param>
        /// <param name="background"></param>
        private void SeleccionarItem(int posicion, string background)
        {
            ListBoxItem item = new ListBoxItem();

            for (int i = 0; i < listBoxMenu.Items.Count; i++)
            {
                item = listBoxMenu.ItemContainerGenerator.ContainerFromIndex(i) as ListBoxItem;
                if (item != null)
                {
                    item.Background = null;
                    if (i == posicion)
                    {
                        item.Background = (Brush)new BrushConverter().ConvertFrom(background);
                        _ItemSeleccionado = item;
                        listBoxMenu.SelectedIndex = posicion;
                        listBoxMenu.SelectedItem = _ItemSeleccionado;
                        listBoxMenu.UpdateLayout();
                        listBoxMenu.ScrollIntoView(listBoxMenu.SelectedItem);
                        listBoxMenu.UpdateLayout();
                    }
                }
            }
        }
        #endregion
    }
}
