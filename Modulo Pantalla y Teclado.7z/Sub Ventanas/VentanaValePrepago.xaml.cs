﻿using System;
using System.Windows;
using ModuloPantallaTeclado.Interfaces;
using ModuloPantallaTeclado.Clases;
using Entidades.Comunicacion;
using Entidades;
using Entidades.Logica;
using System.Collections.Generic;
using Newtonsoft.Json;
using System.Windows.Input;

namespace ModuloPantallaTeclado.Sub_Ventanas
{
    public enum enmValePrepago { IngresoVale, Confirmacion }

    /// <summary>
    /// Lógica de interacción para VentanaValePrepago.xaml
    /// </summary>
    public partial class VentanaValePrepago : Window, ISubVentana
    {
        #region Variables y propiedades de clase
        private IPantalla _pantalla = null;
        private enmValePrepago _enmValePrepago;
        private string _nroVale;
        private NLog.Logger _logger = NLog.LogManager.GetLogger("logfile");
        JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings
        {
            NullValueHandling = NullValueHandling.Ignore,
            MissingMemberHandling = MissingMemberHandling.Ignore
        };
        #endregion

        #region Mensajes de descripcion
        const string msgIngresoNroVale = "Ingrese el número de vale y presione [ENTER] para confirmar, [ESC] para salir.";
        const string msgConfirme = "Confirme el numero con [ENTER], [ESC] para salir.";
        #endregion

        #region Constructor de la clase
        /// <summary>
        /// Constructor de la clase
        /// </summary>
        /// <param name="padre"></param>
        public VentanaValePrepago(IPantalla padre)
        {
            InitializeComponent();
            _pantalla = padre;
        }
        #endregion

        #region Evento de carga de la ventana
        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            _enmValePrepago = enmValePrepago.IngresoVale;
            Application.Current.Dispatcher.BeginInvoke((Action)(() =>
            {
                _pantalla.MensajeDescripcion(msgIngresoNroVale);
            }));
            }
        #endregion

        #region Metodo para obtener el control desde el padre
        /// <summary>
        /// Obtiene el control que se quiere agregar a la ventana principal
        /// <returns>FrameworkElement</returns>
        /// </summary>
        public FrameworkElement ObtenerControlPrincipal()
        {
            FrameworkElement control = (FrameworkElement)borderValePrepago.Child;
            borderValePrepago.Child = null;
            Close();
            return control;
        }
        #endregion

        #region Metodos de comunicacion con el modulo de logica
        /// <summary>
        /// Este metodo recibe el string JSON que llega desde el socket
        /// </summary>
        /// <param name="comandoJson"></param>
        public void RecibirDatosLogica(ComandoLogica comandoJson)
        {
            try
            {

            }
            catch
            {

            }
        }

        /// <summary>
        /// Este metodo envia un json formateado en string hacia el socket
        /// </summary>
        /// <param name="status"></param>
        /// <param name="Accion"></param>
        /// <param name="Operacion"></param>
        public void EnviarDatosALogica(enmStatus status, enmAccion Accion, string Operacion)
        {
            try
            {
                _pantalla.EnviarDatosALogica(status, Accion, Operacion);
            }
            catch (Exception ex)
            {
                _logger.Debug("VentanaValePrepago:EnviarDatosALogica() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al intentar enviar datos a logica.");
            }
        }
        #endregion

        #region Metodo de procesamiento de tecla recibida
        /// <summary>
        /// A este metodo llegan las teclas recibidas desde la pantalla principal
        /// </summary>
        /// <param name="tecla"></param>
        public void ProcesarTecla(Key tecla)
        {
            List<DatoVia> listaDV = new List<DatoVia>();
            if (Teclado.IsEscapeKey(tecla))
            {
                Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                {
                    _pantalla.CargarSubVentana(enmSubVentana.Principal);
                    txtBoxNroVale.Text = string.Empty;
                    EnviarDatosALogica(enmStatus.Abortada, enmAccion.VALE_PREPAGO, string.Empty);
                }));
            }
            else if (Teclado.IsConfirmationKey(tecla))
            {
                if (_enmValePrepago == enmValePrepago.IngresoVale)
                {
                    _enmValePrepago = enmValePrepago.Confirmacion;
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        _pantalla.MensajeDescripcion(msgConfirme);
                    }));
                }
                else if (_enmValePrepago == enmValePrepago.Confirmacion)
                {
                    //validar los datos ingresados aca                    
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        _pantalla.CargarSubVentana(enmSubVentana.Principal);
                        Vale vale = new Vale();
                        vale.Numero = txtBoxNroVale.Text;
                        Utiles.ClassUtiles.InsertarDatoVia(vale, ref listaDV);
                        EnviarDatosALogica(enmStatus.Ok, enmAccion.VALE_PREPAGO, Newtonsoft.Json.JsonConvert.SerializeObject(listaDV, jsonSerializerSettings));
                    }));
                }
            }
            else if (Teclado.IsBackspaceKey(tecla))
            {
                if (_enmValePrepago == enmValePrepago.IngresoVale)
                {
                    if (txtBoxNroVale.Text.Length > 0)
                        txtBoxNroVale.Text = txtBoxNroVale.Text.Remove(txtBoxNroVale.Text.Length - 1);
                }
            }
            else if (Teclado.IsNumericKey(tecla))
            {
                if (_enmValePrepago == enmValePrepago.IngresoVale)
                {
                    txtBoxNroVale.Text += Teclado.GetKeyAlphaNumericValue(tecla);
                }
            }
        }
        #endregion
    }
}
