﻿using System;
using System.Windows;
using ModuloPantallaTeclado.Interfaces;
using ModuloPantallaTeclado.Clases;
using System.Collections.Specialized;
using System.Configuration;
using Newtonsoft.Json;
using Entidades.Comunicacion;
using Entidades;
using System.Collections.Generic;
using System.Windows.Input;

namespace ModuloPantallaTeclado.Sub_Ventanas
{
    public enum enmCambioPassword { IngresoPassword, ReIngresoPassword, Confirmar }

    /// <summary>
    /// Lógica de interacción para VentanaCambioPassword.xaml
    /// </summary>
    public partial class VentanaCambioPassword : Window, ISubVentana
    {
        #region Variables y propiedades de clase
        private IPantalla _pantalla = null;
        private enmCambioPassword _enmCambioPassword;
        private string _password;
        private int _maximoCaracteres;
        private NameValueCollection _caracteres;
        private Login _login;
        private Causa _causa;
        private NLog.Logger _logger = NLog.LogManager.GetLogger("logfile");
        JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings
        {
            NullValueHandling = NullValueHandling.Ignore,
            MissingMemberHandling = MissingMemberHandling.Ignore
        };
        #endregion

        #region Mensajes de descripcion
        const string msgIngrese1pass = "Ingrese la contraseña nueva y presione [ENTER], [ESC] para volver.";
        const string msgIngrese2pass = "Reingrese la contraseña y presione [ENTER] para confirmar, [ESC] para volver.";
        const string msgErrorPassword = "Error: ambas contraseñas deben coincidir";
        const string msgErrorNuevoPasswordIgualActual = "Error: la nueva contraseña debe ser distinta a la actual";
        const string msgConfirmeCambio = "Confirme el cambio presionando [ENTER], [ESC] para cancelar.";
        #endregion

        #region Constructor de la clase
        public VentanaCambioPassword(IPantalla padre)
        {
            InitializeComponent();
            _pantalla = padre;
        }
        #endregion

        #region Evento de carga de la ventana
        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            _caracteres = (NameValueCollection)ConfigurationManager.GetSection("caracteres");
            _maximoCaracteres = Convert.ToInt32(_caracteres["maximoCaracteres"]);
            _enmCambioPassword = enmCambioPassword.IngresoPassword;
            try
            {
                _login = Utiles.ClassUtiles.ExtraerObjetoJson<Login>(_pantalla.ParametroAuxiliar);                
                _causa = Utiles.ClassUtiles.ExtraerObjetoJson<Causa>(_pantalla.ParametroAuxiliar);
            }
            catch (JsonException jsonEx)
            {
                _logger.Debug("CambioPassword:Grid_Loaded() JsonException: {0}", jsonEx.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
            catch (Exception ex)
            {
                _logger.Debug("CambioPassword:Grid_Loaded() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
            Application.Current.Dispatcher.BeginInvoke((Action)(() =>
            {
                _pantalla.MensajeDescripcion(msgIngrese1pass);
                lblCambioPassword.Content = _causa.Descripcion;
            }));
        }
        #endregion

        #region Metodo para obtener el control desde el padre
        /// <summary>
        /// Obtiene el control que se quiere agregar a la ventana principal
        /// <returns>FrameworkElement</returns>
        /// </summary>
        public FrameworkElement ObtenerControlPrincipal()
        {
            FrameworkElement control = (FrameworkElement)borderCambioPassword.Child;
            borderCambioPassword.Child = null;
            Close();
            return control;
        }
        #endregion

        #region Metodos de comunicacion con el modulo de logica
        /// <summary>
        /// Este metodo recibe el string JSON que llega desde el socket
        /// </summary>
        /// <param name="comandoJson"></param>
        public void RecibirDatosLogica(ComandoLogica comandoJson)
        {
            try
            {
                if (comandoJson.CodigoStatus == enmStatus.Ok
                    && comandoJson.Accion == enmAccion.ESTADO)
                {
                    Causa causa = Utiles.ClassUtiles.ExtraerObjetoJson<Causa>(comandoJson.Operacion);

                    if (causa.Codigo == eCausas.AperturaTurno
                        || causa.Codigo == eCausas.CausaCierre)
                    {
                        //Logica indica que se debe cerrar la ventana
                        Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                        {
                            _pantalla.CargarSubVentana(enmSubVentana.Principal);
                        }));
                    }
                }
            }
            catch (JsonException jsonEx)
            {
                _logger.Debug("VentanaCambioPassword:RecibirDatosLogica() JsonException: {0}", jsonEx.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
            catch (Exception ex)
            {
                _logger.Debug("VentanaCambioPassword:RecibirDatosLogica() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
        }

        /// <summary>
        /// Este metodo envia un json formateado en string hacia el socket
        /// </summary>
        /// <param name="status"></param>
        /// <param name="Accion"></param>
        /// <param name="Operacion"></param>
        public void EnviarDatosALogica(enmStatus status, enmAccion Accion, string Operacion)
        {
            try
            {
                _pantalla.EnviarDatosALogica(status,Accion, Operacion);
            }
            catch (Exception ex)
            {
                _logger.Debug("CambioPassword:EnviarDatosALogica() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al intentar enviar datos a logica.");
            }
        }
        #endregion

        #region Metodo de procesamiento de tecla recibida
        /// <summary>
        /// A este metodo llegan las teclas recibidas desde la pantalla principal
        /// </summary>
        /// <param name="tecla"></param>
        public void ProcesarTecla(Key tecla)
        {
            List<DatoVia> listaDV = new List<DatoVia>();
            if (Teclado.IsBackspaceKey(tecla))
            {
                if (_enmCambioPassword == enmCambioPassword.ReIngresoPassword)
                {
                    if (txtReingresoPassword.Password.Length > 0)
                        txtReingresoPassword.Password = txtReingresoPassword.Password.Remove(txtReingresoPassword.Password.Length - 1);
                }
                else if (_enmCambioPassword == enmCambioPassword.IngresoPassword)
                {
                    if (txtIngresoPassword.Password.Length > 0)
                        txtIngresoPassword.Password = txtIngresoPassword.Password.Remove(txtIngresoPassword.Password.Length - 1);
                }
            }
            else if (Teclado.IsConfirmationKey(tecla))
            {
                if (_enmCambioPassword == enmCambioPassword.Confirmar)
                {
                    if (txtIngresoPassword.Password == txtReingresoPassword.Password)
                    {                        
                        _password = txtIngresoPassword.Password;
                        _login.Password = Utiles.ClassUtiles.GetHashString(_login.Usuario + _password);
                        Utiles.ClassUtiles.InsertarDatoVia(_login, ref listaDV);
                        var nuevoPass = JsonConvert.SerializeObject(listaDV, jsonSerializerSettings);
                        EnviarDatosALogica(enmStatus.Ok,enmAccion.CAMBIO_PASS, nuevoPass);
                        txtIngresoPassword.Password = string.Empty;
                        txtReingresoPassword.Password = string.Empty;
                        _pantalla.CargarSubVentana(enmSubVentana.Principal);
                    }
                    else
                    {
                        _pantalla.MensajeDescripcion(msgErrorPassword);
                        txtIngresoPassword.Password = string.Empty;
                        txtReingresoPassword.Password = string.Empty;
                        _enmCambioPassword = enmCambioPassword.IngresoPassword;
                    }
                }
                else if (txtIngresoPassword.Password != string.Empty && _enmCambioPassword == enmCambioPassword.IngresoPassword)
                {
                    _password = txtIngresoPassword.Password;
                    _login.Password = Utiles.ClassUtiles.GetHashString(_login.Usuario + _password);
                    if (_login.Password == _login.PasswordViejo)
                    {
                        _logger.Debug("Password nueva igual a password vieja");
                        _password = string.Empty;
                        _login.Password = string.Empty;
                        _pantalla.MensajeDescripcion(msgErrorNuevoPasswordIgualActual);
                    }
                    else
                    {
                        _enmCambioPassword = enmCambioPassword.ReIngresoPassword;
                        _pantalla.MensajeDescripcion(msgIngrese2pass);
                    }
                }
                else if (txtReingresoPassword.Password != string.Empty && _enmCambioPassword == enmCambioPassword.ReIngresoPassword)
                {
                    _enmCambioPassword = enmCambioPassword.Confirmar;
                    _pantalla.MensajeDescripcion(msgConfirmeCambio);
                }
            }
            else if (Teclado.IsEscapeKey(tecla))
            {
                if (_enmCambioPassword == enmCambioPassword.Confirmar)
                {
                    _enmCambioPassword = enmCambioPassword.ReIngresoPassword;
                    txtReingresoPassword.Password = string.Empty;
                    _pantalla.MensajeDescripcion(msgIngrese2pass);
                }

                else if (_enmCambioPassword == enmCambioPassword.ReIngresoPassword)
                {
                    _enmCambioPassword = enmCambioPassword.IngresoPassword;
                    txtReingresoPassword.Password = string.Empty;
                    txtIngresoPassword.Password = string.Empty;
                    _pantalla.MensajeDescripcion(msgIngrese1pass);
                }

                else if (_enmCambioPassword == enmCambioPassword.IngresoPassword)
                {
                    txtIngresoPassword.Password = string.Empty;
                    txtReingresoPassword.Password = string.Empty;
                    _pantalla.CargarSubVentana(enmSubVentana.Principal);
                    EnviarDatosALogica(enmStatus.Abortada, enmAccion.CAMBIO_PASS, string.Empty);
                }
            }
            else
            {
                if (_enmCambioPassword == enmCambioPassword.IngresoPassword)
                {
                    if (Teclado.IsLowerCaseOrNumberKey(tecla))
                    {
                        if (txtIngresoPassword.Password.Length < _maximoCaracteres)
                            txtIngresoPassword.Password += Teclado.GetKeyAlphaNumericValue(tecla);
                    }
                }
                else if (_enmCambioPassword == enmCambioPassword.ReIngresoPassword)
                {
                    if (Teclado.IsLowerCaseOrNumberKey(tecla))
                    {
                        if (txtReingresoPassword.Password.Length < _maximoCaracteres)
                            txtReingresoPassword.Password += Teclado.GetKeyAlphaNumericValue(tecla);
                    }
                }
            }
        }
        #endregion

    }
}
