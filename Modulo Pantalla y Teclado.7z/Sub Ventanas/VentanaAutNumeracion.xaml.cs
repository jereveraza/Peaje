﻿using Entidades;
using Entidades.Comunicacion;
using Entidades.ComunicacionBaseDatos;
using ModuloPantallaTeclado.Clases;
using ModuloPantallaTeclado.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Input;

namespace ModuloPantallaTeclado.Sub_Ventanas
{
    /// <summary>
    /// Lógica de interacción para VentanaAutNumeracion.xaml
    /// </summary>
    public partial class VentanaAutNumeracion : Window , ISubVentana
    {
        
        #region Variables y propiedades de clase
        private IPantalla _pantalla = null;
        private Numeracion _numeracion = null;
        private Operador _operador = null;
        private NLog.Logger _logger = NLog.LogManager.GetLogger("logfile");
        JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings
        {
            NullValueHandling = NullValueHandling.Ignore,
            MissingMemberHandling = MissingMemberHandling.Ignore
        };
        #endregion

        #region Mensajes de descripcion
        const string msgConfirmaNumeracion = "Confirmar numeracion, Presione [ENTER] para confirmar, [ESC] para volver.";
        #endregion

        #region Constructor de la clase
        public VentanaAutNumeracion(IPantalla padre)
        {
            InitializeComponent();
            _pantalla = padre;
        }
        #endregion

        #region Evento de carga de la ventana
        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            Application.Current.Dispatcher.BeginInvoke((Action)(() =>
            {
                _pantalla.MensajeDescripcion(msgConfirmaNumeracion);
                
                //Si me llego la patente de logica, la muestro el textbox
                if (_pantalla.ParametroAuxiliar != string.Empty)
                {
                    CargarDatosEnControles(_pantalla.ParametroAuxiliar);
                    _pantalla.MensajeDescripcion(msgConfirmaNumeracion);
                    _operador = Utiles.ClassUtiles.ExtraerObjetoJson<Operador>(_pantalla.ParametroAuxiliar);
                }
            }));
        }
        #endregion

        #region Metodo para obtener el control desde el padre
        /// <summary>
        /// Obtiene el control que se quiere agregar a la ventana principal
        /// <returns>FrameworkElement</returns>
        /// </summary>
        public FrameworkElement ObtenerControlPrincipal()
        {
            FrameworkElement control = (FrameworkElement)borderVentanaAutNumeracion.Child;
            borderVentanaAutNumeracion.Child = null;
            Close();
            return control;
        }
        #endregion

        #region Metodo de carga de textboxes de datos
        private void CargarDatosEnControles(string datos)
        {
            try
            {
                _numeracion = Utiles.ClassUtiles.ExtraerObjetoJson<Numeracion>(datos);

                if (_numeracion != null)
                {
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        txtBoxUltimoBloque.Text = _numeracion.NumeroTurno.ToString();
                        txtBoxUltimoTransito.Text = _numeracion.NumeroTransito.ToString();
                        txtBoxUltimoTicket.Text = _numeracion.Factura;
                        txtBoxOrigenDatos.Text = _numeracion.OrigenDatos;
                    }));
                }
            }
            catch (JsonException jsonEx)
            {
                _logger.Debug("VentanaAutNumeracion:CargarDatosEnControles() JsonException: {0}", jsonEx.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
            catch (Exception ex)
            {
                _logger.Debug("VentanaAutNumeracion:CargarDatosEnControles() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
        }
        #endregion

        #region Metodos de comunicacion con el modulo de logica
        /// <summary>
        /// Este metodo recibe el string JSON que llega desde el socket
        /// </summary>
        /// <param name="comandoJson"></param>
        public void RecibirDatosLogica(ComandoLogica comandoJson)
        {
            try
            {
            }
            catch (Exception ex)
            {
                _logger.Debug("VentanaAutNumeracion:RecibirDatosLogica() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al recibir una Respuesta de logica.");
            }
        }

        /// <summary>
        /// Este metodo envia un json formateado en string hacia el socket
        /// </summary>
        /// <param name="status"></param>
        /// <param name="Accion"></param>
        /// <param name="Operacion"></param>
        public void EnviarDatosALogica(enmStatus status, enmAccion Accion, string Operacion)
        {
            try
            {
                _pantalla.EnviarDatosALogica(status, Accion, Operacion);
            }
            catch (Exception ex)
            {
                _logger.Debug("VentanaAutNumeracion:EnviarDatosALogica() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al intentar enviar datos a logica.");
            }
        }
        #endregion

        #region Metodo de procesamiento de tecla recibida
        /// <summary>
        /// A este metodo llegan las teclas recibidas desde la pantalla principal
        /// </summary>
        /// <param name="tecla"></param>
        public void ProcesarTecla(Key tecla)
        {
            List<DatoVia> listaDV = new List<DatoVia>();

            //Espero el ingreso de patente del usuario
            if (Teclado.IsConfirmationKey(tecla))
            {
                //Envio la consulta a logica y seteo el nuevo estado
                Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                {
                    Utiles.ClassUtiles.InsertarDatoVia(_numeracion, ref listaDV);
                    Utiles.ClassUtiles.InsertarDatoVia(_operador, ref listaDV);
                    EnviarDatosALogica(enmStatus.Ok, enmAccion.NUMERACION, Newtonsoft.Json.JsonConvert.SerializeObject(listaDV, jsonSerializerSettings));
                    _pantalla.CargarSubVentana(enmSubVentana.Principal);
                }));
            }
            else if (Teclado.IsEscapeKey(tecla))
            {
                EnviarDatosALogica(enmStatus.Abortada, enmAccion.NUMERACION, string.Empty);
                _pantalla.CargarSubVentana(enmSubVentana.Principal);
            }
        }
        #endregion
    }
}
