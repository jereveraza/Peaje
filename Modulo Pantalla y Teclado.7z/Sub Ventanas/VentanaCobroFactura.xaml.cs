﻿using ModuloPantallaTeclado.Interfaces;
using System;
using System.Collections.Generic;
using System.Windows;
using Entidades;
using Entidades.Comunicacion;
using Newtonsoft.Json;
using ModuloPantallaTeclado.Clases;
using Entidades.Logica;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Input;

namespace ModuloPantallaTeclado.Sub_Ventanas
{
    public enum enmMenuFactura { IngresoClave, IngresoRut, IngresoRazonSocial, IngresoNuevaRazonSocial, ConsultaDatos, SeleccionCliente, MuestroDatosClave, MuestroDatosRuc, MuestroDatosRazonSocial}

    /// <summary>
    /// Lógica de interacción para VentanaCobroFactura.xaml
    /// </summary>
    public partial class VentanaCobroFactura : Window, ISubVentana
    {
        #region Variables y propiedades de clase
        private IPantalla _pantalla = null;
        private enmMenuFactura _enmMenuFactura;
        private string _claveIngresada = string.Empty;
        private string _rucIngresado = string.Empty;
        private string _razonSocialIngresada = string.Empty;
        private InfoCliente _infoCliente = null;
        private List<InfoCliente> _listaClientes;
        private List<ClienteConIndex> _listaClientesIndex;
        private int _cantidadClientes = 0;
        private int _itemSeleccionado = 0;
        private int _paginaVisible = 0;
        private NLog.Logger _logger = NLog.LogManager.GetLogger("logfile");
        JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings
        {
            NullValueHandling = NullValueHandling.Ignore,
            MissingMemberHandling = MissingMemberHandling.Ignore
        };

        private class ClienteConIndex
        {
            public ClienteConIndex(InfoCliente client, int num, int pag)
            {
                NumeroCliente = num;
                InfoCliente = client;
                Pagina = pag;
            }
            public int NumeroCliente { get; set; }

            public int Pagina { get; set; }

            public InfoCliente InfoCliente { get; set; }
        }
        #endregion

        #region Mensajes de descripcion
        const string msgIngresoClave = "Ingrese la clave de cliente, [ENTER] para confirmar, [ESC] para volver.";
        const string msgIngresoRut = "Ingrese el Ruc, [ENTER] para confirmar, [ESC] para volver.";
        const string msgIngresoRutInvalido = "El Ruc ingresado no es valido, [ENTER] para confirmar, [ESC] para volver.";
        const string msgNuevoCliente = "Ruc no hallado. Ingrese razon social ,[ENTER] para confirmar, [ESC] para volver.";
        const string msgIngresoRazonSocial = "Ingrese la Razon Social, [ENTER] para confirmar, [ESC] para volver.";
        const string msgRazonSocialCorta = " caracteres como minimo, [ENTER] para confirmar, [ESC] para volver.";
        const string msgClienteNoHallado = "Cliente no encontrado, [ESC] para volver.";
        const string msgSeleccionCliente = "Seleccione cliente de la lista, [ESC] para volver.";
        const string msgSeleccionClienteMultiplesPaginas = "Seleccione cliente de la lista, [SPACE] Siguiente pag, [ESC] para volver.";
        const string msgConfirmaDatos = "Presione [EFECTIVO] para confirmar, [ESC] para volver.";
        const string msgSiguientePagClientes = "Pagina Siguiente...";
        const string msgConsultandoDatos = "Consultado datos..., [ESC] para volver.";
        #endregion

        #region Defines
        private const int _minimaCantidadCaracteresRazonSocialParaAutocompletar = 5;
        private const int _filasVisiblesPrimerPaginaClientes = 10;
        private const int _maxNumeroCaracteresClave = 12;
        private const int _maxNumeroCaracteresRuc = 13;
        private const int _maxNumeroCaracteresRazonSocial = 15;
        #endregion

        #region Constructor de la clase
        public VentanaCobroFactura(IPantalla padre)
        {
            InitializeComponent();
            _pantalla = padre;
        }
        #endregion

        #region Evento de carga de la ventana
        /// <summary>
        /// Funcion callback a cargarse la ventana
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            Application.Current.Dispatcher.BeginInvoke((Action)(() =>
            {
                _pantalla.MensajeDescripcion(msgIngresoClave);
                FormatearTextBox(eTextBoxVentanaFactura.Clave);
            }));
        }
        #endregion

        #region Metodo para enviar datos a logica
        /// <summary>
        /// Este metodo envia un json formateado en string hacia el socket
        /// </summary>
        /// <param name="status"></param>
        /// <param name="Accion"></param>
        /// <param name="Operacion"></param>
        public void EnviarDatosALogica(enmStatus status, enmAccion Accion, string Operacion)
        {
            try
            {
                Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                {
                    _pantalla.EnviarDatosALogica(status, Accion, Operacion);
                }));
            }
            catch(Exception e)
            {
                _logger.Error(e);
            }
        }
        #endregion

        #region Metodo para obtener el control desde el padre
        /// <summary>
        /// Obtiene el control que se quiere agregar a la ventana principal
        /// <returns>FrameworkElement</returns>
        /// </summary>
        public FrameworkElement ObtenerControlPrincipal()
        {
            FrameworkElement control = (FrameworkElement)borderVentanaCobroFactura.Child;
            borderVentanaCobroFactura.Child = null;
            Close();
            return control;
        }
        #endregion

        #region Metodo de procesamiento de tecla recibida
        /// <summary>
        /// A este metodo llegan las teclas recibidas desde la pantalla principal
        /// </summary>
        /// <param name="tecla"></param>
        public void ProcesarTecla(Key tecla)
        {
            List<DatoVia> listaDV = new List<DatoVia>();
            if (_enmMenuFactura == enmMenuFactura.IngresoClave)
            {
                if (Teclado.IsConfirmationKey(tecla))
                {
                    _claveIngresada = txtClave.Text;

                    // Si no hay input, aviso por pantalla
                    if (_claveIngresada.Length == 0)
                    {
                        _pantalla.MensajeDescripcion(msgIngresoRut);
                        _enmMenuFactura = enmMenuFactura.IngresoRut;

                        FormatearTextBox(eTextBoxVentanaFactura.Clave, false);
                        FormatearTextBox(eTextBoxVentanaFactura.Ruc);
                    }
                    else
                    {
                        EstadoFactura estadoFactura = new EstadoFactura();
                        estadoFactura.Codigo = eBusquedaFactura.BusquedaNumeroCliente;
                        Utiles.ClassUtiles.InsertarDatoVia(estadoFactura, ref listaDV);

                        InfoCliente infoCliente = new InfoCliente();
                        int nroClave;
                        int.TryParse(_claveIngresada, out nroClave);
                        infoCliente.Clave = nroClave;
                        Utiles.ClassUtiles.InsertarDatoVia(infoCliente, ref listaDV);

                        _enmMenuFactura = enmMenuFactura.ConsultaDatos;
                        _pantalla.MensajeDescripcion(msgConsultandoDatos);

                        EnviarDatosALogica(enmStatus.Ok, enmAccion.FACTURA, Newtonsoft.Json.JsonConvert.SerializeObject(listaDV, jsonSerializerSettings));
                    }
                }
                else if(Teclado.IsEscapeKey(tecla))
                {
                    _claveIngresada = txtClave.Text;

                    if (_claveIngresada.Length == 0)
                    {
                        EnviarDatosALogica(enmStatus.Abortada, enmAccion.FACTURA, string.Empty);
                        Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                        {
                            _pantalla.CargarSubVentana(enmSubVentana.Principal);
                        }));
                    }
                    else
                    {
                        CargarClaveEnControl();
                        _pantalla.MensajeDescripcion(msgIngresoClave);
                    }
                }
                else if(Teclado.IsBackspaceKey(tecla))
                {
                    if (txtClave.Text.Length > 0)
                        CargarClaveEnControl(txtClave.Text.Remove(txtClave.Text.Length - 1));
                }
                else
                {
                    if (Teclado.IsLowerCaseOrNumberKey(tecla)
				     && txtClave.Text.Length < _maxNumeroCaracteresClave)
                        CargarClaveEnControl(txtClave.Text + Teclado.GetKeyAlphaNumericValue(tecla));
                }
            }
            else if (_enmMenuFactura == enmMenuFactura.IngresoRut)
            {
                if (Teclado.IsConfirmationKey(tecla))
                {
                    _rucIngresado = txtRuc.Text;

                    if (_rucIngresado.Length == 0)
                    {
                        _enmMenuFactura = enmMenuFactura.IngresoRazonSocial;
                        _pantalla.MensajeDescripcion(msgIngresoRazonSocial);

                        FormatearTextBox(eTextBoxVentanaFactura.Ruc, false);
                        FormatearTextBox(eTextBoxVentanaFactura.RazonSocial);
                    }
                    else
                    {
                        if(Clases.Utiles.IsValidRUC(_rucIngresado))
                        {
                            Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                            {
                                EstadoFactura estadoFactura = new EstadoFactura();
                                estadoFactura.Codigo = eBusquedaFactura.BusquedaRut;
                                Utiles.ClassUtiles.InsertarDatoVia(estadoFactura, ref listaDV);

                                InfoCliente infoCliente = new InfoCliente();
                                infoCliente.Ruc = _rucIngresado;
                                Utiles.ClassUtiles.InsertarDatoVia(infoCliente, ref listaDV);

                                _enmMenuFactura = enmMenuFactura.ConsultaDatos;
                                _pantalla.MensajeDescripcion(msgConsultandoDatos);

                                EnviarDatosALogica(enmStatus.Ok, enmAccion.FACTURA, Newtonsoft.Json.JsonConvert.SerializeObject(listaDV, jsonSerializerSettings));
                            }));
                        }
                        else
                        {
                            _pantalla.MensajeDescripcion(msgIngresoRutInvalido);
                        }
                    }
                }
                else if (Teclado.IsEscapeKey(tecla))
                {
                    _rucIngresado = txtRuc.Text;

                    if (_rucIngresado.Length == 0)
                    {
                        _pantalla.MensajeDescripcion(msgIngresoClave);
                        _enmMenuFactura = enmMenuFactura.IngresoClave;
                        FormatearTextBox(eTextBoxVentanaFactura.Ruc, false);
                        FormatearTextBox(eTextBoxVentanaFactura.Clave);
                    }
                    else
                    {
                        CargarRucEnControl();
                        _pantalla.MensajeDescripcion(msgIngresoRut);
                    }
                }
                else if (Teclado.IsBackspaceKey(tecla))
                {
                    if (txtRuc.Text.Length > 0)
                        CargarRucEnControl(txtRuc.Text.Remove(txtRuc.Text.Length - 1));
                }
                else
                {
                    if(Teclado.IsNumericKey(tecla))
                    {
                        if (txtRuc.Text.Length < _maxNumeroCaracteresRuc)
                            CargarRucEnControl(txtRuc.Text + Teclado.GetKeyNumericValue(tecla));
                    }
                }
            }
            else if (_enmMenuFactura == enmMenuFactura.IngresoRazonSocial)
            {
                if (Teclado.IsConfirmationKey(tecla))
                {
                    _razonSocialIngresada = txtRazonSocial.Text;

                    if (_razonSocialIngresada.Length >= _minimaCantidadCaracteresRazonSocialParaAutocompletar)
                    {
                        Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                        {
                            EstadoFactura estadoFactura = new EstadoFactura();
                            estadoFactura.Codigo = eBusquedaFactura.BusquedaNombre;
                            Utiles.ClassUtiles.InsertarDatoVia(estadoFactura, ref listaDV);

                            InfoCliente infoCliente = new InfoCliente();
                            infoCliente.RazonSocial = _razonSocialIngresada;
                            infoCliente.Nombre = _razonSocialIngresada;
                            Utiles.ClassUtiles.InsertarDatoVia(infoCliente, ref listaDV);

                            _enmMenuFactura = enmMenuFactura.ConsultaDatos;
                            _pantalla.MensajeDescripcion(msgConsultandoDatos);

                            EnviarDatosALogica(enmStatus.Ok, enmAccion.FACTURA, Newtonsoft.Json.JsonConvert.SerializeObject(listaDV, jsonSerializerSettings));
                        }));
                    }
                    else
                    {
                        _pantalla.MensajeDescripcion(
                            string.Format("{0}{1}",
                            _minimaCantidadCaracteresRazonSocialParaAutocompletar.ToString(),
                            msgRazonSocialCorta));
                    }
                }
                else if (Teclado.IsEscapeKey(tecla))
                {
                    _razonSocialIngresada = txtRazonSocial.Text;

                    if (_razonSocialIngresada.Length == 0)
                    {
                        _enmMenuFactura = enmMenuFactura.IngresoRut;
                        _pantalla.MensajeDescripcion(msgIngresoRut);
                        FormatearTextBox(eTextBoxVentanaFactura.RazonSocial, false);
                        FormatearTextBox(eTextBoxVentanaFactura.Ruc);
                    }
                    else
                    {
                        CargarRazonSocialEnControl();
                        _pantalla.MensajeDescripcion(msgIngresoRazonSocial);
                    }
                }
                else if (Teclado.IsBackspaceKey(tecla))
                {
                    if (txtRazonSocial.Text.Length > 0)
                        CargarRazonSocialEnControl(txtRazonSocial.Text.Remove(txtRazonSocial.Text.Length - 1));
                }
                else
                {
                    if (txtRazonSocial.Text.Length < _maxNumeroCaracteresRazonSocial)
                        CargarRazonSocialEnControl(txtRazonSocial.Text + Teclado.GetKeyAlphaNumericValue(tecla));
                }
            }
            else if (_enmMenuFactura == enmMenuFactura.IngresoNuevaRazonSocial)
            {
                if (Teclado.IsConfirmationKey(tecla))
                {
                    _razonSocialIngresada = txtRazonSocial.Text;
                    _enmMenuFactura = enmMenuFactura.MuestroDatosRazonSocial;
                    _pantalla.MensajeDescripcion(msgConfirmaDatos);
                }
                else if (Teclado.IsEscapeKey(tecla))
                {
                    _razonSocialIngresada = txtRazonSocial.Text;

                    if (_razonSocialIngresada.Length == 0)
                    {
                        _enmMenuFactura = enmMenuFactura.IngresoRut;
                        _pantalla.MensajeDescripcion(msgIngresoRut);
                        FormatearTextBox(eTextBoxVentanaFactura.RazonSocial, false);
                        FormatearTextBox(eTextBoxVentanaFactura.Ruc);
                    }
                    else
                    {
                        CargarRazonSocialEnControl();
                    }
                }
                else if (Teclado.IsBackspaceKey(tecla))
                {
                    if (txtRazonSocial.Text.Length > 0)
                        CargarRazonSocialEnControl(txtRazonSocial.Text.Remove(txtRazonSocial.Text.Length - 1));
                }
                else
                {
                    if (txtRazonSocial.Text.Length < _maxNumeroCaracteresRazonSocial)
                        CargarRazonSocialEnControl(txtRazonSocial.Text + Teclado.GetKeyAlphaNumericValue(tecla));
                }
            }
            else if (_enmMenuFactura == enmMenuFactura.ConsultaDatos)
            {
                if (Teclado.IsEscapeKey(tecla))
                {
                    CargarClaveEnControl();
                    CargarRucEnControl();
                    CargarRazonSocialEnControl();

                    FormatearTextBox(eTextBoxVentanaFactura.Clave);
                    FormatearTextBox(eTextBoxVentanaFactura.RazonSocial,false);
                    FormatearTextBox(eTextBoxVentanaFactura.Ruc,false);

                    _enmMenuFactura = enmMenuFactura.IngresoClave;
                    _pantalla.MensajeDescripcion(msgIngresoClave);
                }
            }
            else if (_enmMenuFactura == enmMenuFactura.SeleccionCliente)
            {
                if (Teclado.IsEscapeKey(tecla))
                {
                    dataGridClientes.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        dataGridClientes.ItemsSource = null;
                        dataGridClientes.Items.Refresh();
                    }));
                    _enmMenuFactura = enmMenuFactura.IngresoRazonSocial;
                    _pantalla.MensajeDescripcion(msgIngresoRazonSocial);
                    FormatearTextBox(eTextBoxVentanaFactura.Opcion,false);

                    //Limpio datos
                    CargarClaveEnControl();
                    CargarRucEnControl();
                    CargarOpcionEnControl();
                }
                else if (Teclado.IsNumericKey(tecla))
                {
                    int teclaNumerica = Teclado.GetKeyNumericValue(tecla);

                    int opcion = 0;
                    int.TryParse(txtOpcion.Text,out opcion);
                    
                    if(txtOpcion.Text.Length == 1) //Tengo un solo digito cargado en textbox
                    {
                        CargarOpcionEnControl(string.Format("{0}{1}", opcion, teclaNumerica));
                    }
                    else //Tengo dos digitos cargados en textbox
                    {
                        // Borro dos digitos de texbox e ingreso nuevo digito
                        CargarOpcionEnControl(string.Format("{0}", teclaNumerica));
                    }
                }
                else if (Teclado.IsBackspaceKey(tecla))
                {
                    if (txtOpcion.Text.Length > 0)
                    {
                        CargarOpcionEnControl(txtOpcion.Text.Remove(txtOpcion.Text.Length - 1));
                    }
                }
                else if (Teclado.IsConfirmationKey(tecla))
                {
                    int opcion = 0;
                    int.TryParse(txtOpcion.Text, out opcion);

                    if (EstaEnRangoDePaginaVisible(opcion))
                    {
                        _itemSeleccionado = opcion;
                        ResaltarClienteSeleccionado(_itemSeleccionado);
                        _infoCliente = (dataGridClientes.SelectedItem as ClienteConIndex).InfoCliente;
                        _enmMenuFactura = enmMenuFactura.MuestroDatosRazonSocial;
                        _pantalla.MensajeDescripcion(msgConfirmaDatos);
                        CargarDatosEnControles(_infoCliente);
                    }
                }
                else if (Teclado.IsNextPageKey(tecla))
                {
                    CargarListaClientesEnControl(_paginaVisible+1);
                }
            }
            else if (_enmMenuFactura == enmMenuFactura.MuestroDatosClave
                  || _enmMenuFactura == enmMenuFactura.MuestroDatosRazonSocial
                  || _enmMenuFactura == enmMenuFactura.MuestroDatosRuc)
            {
                if (Teclado.IsCashKey(tecla))
                {
                    EstadoFactura estadoFactura = new EstadoFactura();

                    if(_listaClientes.Count == 0)
                    {
                        _infoCliente = new InfoCliente();

                        estadoFactura.Codigo = eBusquedaFactura.NuevoCliente;
                        _infoCliente.Ruc = _rucIngresado;
                        _infoCliente.RazonSocial = _razonSocialIngresada;
                    }
                    else
                    {
                        estadoFactura.Codigo = eBusquedaFactura.Confirma;
                    }

                    Utiles.ClassUtiles.InsertarDatoVia(_infoCliente, ref listaDV);
                    Utiles.ClassUtiles.InsertarDatoVia(estadoFactura, ref listaDV);

                    EnviarDatosALogica(enmStatus.Ok, enmAccion.FACTURA, Newtonsoft.Json.JsonConvert.SerializeObject(listaDV, jsonSerializerSettings));
                    _pantalla.CargarSubVentana(enmSubVentana.Principal);
                }
                else if (Teclado.IsEscapeKey(tecla))
                {
                    if (_enmMenuFactura == enmMenuFactura.MuestroDatosClave)
                    {
                        _enmMenuFactura = enmMenuFactura.IngresoClave;
                        _pantalla.MensajeDescripcion(msgIngresoClave);

                        //Limpio info de los textboxs
                        CargarRucEnControl();
                        CargarRazonSocialEnControl();
                    }
                    else if (_enmMenuFactura == enmMenuFactura.MuestroDatosRazonSocial)
                    {
                        if(_cantidadClientes == 1) //Vuelvo al input de razon social
                        {
                            _enmMenuFactura = enmMenuFactura.IngresoRazonSocial;
                            _pantalla.MensajeDescripcion(msgIngresoRazonSocial);

                            //Limpio info de los textboxs
                            CargarRucEnControl();
                            CargarClaveEnControl();
                            CargarOpcionEnControl();

                            FormatearTextBox(eTextBoxVentanaFactura.Opcion, false);
                            FormatearTextBox(eTextBoxVentanaFactura.RazonSocial);
                        }
                        else //Vuelvo a estado seleccion de cliente en lista
                        {
                            _enmMenuFactura = enmMenuFactura.SeleccionCliente;
                            _pantalla.MensajeDescripcion(msgSeleccionClienteMultiplesPaginas);

                            //Limpio info de los textboxs
                            CargarRucEnControl();
                            CargarClaveEnControl();
                        }
                    }
                    else if (_enmMenuFactura == enmMenuFactura.MuestroDatosRuc)
                    {
                        _enmMenuFactura = enmMenuFactura.IngresoRut;
                        _pantalla.MensajeDescripcion(msgIngresoRut);
                        CargarRazonSocialEnControl();
                        CargarClaveEnControl();
                    }
                }
            } 
        }
        #endregion

        #region Metodo de carga de textboxes de datos
        private void CargarDatosEnControles(InfoCliente infocliente = null)
        {
            try
            {
                CargarClaveEnControl(infocliente?.Clave.ToString());
                CargarRucEnControl(infocliente?.Ruc);
                CargarRazonSocialEnControl(infocliente?.RazonSocial);
            }
            catch (JsonException jsonEx)
            {
                _logger.Debug("VentanaCobroFactura:CargarDatosEnControles() JsonException: {0}", jsonEx.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
            catch (Exception ex)
            {
                _logger.Debug("VentanaCobroFactura:CargarDatosEnControles() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
        }
        #endregion

        #region Metodo de carga de textboxes de clave
        private void CargarClaveEnControl(string clave = null)
        {
            try
            {
                Application.Current.Dispatcher.Invoke((Action)(() =>
                {
                    if (clave == null)
                        txtClave.Text = string.Empty;
                    else
                        txtClave.Text = clave.ToString();
                }));
            }
            catch (JsonException jsonEx)
            {
                _logger.Debug("VentanaCobroFactura:CargarClaveEnControl() JsonException: {0}", jsonEx.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
            catch (Exception ex)
            {
                _logger.Debug("VentanaCobroFactura:CargarClaveEnControl() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
        }
        #endregion

        #region Metodo de carga de textboxes de ruc
        private void CargarRucEnControl(string ruc = null)
        {
            try
            {
                Application.Current.Dispatcher.Invoke((Action)(() =>
                {
                    if (ruc == null)
                        txtRuc.Text = string.Empty;
                    else
                        txtRuc.Text = ruc;
                }));
            }
            catch (JsonException jsonEx)
            {
                _logger.Debug("VentanaCobroFactura:CargarRucEnControl() JsonException: {0}", jsonEx.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
            catch (Exception ex)
            {
                _logger.Debug("VentanaCobroFactura:CargarRucEnControl() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
        }
        #endregion

        #region Metodo de carga de textboxes de RazonSocial
        private void CargarRazonSocialEnControl(string razonSocial = null)
        {
            try
            {
                Application.Current.Dispatcher.Invoke((Action)(() =>
                {
                    if (razonSocial == null)
                        txtRazonSocial.Text = string.Empty;
                    else
                        txtRazonSocial.Text = razonSocial;
                }));
            }
            catch (JsonException jsonEx)
            {
                _logger.Debug("VentanaCobroFactura:CargarRazonSocialEnControl() JsonException: {0}", jsonEx.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
            catch (Exception ex)
            {
                _logger.Debug("VentanaCobroFactura:CargarRazonSocialEnControl() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
        }
        #endregion

        #region Metodo de carga de textbox de Opcion
        private void CargarOpcionEnControl(string opcion = null)
        {
            try
            {
                Application.Current.Dispatcher.Invoke((Action)(() =>
                {
                    if (opcion == null)
                        txtOpcion.Text = string.Empty;
                    else
                        txtOpcion.Text = opcion;
                }));
            }
            catch (JsonException jsonEx)
            {
                _logger.Debug("VentanaCobroFactura:CargarOpcionEnControl() JsonException: {0}", jsonEx.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
            catch (Exception ex)
            {
                _logger.Debug("VentanaCobroFactura:CargarOpcionEnControl() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
        }
        #endregion

        #region Metodos de carga de lista de clientes

        /// <summary>
        /// Verifica si opcion ingresada se encuentra dentro del rango de la pagina de clientes visible en pantalla
        /// </summary>
        /// <returns></returns>
        private bool EstaEnRangoDePaginaVisible(int num)
        {
            bool ret = false;
            ret = _listaClientesIndex.Exists(c => c.Pagina == _paginaVisible && c.NumeroCliente == num);
            return ret;
        }

        /// <summary>
        /// Resalta el cliente seleccionada en la lista del control
        /// </summary>
        /// <param name="num"></param>
        /// <returns></returns>
        private void ResaltarClienteSeleccionado(int num)
        {
            int index = 0;
            if (num <= _filasVisiblesPrimerPaginaClientes)
            {
                index = num - 1;
            }
            else
            {
                index = (num % _filasVisiblesPrimerPaginaClientes) - 1;
            }

            dataGridClientes.Dispatcher.Invoke((Action)(() =>
            {
                dataGridClientes.SelectedIndex = index;
                dataGridClientes.ScrollIntoView(dataGridClientes.SelectedItem);
            }));
        }

        private List<ClienteConIndex> MapearListaClientes(List<InfoCliente> listaInfocliente)
        {
            List<ClienteConIndex> lista = new List<ClienteConIndex>();
            int numeroCliente = 0;
            int numeroPagina = 0;

            foreach(InfoCliente ic in listaInfocliente)
            {
                numeroPagina = (numeroCliente / _filasVisiblesPrimerPaginaClientes ) + 1;
                lista.Add(new ClienteConIndex(ic, numeroCliente+1,numeroPagina) );
                numeroCliente++;
            }

            return lista;
        }

        private void CargarListaClientesEnControl(int numeroPagina = 1)
        {
            try
            {
                List<ClienteConIndex> lista = _listaClientesIndex.FindAll(c => c.Pagina == numeroPagina);

                if (lista.Count > 0)
                {
                    _paginaVisible = numeroPagina;

                    if (_listaClientesIndex.Exists(c => c.Pagina == numeroPagina+1 )) //Si hay mas paginas para mostrar
                    {
                        _pantalla.MensajeDescripcion(msgSeleccionClienteMultiplesPaginas);
                    }
                    else
                    {
                        _pantalla.MensajeDescripcion(msgSeleccionCliente);
                    }

                    Application.Current.Dispatcher.Invoke((Action)(() =>
                    {
                        dataGridClientes.ItemsSource = lista;
                        dataGridClientes.Items.Refresh();
                        //dataGridClientes.SelectedIndex = 0;
                    }));
                }
            }
            catch (JsonException jsonEx)
            {
                _logger.Debug("VentanaTagManual:CargarDatosEnControles() JsonException: {0}", jsonEx.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
            catch (Exception ex)
            {
                _logger.Debug("VentanaTagManual:CargarDatosEnControles() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
        }
        #endregion

        #region Formato textboxs

        private enum eTextBoxVentanaFactura { Clave, Ruc, RazonSocial, Opcion }

        private Brush _brushFondoRegular = Brushes.White;
        private Brush _brushLetraRegular = Brushes.Black;
        private Brush _brushFondoResaltado = Brushes.Blue;
        private Brush _brushLetraResaltado = Brushes.Yellow;

        /// <summary>
        /// Formatea colores de textbox
        /// </summary>
        /// <param name="eTextBox"></param>
        /// <param name="resaltar"></param>
        private void FormatearTextBox(eTextBoxVentanaFactura eTextBox, bool resaltar = true)
        {
            TextBox textbox = txtClave;

            switch (eTextBox)
            {
                case eTextBoxVentanaFactura.Clave:
                    textbox = txtClave;
                    break;
                case eTextBoxVentanaFactura.RazonSocial:
                    textbox = txtRazonSocial;
                    break;
                case eTextBoxVentanaFactura.Ruc:
                    textbox = txtRuc;
                    break;
                case eTextBoxVentanaFactura.Opcion:
                    textbox = txtOpcion;
                    break;
            }

            Application.Current.Dispatcher.BeginInvoke((Action)(() =>
            {
                if (resaltar)
                {
                    textbox.Background = _brushFondoResaltado;
                    textbox.Foreground = _brushLetraResaltado;
                }
                else
                {
                    textbox.Background = _brushFondoRegular;
                    textbox.Foreground = _brushLetraRegular;
                }
            }));
        }
        #endregion

        #region Metodos de comunicacion (recepcion) con el modulo de logica
        /// <summary>
        /// Este metodo recibe el string JSON que llega desde el socket
        /// </summary>
        /// <param name="comandoJson"></param>
        public void RecibirDatosLogica(ComandoLogica comandoJson)
        {
            try
            {
                if (comandoJson.CodigoStatus == enmStatus.Ok
                    && comandoJson.Accion == enmAccion.ESTADO)
                {
                    Causa causa = Utiles.ClassUtiles.ExtraerObjetoJson<Causa>(comandoJson.Operacion);

                    if (causa.Codigo == eCausas.AperturaTurno
                        || causa.Codigo == eCausas.CausaCierre
                        || causa.Codigo == eCausas.Salidavehiculo)
                    {
                        //Logica indica que se debe cerrar la ventana
                        Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                        {
                            _pantalla.CargarSubVentana(enmSubVentana.Principal);
                        }));
                    }
                }
                else if (comandoJson.Accion == enmAccion.FACTURA && comandoJson.Operacion != string.Empty)
                {
                    if (_enmMenuFactura == enmMenuFactura.ConsultaDatos)
                    {
                        EstadoFactura estadoFactura = Utiles.ClassUtiles.ExtraerObjetoJson<EstadoFactura>(comandoJson.Operacion);
                        
                        if (estadoFactura.Codigo == eBusquedaFactura.BusquedaNumeroCliente)
                        {
                            _listaClientes = Utiles.ClassUtiles.ExtraerObjetoJson<List<InfoCliente>>(comandoJson.Operacion);
                            _listaClientes.Sort((x, y) => x.RazonSocial.CompareTo(y.RazonSocial));
                            _cantidadClientes = _listaClientes.Count;
                            _listaClientesIndex = MapearListaClientes(_listaClientes);

                            if (_cantidadClientes == 0)
                            {
                                _pantalla.MensajeDescripcion(msgClienteNoHallado);
                                _enmMenuFactura = enmMenuFactura.IngresoClave;
                            }
                            else if (_cantidadClientes == 1)
                            {
                                CargarRazonSocialEnControl(_listaClientes[0].RazonSocial);
                                CargarRucEnControl(_listaClientes[0].Ruc);
                                _pantalla.MensajeDescripcion(msgConfirmaDatos);
                                _enmMenuFactura = enmMenuFactura.MuestroDatosClave;
                                _infoCliente = _listaClientes[0];
                            }
                            else
                            {
                                CargarListaClientesEnControl();
                                _enmMenuFactura = enmMenuFactura.SeleccionCliente;
                                FormatearTextBox(eTextBoxVentanaFactura.Clave,false);
                                FormatearTextBox(eTextBoxVentanaFactura.Opcion);
                            }
                        }
                        else if (estadoFactura.Codigo == eBusquedaFactura.BusquedaNombre)
                        {
                            _listaClientes = Utiles.ClassUtiles.ExtraerObjetoJson<List<InfoCliente>>(comandoJson.Operacion);
                            _listaClientes.Sort((x, y) => x.RazonSocial.CompareTo(y.RazonSocial));
                            _cantidadClientes = _listaClientes.Count;
                            _listaClientesIndex = MapearListaClientes(_listaClientes);

                            if (_cantidadClientes == 0)
                            {
                                _pantalla.MensajeDescripcion(msgClienteNoHallado);
                                _enmMenuFactura = enmMenuFactura.IngresoRazonSocial;
                            }
                            else if (_cantidadClientes == 1)
                            {
                                CargarClaveEnControl(_listaClientes[0].Clave.ToString());
                                CargarRazonSocialEnControl(_listaClientes[0].RazonSocial);
                                CargarRucEnControl(_listaClientes[0].Ruc);
                                _pantalla.MensajeDescripcion(msgConfirmaDatos);
                                _enmMenuFactura = enmMenuFactura.MuestroDatosRazonSocial;
                                _infoCliente = _listaClientes[0];
                            }
                            else
                            {
                                CargarListaClientesEnControl();
                                _enmMenuFactura = enmMenuFactura.SeleccionCliente;
                                FormatearTextBox(eTextBoxVentanaFactura.RazonSocial, false);
                                FormatearTextBox(eTextBoxVentanaFactura.Opcion);
                            }
                        }
                        else if (estadoFactura.Codigo == eBusquedaFactura.BusquedaRut)
                        {
                            _listaClientes = Utiles.ClassUtiles.ExtraerObjetoJson<List<InfoCliente>>(comandoJson.Operacion);
                            _listaClientes.Sort((x, y) => x.RazonSocial.CompareTo(y.RazonSocial));
                            _cantidadClientes = _listaClientes.Count;
                            _listaClientesIndex = MapearListaClientes(_listaClientes);

                            if (_cantidadClientes == 0)
                            {
                                _pantalla.MensajeDescripcion(msgNuevoCliente);
                                _enmMenuFactura = enmMenuFactura.IngresoNuevaRazonSocial;
                                FormatearTextBox(eTextBoxVentanaFactura.Ruc, false);
                                FormatearTextBox(eTextBoxVentanaFactura.RazonSocial);
                            }
                            else if (_cantidadClientes == 1)
                            {
                                CargarClaveEnControl(_listaClientes[0].Clave.ToString());
                                CargarRazonSocialEnControl(_listaClientes[0].RazonSocial);
                                CargarRucEnControl(_listaClientes[0].Ruc);
                                _pantalla.MensajeDescripcion(msgConfirmaDatos);
                                _enmMenuFactura = enmMenuFactura.MuestroDatosRuc;
                                _infoCliente = _listaClientes[0];
                            }
                            else
                            {
                                CargarListaClientesEnControl();
                                _enmMenuFactura = enmMenuFactura.SeleccionCliente;
                                FormatearTextBox(eTextBoxVentanaFactura.Ruc, false);
                                FormatearTextBox(eTextBoxVentanaFactura.Opcion);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.Debug("VentanaFactura:RecibirDatosLogica() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al recibir una Respuesta de logica.");
            }
        }
        #endregion
    }
}
