﻿using System;
using System.Windows;
using ModuloPantallaTeclado.Interfaces;
using ModuloPantallaTeclado.Clases;
using Newtonsoft.Json;
using Entidades.Comunicacion;
using Entidades;
using Entidades.Logica;
using System.Collections.Generic;
using Entidades.ComunicacionBaseDatos;
using System.Windows.Media;
using System.Windows.Input;

namespace ModuloPantallaTeclado.Sub_Ventanas
{
    public enum enmMenuRetiro { IngresoImporte, IngresoBolsa, IngresoPrecinto, Confirmacion }

    /// <summary>
    /// Lógica de interacción para VentanaRetiroAnticipado.xaml
    /// </summary>
    public partial class VentanaRetiroAnticipado : Window, ISubVentana
    {
        #region Variables y propiedades de clase
        private IPantalla _pantalla = null;
        private enmMenuRetiro _enmMenuRetiro;
        private long _importeARetirar = 0;
        private int _numeroDeBolsa = 0;
        private int _numeroDePrecinto = 0;
        private int _caracteresSimboloMoneda;
        private Moneda _moneda = null;
        private bool _usaBolsa = false;
        private Parte _parte = null;
        private Brush _brushFondoRegular = Brushes.Black;
        private Brush _brushLetraRegular = Brushes.White;
        private Brush _brushFondoResaltado = Brushes.Blue;
        private Brush _brushLetraResaltado = Brushes.Yellow;
        private NLog.Logger _logger = NLog.LogManager.GetLogger("logfile");
        JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings
        {
            NullValueHandling = NullValueHandling.Ignore,
            MissingMemberHandling = MissingMemberHandling.Ignore
        };
        #endregion

        #region Mensajes de descripcion
        const string msgIngresoMonto = "Ingrese el importe a retirar y confirme con [ENTER], [ESC] para volver.";
        const string msgIngresoBolsa = "Ingrese el número de bolsa y confirme con [ENTER], [ESC] para volver.";
        const string msgIngresoPrecinto = "Ingrese el número de precinto y confirme con [ENTER], [ESC] para volver.";
        const string msgConfirmeDatos = "Confirme los datos ingresados con [CASH], [ESC] para volver.";
        #endregion

        #region Constructor de la clase
        public VentanaRetiroAnticipado(IPantalla padre)
        {
            InitializeComponent();
            _pantalla = padre;
        }
        #endregion

        #region Evento de carga de la ventana
        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            Application.Current.Dispatcher.BeginInvoke((Action)(() =>
            {
                _pantalla.MensajeDescripcion(msgIngresoMonto);
                _enmMenuRetiro = enmMenuRetiro.IngresoImporte;
                txtImporte.Text = Datos.GetSimboloMonedaReferencia();
                _caracteresSimboloMoneda = txtImporte.Text.Length;
                if (_pantalla.ParametroAuxiliar != string.Empty)
                {
                    //_moneda = Utiles.ClassUtiles.ExtraerObjetoJson<RetiroAnticipado>(_pantalla.ParametroAuxiliar).Moneda;
                    _moneda = Utiles.ClassUtiles.ExtraerObjetoJson<Moneda>( _pantalla.ParametroAuxiliar );
                    _usaBolsa = Utiles.ClassUtiles.ExtraerObjetoJson<Bolsa>(_pantalla.ParametroAuxiliar).UsaBolsa;
                    if(_usaBolsa)
                    {
                        FormatearTextBoxBolsa();
                        FormatearTextBoxPrecinto();
                    }
                    CargarDatosEnControles(_pantalla.ParametroAuxiliar);
                }
            }));
        }
        #endregion

        #region Metodo para obtener el control desde el padre
        /// <summary>
        /// Obtiene el control que se quiere agregar a la ventana principal
        /// <returns>FrameworkElement</returns>
        /// </summary>
        public FrameworkElement ObtenerControlPrincipal()
        {
            FrameworkElement control = (FrameworkElement)borderVentanaRetiro.Child;
            borderVentanaRetiro.Child = null;
            Close();
            return control;
        }
        #endregion

        #region Metodos de comunicacion con el modulo de logica
        /// <summary>
        /// Este metodo recibe el string JSON que llega desde el socket
        /// </summary>
        /// <param name="comandoJson"></param>
        public void RecibirDatosLogica(ComandoLogica comandoJson)
        {
            try
            {
                if (comandoJson.CodigoStatus == enmStatus.Ok
                    && comandoJson.Accion == enmAccion.ESTADO)
                {
                    Causa causa = Utiles.ClassUtiles.ExtraerObjetoJson<Causa>(comandoJson.Operacion);

                    if (causa.Codigo == eCausas.AperturaTurno
                        || causa.Codigo == eCausas.CausaCierre)
                    {
                        //Logica indica que se debe cerrar la ventana
                        Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                        {
                            _pantalla.CargarSubVentana(enmSubVentana.Principal);
                        }));
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.Debug("VentanaRetiroAnticipado:RecibirDatosLogica() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al recibir una Respuesta de logica.");
            }
        }

        /// <summary>
        /// Este metodo envia un json formateado en string hacia el socket
        /// </summary>
        /// <param name="status"></param>
        /// <param name="Accion"></param>
        /// <param name="Operacion"></param>
        public void EnviarDatosALogica(enmStatus status, enmAccion Accion, string Operacion)
        {
            try
            {
                _pantalla.EnviarDatosALogica(status, Accion, Operacion);
            }
            catch (Exception ex)
            {
                _logger.Debug("VentanaRetiroAnticipado:EnviarDatosALogica() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al intentar enviar datos a logica.");
            }
        }
        #endregion

        #region Metodo de carga de textboxes de datos
        private void CargarDatosEnControles(string datos)
        {
            try
            {
                _parte = Utiles.ClassUtiles.ExtraerObjetoJson<Parte>(datos);
                Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                {
                    txtCajero.Text = _parte.IDCajero;
                    txtNombre.Text = _parte.NombreCajero;
                    txtParte.Text = _parte.NumeroParte.ToString();
                }));
            }
            catch (JsonException jsonEx)
            {
                _logger.Debug("VentanaRetiroAnticipado:CargarDatosEnControles() JsonException: {0}", jsonEx.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
            catch (Exception ex)
            {
                _logger.Debug("CargarDatosEnControles:CargarDatosEnControles() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
        }
        #endregion

        #region Metodo de procesamiento de tecla recibida
        /// <summary>
        /// A este metodo llegan las teclas recibidas desde la pantalla principal
        /// </summary>
        /// <param name="tecla"></param>
        public void ProcesarTecla(Key tecla)
        {
            List<DatoVia> listaDV = new List<DatoVia>();
            if (Teclado.IsEscapeKey(tecla))
            {
                if (_enmMenuRetiro == enmMenuRetiro.IngresoImporte)
                {
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        txtImporte.Text = string.Empty;
                        txtBolsa.Text = string.Empty;
                        EnviarDatosALogica(enmStatus.Abortada, enmAccion.RETIRO_ANT, string.Empty);
                        _pantalla.CargarSubVentana(enmSubVentana.Principal);
                    }));
                }
                else if (_enmMenuRetiro == enmMenuRetiro.IngresoBolsa && _usaBolsa)
                {
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        _pantalla.MensajeDescripcion(msgIngresoMonto);
                        _enmMenuRetiro = enmMenuRetiro.IngresoImporte;
                        txtBolsa.Text = string.Empty;
                    }));
                }
                else if (_enmMenuRetiro == enmMenuRetiro.IngresoPrecinto && _usaBolsa)
                {
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        _pantalla.MensajeDescripcion(msgIngresoBolsa);
                        _enmMenuRetiro = enmMenuRetiro.IngresoBolsa;
                        txtPrecinto.Text = string.Empty;
                    }));
                }
                else if (_enmMenuRetiro == enmMenuRetiro.Confirmacion)
                {
                    if (_usaBolsa)
                    {
                        Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                        {
                            _pantalla.MensajeDescripcion(msgIngresoPrecinto);
                            _enmMenuRetiro = enmMenuRetiro.IngresoPrecinto;
                        }));
                    }
                    else
                    {
                        Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                        {
                            _pantalla.MensajeDescripcion(msgIngresoMonto);
                            _enmMenuRetiro = enmMenuRetiro.IngresoImporte;
                        }));
                    }
                }
            }
            else if (Teclado.IsConfirmationKey(tecla))
            {
                if (_enmMenuRetiro == enmMenuRetiro.IngresoImporte)
                {
                    _importeARetirar = int.Parse(txtImporte.Text.Remove(0, _caracteresSimboloMoneda - 1));
                    if (_usaBolsa)
                    {
                        Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                        {
                            if (txtImporte.Text.Length > _caracteresSimboloMoneda)
                            {
                                _pantalla.MensajeDescripcion(msgIngresoBolsa);
                                _enmMenuRetiro = enmMenuRetiro.IngresoBolsa;
                                txtBolsa.Text = string.Empty;
                            }
                        }));
                    }
                    else
                    {
                        Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                        {
                            if (txtImporte.Text.Length > _caracteresSimboloMoneda)
                            {
                                _pantalla.MensajeDescripcion(msgConfirmeDatos);
                                _enmMenuRetiro = enmMenuRetiro.Confirmacion;
                            }
                        }));
                    }
                }
                else if (_enmMenuRetiro == enmMenuRetiro.IngresoBolsa && _usaBolsa)
                {
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        _pantalla.MensajeDescripcion(msgIngresoPrecinto);
                        _enmMenuRetiro = enmMenuRetiro.IngresoPrecinto;
                        if (txtBolsa.Text.Length > 0)
                            _numeroDeBolsa = int.Parse(txtBolsa.Text);
                        else
                            _numeroDeBolsa = 0;
                    }));
                }
                else if (_enmMenuRetiro == enmMenuRetiro.IngresoPrecinto && _usaBolsa)
                {
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        _pantalla.MensajeDescripcion(msgConfirmeDatos);
                        _enmMenuRetiro = enmMenuRetiro.Confirmacion;
                        if (txtPrecinto.Text.Length > 0)
                            _numeroDePrecinto = int.Parse(txtPrecinto.Text);
                        else
                            _numeroDePrecinto = 0;
                    }));
                }
            }
            else if (Teclado.IsCashKey(tecla))
            {
                if (_enmMenuRetiro == enmMenuRetiro.Confirmacion)
                {
                    RetiroAnticipado retiro = new RetiroAnticipado(_importeARetirar * 1000, _numeroDeBolsa, _numeroDePrecinto);
                    //retiro.Moneda = _moneda;
                    retiro.PorDenominacion = false;
                    Utiles.ClassUtiles.InsertarDatoVia(retiro, ref listaDV);
                    Utiles.ClassUtiles.InsertarDatoVia( _moneda, ref listaDV );
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        EnviarDatosALogica(enmStatus.Ok, enmAccion.RETIRO_ANT, JsonConvert.SerializeObject(listaDV, jsonSerializerSettings));
                        _pantalla.CargarSubVentana(enmSubVentana.Principal);
                    }));
                }
            }
            else if (Teclado.IsBackspaceKey(tecla))
            {
                if (_enmMenuRetiro == enmMenuRetiro.IngresoImporte)
                {
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        if (txtImporte.Text.Length > _caracteresSimboloMoneda)
                            txtImporte.Text = txtImporte.Text.Remove(txtImporte.Text.Length - 1);
                    }));
                }
                else if (_enmMenuRetiro == enmMenuRetiro.IngresoBolsa && _usaBolsa)
                {
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        if (txtBolsa.Text.Length > 0)
                            txtBolsa.Text = txtBolsa.Text.Remove(txtBolsa.Text.Length - 1);
                    }));
                }
                else if (_enmMenuRetiro == enmMenuRetiro.IngresoPrecinto && _usaBolsa)
                {
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        if (txtPrecinto.Text.Length > 0)
                            txtPrecinto.Text = txtPrecinto.Text.Remove(txtPrecinto.Text.Length - 1);
                    }));
                }
            }
            else
            {
                if (_enmMenuRetiro == enmMenuRetiro.IngresoImporte)
                {
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        txtImporte.Text += Teclado.GetKeyNumericValue(tecla);
                    }));
                }
                else if (_enmMenuRetiro == enmMenuRetiro.IngresoBolsa && _usaBolsa)
                {
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        txtBolsa.Text += Teclado.GetKeyNumericValue(tecla);
                    }));
                }
                else if (_enmMenuRetiro == enmMenuRetiro.IngresoPrecinto && _usaBolsa)
                {
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        txtPrecinto.Text += Teclado.GetKeyNumericValue(tecla);
                    }));
                }
            }
        }
        #endregion

        /// <summary>
        /// Cambia formato textbox de numero de bolsa (resaltar o formato normal)
        /// </summary>
        /// <param name="resaltar"></param>
        private void FormatearTextBoxBolsa(bool resaltar = true)
        {
            Application.Current.Dispatcher.BeginInvoke((Action)(() =>
            {
                if (_usaBolsa && !txtBolsa.IsEnabled)
                    txtBolsa.IsEnabled = true;
                if (resaltar)
                {
                    txtBolsa.Background = _brushFondoResaltado;
                    txtBolsa.Foreground = _brushLetraResaltado;
                }
                else
                {
                    txtBolsa.Background = _brushFondoRegular;
                    txtBolsa.Foreground = _brushLetraRegular;
                }
            }));
        }

        /// <summary>
        /// Cambia formato textbox de numero de precinto (resaltar o formato normal)
        /// </summary>
        /// <param name="resaltar"></param>
        private void FormatearTextBoxPrecinto(bool resaltar = true)
        {
            Application.Current.Dispatcher.BeginInvoke((Action)(() =>
            {
                if (_usaBolsa && !txtPrecinto.IsEnabled)
                    txtPrecinto.IsEnabled = true;

                if (resaltar)
                {
                    txtPrecinto.Background = _brushFondoResaltado;
                    txtPrecinto.Foreground = _brushLetraResaltado;
                }
                else
                {
                    txtPrecinto.Background = _brushFondoRegular;
                    txtPrecinto.Foreground = _brushLetraRegular;
                }
            }));
        }
    }
}
