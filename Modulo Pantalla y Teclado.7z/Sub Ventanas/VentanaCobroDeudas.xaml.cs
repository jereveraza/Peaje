﻿using System.Windows;
using ModuloPantallaTeclado.Interfaces;
using ModuloPantallaTeclado.Entidades;
using ModuloPantallaTeclado.Clases;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Windows.Controls;
using Entidades.Comunicacion;
using Entidades;
using Entidades.Logica;
using System.Windows.Input;

namespace ModuloPantallaTeclado.Sub_Ventanas
{
    public enum enmCobroDeuda { IngresoPatente, IngresoDocumento, ObtenerDatos, SeleccionDeuda, ConfirmoPago }

    /// <summary>
    /// Lógica de interacción para VentanaCobroDeudas.xaml
    /// </summary>
    public partial class VentanaCobroDeudas : Window, ISubVentana
    {
        #region Variables y propiedades de clase
        private IPantalla _pantalla = null;
        private enmCobroDeuda _enmCobroDeuda;
        private string _patenteIngresada;
        private int _itemSeleccionado, _cantDeudas;
        private long _totalDueda;
        private NLog.Logger _logger = NLog.LogManager.GetLogger("logfile");
        JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings
        {
            NullValueHandling = NullValueHandling.Ignore,
            MissingMemberHandling = MissingMemberHandling.Ignore
        };
        #endregion

        #region Mensajes de descripcion
        const string msgIngresoPatente = "Ingrese la patente [ENTER] para confirmar, [ESC] para volver.";
        const string msgFormatoPatenteErr = "Formato de patente incorrecto";
        const string msgIngresoDocumento = "Ingrese el número de documento y presione [ENTER] para confirmar, [ESC] para volver.";
        const string msgSeleccioneDeuda = "Seleccione la deuda a abonar y presione [ENTER] para confirmar, [ESC] para volver.";
        const string msgDeseaConfirmarPago = "Presione [ENTER] para confirmar el pago, [ESC] para volver.";
        #endregion

        #region Constructor de la clase
        /// <summary>
        /// Constructor de la clase
        /// </summary>
        /// <param name="padre"></param>
        public VentanaCobroDeudas(IPantalla padre)
        {
            InitializeComponent();
            _pantalla = padre;
        }
        #endregion

        #region Evento de carga de la ventana
        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            _enmCobroDeuda = enmCobroDeuda.IngresoPatente;
            dataGridDeudas.SelectionUnit = DataGridSelectionUnit.FullRow;
            dataGridDeudas.SelectionMode = DataGridSelectionMode.Single;

            Application.Current.Dispatcher.BeginInvoke((Action)(() =>
            {
                _pantalla.MensajeDescripcion(msgIngresoPatente);
                if (_pantalla.ParametroAuxiliar != string.Empty)
                {
                    _patenteIngresada = _pantalla.ParametroAuxiliar;
                    txtBoxPatente.Text = _patenteIngresada;
                }
            }));
        }
        #endregion

        #region Metodo para obtener el control desde el padre
        /// <summary>
        /// Obtiene el control que se quiere agregar a la ventana principal
        /// <returns>FrameworkElement</returns>
        /// </summary>
        public FrameworkElement ObtenerControlPrincipal()
        {
            FrameworkElement control = (FrameworkElement)borderCobroDeudas.Child;
            borderCobroDeudas.Child = null;
            Close();
            return control;
        }
        #endregion

        #region Metodo que carga los datos en los controles
        /// <summary>
        /// Metodo que carga los datos enviados por logica en los controles
        /// </summary>
        /// <param name="datos"></param>
        private void CargarDatosEnControles(string datos)
        {
            try
            {
                ListaDeuda listaDeudas = Utiles.ClassUtiles.ExtraerObjetoJson<ListaDeuda>(datos);
                List<Deuda> deudas = listaDeudas.ListaDeudas;

                //Ordeno la lista por fecha descendente
                deudas.Sort((x, y) => y.FechaHora.CompareTo(x.FechaHora));
                _itemSeleccionado = 1;
                foreach (var d in deudas)
                {
                    _totalDueda += d.Monto;
                }
                //Agrego la opcion de pagar todo al final de la lista
                var pagoTotal = new Deuda("0","TODAS","-","-", _totalDueda,DateTime.Now);
                deudas.Add(pagoTotal);

                _enmCobroDeuda = enmCobroDeuda.SeleccionDeuda;
                Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                {
                    _pantalla.MensajeDescripcion(msgSeleccioneDeuda);
                    dataGridDeudas.Items.Clear();
                    dataGridDeudas.ItemsSource = deudas;
                    dataGridDeudas.Items.Refresh();
                    _cantDeudas = dataGridDeudas.Items.Count;
                    dataGridDeudas.SelectedIndex = _itemSeleccionado - 1;
                    txtBoxTotal.Text = Datos.GetSimboloMonedaReferencia() + (dataGridDeudas.SelectedItem as Deuda).Monto.ToString();
                }));
            }
            catch (JsonException jsonEx)
            {
                _logger.Debug("CobroDeudas:CargarDatosEnControles() JsonException: {0}", jsonEx.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
            catch (Exception ex)
            {
                _logger.Debug("CobroDeudas:CargarDatosEnControles() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
        }
        #endregion

        #region Metodos de comunicacion con el modulo de logica
        /// <summary>
        /// Este metodo recibe el string JSON que llega desde el socket
        /// </summary>
        /// <param name="comandoJson"></param>
        public void RecibirDatosLogica(ComandoLogica comandoJson)
        {
            try
            {
                if (_enmCobroDeuda == enmCobroDeuda.ObtenerDatos && comandoJson.Accion == enmAccion.PAGO_DIF)
                {
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        CargarDatosEnControles(comandoJson.Operacion);
                    }));
                }
            }
            catch (JsonException jsonEx)
            {
                _logger.Debug("CobroDeudas:RecibirDatosLogica() JsonException: {0}", jsonEx.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
            catch (Exception ex)
            {
                _logger.Debug("CobroDeudas:RecibirDatosLogica() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al intentar deserializar una Respuesta de logica.");
            }
        }

        /// <summary>
        /// Este metodo envia un json formateado en string hacia el socket
        /// </summary>
        /// <param name="status"></param>
        /// <param name="Accion"></param>
        /// <param name="Operacion"></param>
        public void EnviarDatosALogica(enmStatus status, enmAccion Accion, string Operacion)
        {
            try
            {
                _pantalla.EnviarDatosALogica(status, Accion, Operacion);
            }
            catch (Exception ex)
            {
                _logger.Debug("CobroDeudas:EnviarDatosALogica() Exception: {0}", ex.Message.ToString());
                _logger.Warn("Error al intentar enviar datos a logica.");
            }
        }
        #endregion

        #region Metodo de procesamiento de tecla recibida
        /// <summary>
        /// A este metodo llegan las teclas recibidas desde la pantalla principal
        /// </summary>
        /// <param name="tecla"></param>
        public void ProcesarTecla(Key tecla)
        {
            List<DatoVia> listaDV = new List<DatoVia>();
            if (Teclado.IsEscapeKey(tecla))
            {
                Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                {
                    _pantalla.CargarSubVentana(enmSubVentana.Principal);
                    EnviarDatosALogica(enmStatus.Abortada, enmAccion.PAGO_DIF, string.Empty);
                }));
            }
            else if (Teclado.IsConfirmationKey(tecla))
            {
                if (_enmCobroDeuda == enmCobroDeuda.IngresoPatente)
                {
                    _patenteIngresada = txtBoxPatente.Text;
                    if (Clases.Utiles.EsPatenteValida(_patenteIngresada))
                    {
                        Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                        {
                            //Solicito a logica datos de la patente
                            Vehiculo vehiculo = new Vehiculo();
                            vehiculo.Patente = _patenteIngresada;
                            Utiles.ClassUtiles.InsertarDatoVia(vehiculo, ref listaDV);
                            EnviarDatosALogica(enmStatus.Ok, enmAccion.PAGO_DIF, Newtonsoft.Json.JsonConvert.SerializeObject(listaDV, jsonSerializerSettings));
                        }));

                        //<----------   Aca va el ingreso opcional del documento
                        _enmCobroDeuda = enmCobroDeuda.ObtenerDatos;
                    }
                    else
                    {
                        //Si se ingreso la patente incorrecta, aviso al usuario y borro los datos
                        //ingresados
                        _pantalla.MensajeDescripcion(msgFormatoPatenteErr);
                        _patenteIngresada = string.Empty;
                        //No borro los datos ingresados para que el usuario pueda editar
                        //txtBoxPatente.Text = string.Empty;
                    }
                }
                else if (_enmCobroDeuda == enmCobroDeuda.SeleccionDeuda)
                {
                    _enmCobroDeuda = enmCobroDeuda.ConfirmoPago;
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        _pantalla.MensajeDescripcion(msgDeseaConfirmarPago);
                    }));
                }
                else if (_enmCobroDeuda == enmCobroDeuda.ConfirmoPago)
                {
                    var pagodeuda = new PagoDeuda(_patenteIngresada, (dataGridDeudas.SelectedItem as Deuda).Numero, (dataGridDeudas.SelectedItem as Deuda).Monto);
                    Utiles.ClassUtiles.InsertarDatoVia(pagodeuda, ref listaDV); 
                    EnviarDatosALogica(enmStatus.Ok, enmAccion.PAGO_DIF, JsonConvert.SerializeObject(listaDV, jsonSerializerSettings));
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        _pantalla.CargarSubVentana(enmSubVentana.Principal);
                    }));
                }
            }
            else if (Teclado.IsUpKey(tecla))
            {
                if (_enmCobroDeuda == enmCobroDeuda.SeleccionDeuda)
                {
                    if (_itemSeleccionado > 1)
                    {
                        dataGridDeudas.Dispatcher.BeginInvoke((Action)(() =>
                        {
                            _itemSeleccionado--;
                            dataGridDeudas.SelectedIndex = _itemSeleccionado - 1;
                            txtBoxTotal.Text = Datos.GetSimboloMonedaReferencia() + (dataGridDeudas.SelectedItem as Deuda).Monto.ToString();
                        }));
                    }
                }
            }
            else if (Teclado.IsDownKey(tecla))
            {
                if (_enmCobroDeuda == enmCobroDeuda.SeleccionDeuda)
                {
                    if (_itemSeleccionado < _cantDeudas)
                    {
                        dataGridDeudas.Dispatcher.BeginInvoke((Action)(() =>
                        {
                            _itemSeleccionado++;
                            dataGridDeudas.SelectedIndex = _itemSeleccionado - 1;
                            txtBoxTotal.Text = Datos.GetSimboloMonedaReferencia() + (dataGridDeudas.SelectedItem as Deuda).Monto.ToString();
                        }));
                    }
                }
            }
            else if (Teclado.IsBackspaceKey(tecla))
            {
                if (_enmCobroDeuda == enmCobroDeuda.IngresoPatente)
                {
                    if (txtBoxPatente.Text.Length > 0)
                        txtBoxPatente.Text = txtBoxPatente.Text.Remove(txtBoxPatente.Text.Length - 1);
                }
            }
            else
            {
                if (_enmCobroDeuda == enmCobroDeuda.IngresoPatente)
                {
                    if (Teclado.IsLowerCaseOrNumberKey(tecla))
                        txtBoxPatente.Text += Teclado.GetKeyAlphaNumericValue(tecla);
                }
                else if (_enmCobroDeuda == enmCobroDeuda.SeleccionDeuda)
                {
                    if (Teclado.IsNumericKey(tecla))
                    {
                        if (_cantDeudas <= 10)
                        {
                            _itemSeleccionado = (int)Teclado.GetKeyNumericValue(tecla);
                            if (_itemSeleccionado >= 1 && _itemSeleccionado <= _cantDeudas)
                            {
                                dataGridDeudas.Dispatcher.BeginInvoke((Action)(() =>
                                {
                                    dataGridDeudas.SelectedIndex = _itemSeleccionado - 1;
                                    txtBoxTotal.Text = Datos.GetSimboloMonedaReferencia() + (dataGridDeudas.SelectedItem as Deuda).Monto.ToString();
                                }));
                            }
                        }
                    }
                }
            }
        }
        #endregion
    }
}
