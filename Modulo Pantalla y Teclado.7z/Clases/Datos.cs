﻿using System;
using System.Configuration;
using System.Text;

namespace ModuloPantallaTeclado.Clases
{
    public static class Datos
    {
        #region Variables y propiedades de clase
        private static readonly object obj = new object();
        private static string _simboloMoneda = null;
        private static int _cantidadDecimales;
        private static StringBuilder _sbFormato = new StringBuilder();
        #endregion

        #region Constantes y definiciones globales
        public const double AnchoFoto = 450;
        public const double AltoFoto = 325;
        #endregion

        #region Constructor de la clase
        static Datos()
        {
            _simboloMoneda = ConfigurationManager.AppSettings["SimboloMoneda"];
            if (_simboloMoneda == null)
                _simboloMoneda = System.Globalization.CultureInfo.CurrentCulture.NumberFormat.CurrencySymbol;

            if (ConfigurationManager.AppSettings["CantidadDecimales"] == null)
                _cantidadDecimales = System.Globalization.CultureInfo.CurrentCulture.NumberFormat.CurrencyDecimalDigits;
            else
                _cantidadDecimales = Convert.ToInt32(ConfigurationManager.AppSettings["CantidadDecimales"]);

            if (_cantidadDecimales > 0)
            {
                _sbFormato.Append('0');
                _sbFormato.Append(".");
                _sbFormato.Append('0', _cantidadDecimales);
            }
            else
                _sbFormato.Append('0');
        }
        #endregion

        #region Metodos para gestion de monedas
        public static string GetSimboloMonedaReferencia()
        {
            return _simboloMoneda + " ";
        }

        public static string FormatearMonedaAString(decimal valor, string simboloMoneda = "")
        {
            string sValor, simboloM;
            
            sValor = valor.ToString(_sbFormato.ToString());

            simboloM = (simboloMoneda=="")?_simboloMoneda:simboloMoneda;

            return string.Format(simboloM + " " + sValor);
        }
        #endregion
    
    }
}
