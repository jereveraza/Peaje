﻿using System;
using System.Collections.Generic;
using System.Windows.Input;

namespace ModuloPantallaTeclado.Clases
{
    public class Teclado
    {
        private static Dictionary<string, string> _sectorTeclas;

        #region Metodo de carga de las teclas en memoria desde app.config
        public static void CargarTeclasFuncion(ref Dictionary<string, string> sectorTeclas)
        {
            _sectorTeclas = sectorTeclas;
        }
        #endregion

        #region Metodos de analisis de teclas presionadas
        /// <summary>
        /// Convierte del enumerado Key a un string
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public static string ConvertKeyToString(Key key)
        {
            string nRet = string.Empty;

            switch (key)
            {
                case Key.D0:
                case Key.D1:
                case Key.D2:
                case Key.D3:
                case Key.D4:
                case Key.D5:
                case Key.D6:
                case Key.D7:
                case Key.D8:
                case Key.D9:
                    return ((int)key - 34).ToString();
                case Key.NumPad0:
                case Key.NumPad1:
                case Key.NumPad2:
                case Key.NumPad3:
                case Key.NumPad4:
                case Key.NumPad5:
                case Key.NumPad6:
                case Key.NumPad7:
                case Key.NumPad8:
                case Key.NumPad9:
                    return ((int)key - 74).ToString();
                case Key.A:
                case Key.B:
                case Key.C:
                case Key.D:
                case Key.E:
                case Key.F:
                case Key.G:
                case Key.H:
                case Key.I:
                case Key.J:
                case Key.K:
                case Key.L:
                case Key.M:
                case Key.N:
                case Key.O:
                case Key.P:
                case Key.Q:
                case Key.R:
                case Key.S:
                case Key.T:
                case Key.U:
                case Key.V:
                case Key.W:
                case Key.X:
                case Key.Y:
                case Key.Z:
                    return (key.ToString());
                case Key.Space:
                    return " ";
            }
            return nRet;
        }

        private static Key ConvertKeyFromString(string keystr)
        {
            Key key;
            Enum.TryParse(keystr, out key);
            return key;
        }

        private static ModifierKeys ConvertModifierKeyFromString(string keystr)
        {
            ModifierKeys key;
            Enum.TryParse(keystr, out key);
            return key;
        }

        /// <summary>
        /// Obtiene la tecla alfanumerica que fue presionada
        /// </summary>
        /// <param name="e"></param>
        /// <returns></returns>
        public static char? GetKeyAlphaNumericValue(Key e)
        {
            string strAux = ConvertKeyToString(e);
            if (strAux != string.Empty && Keyboard.Modifiers == ModifierKeys.None)
                return char.Parse(strAux.ToUpper());
            return null;
        }

        /// <summary>
        /// Comprueba si la tecla ingresada corresponde a una funcion.
        /// </summary>
        /// <param name="e"></param>
        /// <param name="nombreTecla"></param>
        /// <returns></returns>
        public static bool IsFunctionKey(Key e, string nombreTecla)
        {
            try
            {
                string[] keyValueTemp = _sectorTeclas[nombreTecla].ToString().Split(',');

                if (Keyboard.Modifiers == ConvertModifierKeyFromString(keyValueTemp[1]) && e == ConvertKeyFromString(keyValueTemp[0]))
                    return true;
                return false;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Comprueba si esta definida una tecla con la descripcion informada
        /// </summary>
        /// <param name="description"></param>
        /// <returns></returns>
        public static bool IsExistingKey(string description)
        {
            if (!_sectorTeclas.ContainsKey(description))
                return false;
            return true;
        }

        /// <summary>
        /// Obtiene la tecla numerica que fue presionada
        /// </summary>
        /// <param name="e"></param>
        /// <returns></returns>
        public static int GetKeyNumericValue(Key e)
        {
            int salida=0;

            if (IsNumericKey(e))
                int.TryParse(ConvertKeyToString(e),out salida);
            return salida;
        }

        /// <summary>
        /// Comprueba si la tecla presionada es un numero o una letra minuscula
        /// </summary>
        /// <param name="e"></param>
        /// <returns></returns>
        public static bool IsLowerCaseOrNumberKey(Key e)
        {
            bool nRet = false;

            string strAux = ConvertKeyToString(e);
            if (strAux != string.Empty)
                nRet = true;
            return nRet;
        }

        /// <summary>
        /// Comprueba si la tecla presionada es un numero
        /// </summary>
        /// <param name="e"></param>
        /// <returns></returns>
        public static bool IsNumericKey(Key e)
        {
            if((e >= Key.D0 && e<= Key.D9) || (e >= Key.NumPad0 && e <= Key.NumPad9))
                return true;
            return false;
        }

        /// <summary>
        /// Comprueba si la tecla presionada es fecha arriba
        /// </summary>
        /// <param name="e"></param>
        /// <returns></returns>
        public static bool IsUpKey(Key e)
        {
            if (e == Key.Up)
                return true;
            return false;
        }

        /// <summary>
        /// Comprueba si la tecla presionada es flecha abajo
        /// </summary>
        /// <param name="e"></param>
        /// <returns></returns>
        public static bool IsDownKey(Key e)
        {
            if (e == Key.Down)
                return true;
            return false;
        }

        /// <summary>
        /// Comprueba si la tecla presionada es Backspace
        /// </summary>
        /// <param name="e"></param>
        /// <returns></returns>
        public static bool IsBackspaceKey(Key e)
        {
            string[] keyValueTemp = _sectorTeclas["Backspace"].ToString().Split(',');

            if (Keyboard.Modifiers == ConvertModifierKeyFromString(keyValueTemp[1]) && e == ConvertKeyFromString(keyValueTemp[0]))
                return true;
            return false;
        }

        /// <summary>
        /// Comprueba si se presiono la tecla escape
        /// </summary>
        /// <param name="e"></param>
        /// <returns></returns>
        public static bool IsEscapeKey(Key e)
        {
            string[] keyValueTemp = _sectorTeclas["Escape"].ToString().Split(',');

            if (Keyboard.Modifiers == ConvertModifierKeyFromString(keyValueTemp[1]) && e == ConvertKeyFromString(keyValueTemp[0]))
                return true;
            return false;
        }

        /// <summary>
        /// Comprueba si se presiono la tecla de confirmacion (enter)
        /// </summary>
        /// <param name="e"></param>
        /// <returns></returns>
        public static bool IsConfirmationKey(Key e)
        {
            string[] keyValueTemp = _sectorTeclas["Enter"].ToString().Split(',');

            if (Keyboard.Modifiers == ConvertModifierKeyFromString(keyValueTemp[1]) && e == ConvertKeyFromString(keyValueTemp[0]))
                return true;
            return false;
        }

        /// <summary>
        /// Comprueba si se presiono la tecla de efectivo
        /// </summary>
        /// <param name="e"></param>
        /// <returns></returns>
        public static bool IsCashKey(Key e)
        {
            string[] keyValueTemp = _sectorTeclas["Cash"].ToString().Split(',');

            if (Keyboard.Modifiers == ConvertModifierKeyFromString(keyValueTemp[1]) && e == ConvertKeyFromString(keyValueTemp[0]))
                return true;
            return false;
        }

        /// <summary>
        /// Comprueba si se presiono la tecla de siguiente pagina (para ventanas con muchas opciones)
        /// </summary>
        /// <param name="e"></param>
        /// <returns></returns>
        public static bool IsNextPageKey(Key e)
        {
            string[] keyValueTemp = _sectorTeclas["NextPage"].ToString().Split(',');

            if (Keyboard.Modifiers == ConvertModifierKeyFromString(keyValueTemp[1]) && e == ConvertKeyFromString(keyValueTemp[0]))
                return true;
            return false;
        }
        #endregion
    }
}
