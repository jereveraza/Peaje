﻿using System;
using System.Collections.Specialized;
using System.Configuration;
using System.Text.RegularExpressions;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ProyectoOCR;
using System.IO;
using Utiles;
using Entidades.ComunicacionBaseDatos;
using System.Collections.Generic;

namespace ModuloPantallaTeclado.Clases
{
    public static class Utiles
    {
        #region Variables y propiedades de clase
        [Flags]
        enum FormatoPatente
        {
            Libre = 0,
            Argentina = 1,
            Brasil = 2,
            Uruguay = 4,
            Ecuador = 8,
            Paraguay = 16,
            Chile = 32,
            Peru = 64, 
            Colombia = 128
        }

        private static string _FiltroPatente = string.Empty;
        private static FormatoPatente _PatentesConfiguradas = FormatoPatente.Libre;
        private static NameValueCollection _paisesConfigurados;
        private static Regex _regexFiltroPatentes;
        private static int MeAlejoAbajo;
        private static int MeAlejoArriba;
        private static int MeAlejoIzq;
        private static int MeAlejoDere;
        #endregion

        #region Filtros de expresiones regulares para patentes
        /*const string FiltroPatenteArgentina = @"(^[A-Z]{3}[0-9]{3}$)|(^[0-9]{3}[A-Z]{3}$)|(^[A-Z]{2}[0-9]{3}[A-Z]{2}$)|";
        const string FiltroPatenteBrasil = @"(^[A-Z]{3}[0-9]{4}$)|(^[A-Z]{3}[0-9][A-Z][0-9]{2}$)|";
        const string FiltroPatenteUruguay = @"(^[A-Z]{3}[0-9]{4}$)|(^[A-Z]{3}[0-9]{3}$)|";
        const string FiltroPatenteEcuador = @"(^[A-Z]{3}[0-9]{4}$)|";
        const string FiltroPatenteParaguay = @"(^[A-Z]{3}[0-9]{3}$)|(^[0-9]{3}[A-Z]{3}$)|(^[A-Z]{4}[0-9]{3}$)|";
        const string FiltroPatenteChile = @"(^[A-Z]{2}[0-9]{4}$)|(^[A-Z]{4}[0-9]{2}$)|(^[A-Z]{3}[0-9]{3}$)|(^[A-Z]{2}[0-9]{4}$)|(^[A-Z][0-9]{4}$)|";
        const string FiltroPatentePeru = @"(^[A-Z]{3}[0-9]{3}$)|(^[A-Z]{2}[0-9]{4}$)|";
        const string FiltroPatenteColombia = @"(^[A-Z]{3}[0-9]{3}$)|(^[A-Z]{2}[0-9]{4}[A-Z][0-9]{4}$)|";*/
        #endregion

        #region Metodos de Filtrado de formato de patentes
        /// <summary>
        /// Devuelve si el formato de patente ingresada es correcto o no
        /// </summary>
        /// <param name="patente"></param>
        /// <returns></returns>
        public static bool EsPatenteValida(string patente)
        {
            if (patente != null)
            {
                if(_regexFiltroPatentes != null)
                    if (_regexFiltroPatentes.Match(patente).Success)
                        return true;
            }
            return false;
        }

        /// <summary>
        /// Inicializa el filtro de formato de patentes de acuerdo al app.config
        /// </summary>
        public static void CargarFiltroPatentes(string sObjeto)
        {
            //Leo desde el app.config la configuracion de los paises
            /*_paisesConfigurados = (NameValueCollection)ConfigurationManager.GetSection("Patentes");
            _PatentesConfiguradas = FormatoPatente.Libre;
            if(_paisesConfigurados["Argentina"] == "1")
            {
                _PatentesConfiguradas = _PatentesConfiguradas ^ FormatoPatente.Argentina;
            }
            if (_paisesConfigurados["Brasil"] == "1")
            {
                _PatentesConfiguradas = _PatentesConfiguradas ^ FormatoPatente.Brasil;
            }
            if (_paisesConfigurados["Chile"] == "1")
            {
                _PatentesConfiguradas = _PatentesConfiguradas ^ FormatoPatente.Chile;
            }
            if (_paisesConfigurados["Colombia"] == "1")
            {
                _PatentesConfiguradas = _PatentesConfiguradas ^ FormatoPatente.Colombia;
            }
            if (_paisesConfigurados["Ecuador"] == "1")
            {
                _PatentesConfiguradas = _PatentesConfiguradas ^ FormatoPatente.Ecuador;
            }
            if (_paisesConfigurados["Paraguay"] == "1")
            {
                _PatentesConfiguradas = _PatentesConfiguradas ^ FormatoPatente.Paraguay;
            }
            if (_paisesConfigurados["Peru"] == "1")
            {
                _PatentesConfiguradas = _PatentesConfiguradas ^ FormatoPatente.Peru;
            }
            if (_paisesConfigurados["Uruguay"] == "1")
            {
                _PatentesConfiguradas = _PatentesConfiguradas ^ FormatoPatente.Uruguay;
            }

            if (_PatentesConfiguradas != FormatoPatente.Libre)
            {
                _FiltroPatente = string.Empty;
                if (_PatentesConfiguradas.HasFlag(FormatoPatente.Argentina))
                {
                    _FiltroPatente += FiltroPatenteArgentina;
                }
                if (_PatentesConfiguradas.HasFlag(FormatoPatente.Brasil))
                {
                    _FiltroPatente += FiltroPatenteBrasil;
                }
                if (_PatentesConfiguradas.HasFlag(FormatoPatente.Chile))
                {
                    _FiltroPatente += FiltroPatenteChile;
                }
                if (_PatentesConfiguradas.HasFlag(FormatoPatente.Colombia))
                {
                    _FiltroPatente += FiltroPatenteColombia;
                }
                if (_PatentesConfiguradas.HasFlag(FormatoPatente.Ecuador))
                {
                    _FiltroPatente += FiltroPatenteEcuador;
                }
                if (_PatentesConfiguradas.HasFlag(FormatoPatente.Paraguay))
                {
                    _FiltroPatente += FiltroPatenteParaguay;
                }
                if (_PatentesConfiguradas.HasFlag(FormatoPatente.Peru))
                {
                    _FiltroPatente += FiltroPatentePeru;
                }
                if (_PatentesConfiguradas.HasFlag(FormatoPatente.Uruguay))
                {
                    _FiltroPatente += FiltroPatenteUruguay;
                }

                //Si el ultimo caracter es '|' , lo borro
                if(_FiltroPatente[_FiltroPatente.Length - 1] == '|')
                {
                    _FiltroPatente = _FiltroPatente.Remove(_FiltroPatente.Length - 1);
                }
                _regexFiltroPatentes = new Regex(_FiltroPatente, RegexOptions.IgnoreCase | RegexOptions.Singleline |
                RegexOptions.CultureInvariant | RegexOptions.Compiled);
            }*/
            if (string.IsNullOrEmpty(_FiltroPatente))
            {
                ListadoExpresiones lExpre = ClassUtiles.ExtraerObjetoJson<ListadoExpresiones>(sObjeto);

                foreach (ExpresionRegular eR in lExpre.ListaExpresiones)
                {
                    _FiltroPatente += "(" + eR.Expresion + ")|";
                }

                //Si el ultimo caracter es '|' , lo borro
                if (_FiltroPatente[_FiltroPatente.Length - 1] == '|')
                {
                    _FiltroPatente = _FiltroPatente.Remove(_FiltroPatente.Length - 1);
                }

                _regexFiltroPatentes = new Regex(_FiltroPatente, RegexOptions.IgnoreCase | RegexOptions.Singleline |
                    RegexOptions.CultureInvariant | RegexOptions.Compiled);
            }
        }
        #endregion

        #region Metodo para validacion de RUC
        public static bool IsValidRUC(string strRuc)
        {
            bool RucValido = false;
            int suma = 0, X = 0, resto = 0, i = 0, impar = 0, par = 0, digito10 = 0, nAux = 0;
            byte digito;

            // Si es un ruc de 13 Caracteres
            if (strRuc.Length == 13)
            {
                //Numero de Provincia
                nAux = Convert.ToInt32(strRuc.Substring(0, 2));
                //Verifico que el numero de provincia este entre 1 y 24 
                if (nAux <= 0 && nAux > 24)
                {
                    return false;
                }

                //El principal o sucursal debe ser 001
                if (strRuc.Substring(10, 3) != "001")
                {
                    return false;
                }

                //El digito
                digito = Convert.ToByte(strRuc.Substring(2, 1));
                //RUC PERSONA NATURAL
                if (digito >= 0 && digito < 6)
                {
                    digito = 0;
                    for (i = 0; i < 9; i += 2)
                    {
                        digito = Convert.ToByte(strRuc.Substring(i, 1));
                        impar = impar + ((digito * 2) > 9 ? digito * 2 - 9 : digito * 2);
                    }
                    for (i = 1; i < 8; i += 2)
                    {
                        digito = Convert.ToByte(strRuc.Substring(i, 1));
                        par = par + digito;
                    }
                    suma = par + impar;
                    resto = suma % 10;
                    if (resto != 0)
                        resto = 10 - resto;
                    if (resto == 10)
                        resto = 0;
                    digito10 = Convert.ToInt32(strRuc.Substring(9, 1));
                    if (resto == digito10)
                        RucValido = true;
                    else
                        RucValido = false;
                }
                // PERSONA JURIDICA O EXTRANJERA
                else if (digito == 9)
                {
                    int[] coef9 = new int[] { 4, 3, 2, 7, 6, 5, 4, 3, 2 };
                    for (i = 0; i < 9; i++)
                    {
                        digito = Convert.ToByte(strRuc.Substring(i, 1));
                        suma = suma + digito * coef9[i];
                    }
                    resto = suma % 11;
                    if (resto != 0)
                        resto = 11 - resto;
                    if (resto == 10)
                        resto = 0;
                    digito10 = Convert.ToInt32(strRuc.Substring(9, 1));
                    if (resto == digito10)
                        RucValido = true;
                    else
                        RucValido = false;
                }
                else if (digito == 6)
                {
                    int[] coef8 = new int[] { 3, 2, 7, 6, 5, 4, 3, 2 };
                    for (i = 0; i < 8; i++)
                    {
                        digito = Convert.ToByte(strRuc.Substring(i, 1));
                        suma = suma + digito * coef8[i];
                    }
                    resto = suma % 11;
                    if (resto != 0)
                        resto = 11 - resto;
                    if (resto == 10)
                        resto = 0;
                    digito10 = Convert.ToByte(strRuc.Substring(8, 1));
                    if (resto == digito10)
                        RucValido = true;
                    else
                        RucValido = false;
                }
                else
                {
                    RucValido = false;
                }
            }
            // Si es un ruc de 10 Caracteres
            if (strRuc.Length == 10)
            {
                digito = 0;
                for (i = 0; i < 9; i += 2)
                {
                    digito = Convert.ToByte(strRuc.Substring(i, 1));
                    impar = impar + ((digito * 2) > 9 ? digito * 2 - 9 : digito * 2);
                }
                for (i = 1; i < 8; i += 2)
                {
                    digito = Convert.ToByte(strRuc.Substring(i, 1));
                    par = par + digito;
                }
                suma = par + impar;
                resto = suma % 10;
                if (resto != 0)
                    resto = 10 - resto;
                if (resto == 10)
                    resto = 0;
                digito10 = Convert.ToInt32(strRuc.Substring(9, 1));
                if (resto == digito10)
                    RucValido = true;
                else
                    RucValido = false;
            }
            return RucValido;
        }
        #endregion


        #region Metodo que carga la configuracion del zoom del app.config
        public static void CargarConfigCortarPatente()
        {
            int nAux;
            bool bOk;

            bOk = int.TryParse(ConfigurationManager.AppSettings["ZOOM_BOTTOM_IMG"].ToString(), out nAux);
            MeAlejoAbajo = bOk ? nAux : 0;

            bOk = int.TryParse(ConfigurationManager.AppSettings["ZOOM_TOP_IMG"].ToString(), out nAux);
            MeAlejoArriba = bOk ? nAux : 0;

            bOk = int.TryParse(ConfigurationManager.AppSettings["ZOOM_LEFT_IMG"].ToString(), out nAux);
            MeAlejoIzq = bOk ? nAux : 0;

            bOk = int.TryParse(ConfigurationManager.AppSettings["ZOOM_RIGTH_IMG"].ToString(), out nAux);
            MeAlejoDere = bOk ? nAux : 0;
        }
        #endregion

        #region Metodo que carga una foto en un control rectangulo
        /// <summary>
        /// Carga una foto en un control rectangulo del tamaño especificado y lo retorna
        /// </summary>
        /// <param name="strImagePath"></param>
        /// <param name="ancho"></param>
        /// <param name="alto"></param>
        /// <param name="imgRecortada"></param>
        /// <returns></returns>
        public static Rectangle CargarFotoRectangulo(string strImagePath, double ancho, double alto, bool imgRecortada)
        {
            Rectangle _rectangle = new Rectangle();
            ImageBrush _uniformBrush = new ImageBrush();
            BitmapImage _image = new BitmapImage();
            _rectangle.Width = ancho;
            _rectangle.Height = alto;

            try
            {
                if (imgRecortada)
                {
                    byte[] imageArray = File.ReadAllBytes(strImagePath);
                    string imagen = Convert.ToBase64String(imageArray);
                    bool bResutado = false;
                    ManejoImagen CropImage = new ManejoImagen();
                    imagen = CropImage.ObtenerImagenMatricula(imagen, MeAlejoArriba, MeAlejoIzq, MeAlejoDere, MeAlejoAbajo, out bResutado);
                    byte[] unicodeBytes = Convert.FromBase64String(imagen);

                    using (MemoryStream ms = new MemoryStream(unicodeBytes, 0, unicodeBytes.Length))
                    {
                        _image.BeginInit();
                        _image.StreamSource = ms;
                        _image.CacheOption = BitmapCacheOption.OnLoad;
                        _image.StreamSource = ms;
                        _image.EndInit();
                        _uniformBrush.ImageSource = _image;
                        _uniformBrush.Stretch = Stretch.Uniform;
                        // Freeze the brush (make it unmodifiable) for performance benefits.
                        _uniformBrush.Freeze();
                        _rectangle.Fill = _uniformBrush;
                    }
                }
                else
                {
                    using (var stream = File.OpenRead(strImagePath))
                    {
                        _image.BeginInit();
                        _image.CacheOption = BitmapCacheOption.OnLoad;
                        _image.StreamSource = stream;
                        _image.EndInit();
                        _uniformBrush.ImageSource = _image;
                        _uniformBrush.Stretch = Stretch.Uniform;
                        // Freeze the brush (make it unmodifiable) for performance benefits.
                        _uniformBrush.Freeze();
                        _rectangle.Fill = _uniformBrush;
                    }
                }

            }
            catch (Exception e)
            {

            }
            return _rectangle;
        }
        #endregion

    }
}
